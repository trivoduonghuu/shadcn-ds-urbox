#!/usr/bin/env python3
"""Doc Component Map (.xlsx) va sinh src/catalog/map.generated.json.

Chi lay dong Giao Dev = Co o hai sheet "Component Set" va "Component don".
Khong sua gi trong Map. Chay lai moi khi Map len version moi:

    python3 scripts/map_to_spec.py path/to/Component_Map.xlsx
"""
import json
import re
import sys
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "src" / "catalog" / "map.generated.json"
SHEETS = ["Component Set", "Component đơn"]
NONE = "(không có)"


def clean(v):
    return "" if v is None else str(v).strip()


def parse_props(text, default_text):
    defaults = {}
    for part in [p.strip() for p in clean(default_text).split(";") if p.strip()]:
        k, v = part.split("=", 1)
        defaults[k.strip()] = v.strip()
    props = []
    if not text or text == NONE:
        return props
    for line in text.split("\n"):
        if not line.strip():
            continue
        name, values = line.split(":", 1)
        name = name.strip()
        vals = [v.strip() for v in values.split("|")]
        props.append({"name": name, "values": vals, "default": defaults.get(name, vals[0])})
    return props


BOOL_RE = re.compile(r"^(.*) \(mặc định: (Bật|Tắt)\)$")
SWAP_RE = re.compile(r"^(.*) \(mặc định: (.*)\)$")


def parse_bools(text):
    out = []
    if not text or text == NONE:
        return out
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        m = BOOL_RE.match(line)
        out.append({"name": m.group(1).strip(), "default": m.group(2) == "Bật"})
    return out


def parse_swaps(text):
    out = []
    if not text or text == NONE:
        return out
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        m = SWAP_RE.match(line)
        out.append({"name": m.group(1).strip(), "default": m.group(2).strip()})
    return out


def main(xlsx):
    wb = openpyxl.load_workbook(xlsx, read_only=True)
    rows = []
    for sheet in SHEETS:
        ws = wb[sheet]
        it = ws.iter_rows(values_only=True)
        header = [clean(h) for h in next(it)]
        col = {h: i for i, h in enumerate(header)}
        for r in it:
            code = clean(r[col["Mã"]])
            if not code or clean(r[col["Giao Dev"]]) != "Có":
                continue
            rows.append(
                {
                    "id": code,
                    "sheet": sheet,
                    "figma": clean(r[col["Component (Figma)"]]),
                    "kind": clean(r[col["Loại"]]),
                    "ds": clean(r[col["data-ds"]]),
                    "props": parse_props(clean(r[col["Property và giá trị"]]), r[col["data-ds-props mặc định"]]),
                    "bools": parse_bools(clean(r[col["Boolean"]])),
                    "swaps": parse_swaps(clean(r[col["Instance swap"]])),
                }
            )
    OUT.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{len(rows)} dong Giao Dev = Co -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main(sys.argv[1])
