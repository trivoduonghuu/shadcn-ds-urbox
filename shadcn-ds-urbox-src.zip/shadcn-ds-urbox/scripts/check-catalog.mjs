// Kiem catalog tren trinh duyet: loi console, font Manrope, va thu thap moi phan tu data-ds
// (ca trang chinh lan tung iframe overlay). Ket qua ghi ra JSON de scripts/verify.py doi chieu voi Map.
//
//   npm run build && npx vite preview --port 4173 &
//   node scripts/check-catalog.mjs http://localhost:4173 out.json [light|dark]
import fs from "node:fs"
import { createRequire } from "node:module"

const require = createRequire(import.meta.url)
const { chromium } = require("playwright")

const [base = "http://localhost:4173", out = "catalog-check.json", theme = "light"] = process.argv.slice(2)

const browser = await chromium.launch()
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
const errors = []
const fonts = []
page.on("console", (m) => m.type() === "error" && errors.push({ where: "main", text: m.text() }))
page.on("pageerror", (e) => errors.push({ where: "main", text: String(e) }))
page.on("response", (r) => {
  if (r.url().includes("fonts.gstatic.com") || r.url().includes("fonts.googleapis.com")) fonts.push({ url: r.url(), status: r.status() })
})

await page.goto(`${base}/?theme=${theme}`, { waitUntil: "networkidle" })
await page.evaluate(() => document.fonts.ready)

const collect = () =>
  [...document.querySelectorAll("[data-ds]")].map((el) => ({ ds: el.getAttribute("data-ds"), props: el.getAttribute("data-ds-props") }))

const main = await page.evaluate(() => {
  const els = [...document.querySelectorAll("[data-ds]")].map((el) => ({ ds: el.getAttribute("data-ds"), props: el.getAttribute("data-ds-props") }))
  return {
    els,
    screens: document.querySelectorAll("[data-screen]").length,
    screen: document.querySelector("[data-screen]")?.getAttribute("data-screen"),
    bodyFont: getComputedStyle(document.body).fontFamily,
    frames: [...document.querySelectorAll("iframe[data-overlay-frame]")].map((f) => f.getAttribute("src")),
    dsNew: document.querySelectorAll("[data-ds-new]").length,
    fontFaces: [...document.fonts].filter((f) => f.status === "loaded").map((f) => `${f.family} ${f.weight} ${f.unicodeRange.slice(0, 24)}`),
  }
})

const frameEls = []
const fpage = await browser.newPage({ viewport: { width: 1000, height: 1500 } })
fpage.on("console", (m) => m.type() === "error" && errors.push({ where: fpage.url(), text: m.text() }))
fpage.on("pageerror", (e) => errors.push({ where: fpage.url(), text: String(e) }))
for (const src of main.frames) {
  await fpage.goto(`${base}/${src}`, { waitUntil: "networkidle" })
  await fpage.waitForTimeout(150)
  const els = await fpage.evaluate(collect)
  if (els.length === 0 && !src.includes("select-open")) errors.push({ where: src, text: "frame khong co phan tu data-ds" })
  frameEls.push(...els.map((e) => ({ ...e, frame: src })))
}

const result = { theme, errors, fonts, ...main, els: [...main.els, ...frameEls] }
fs.writeFileSync(out, JSON.stringify(result, null, 2))
console.log(
  JSON.stringify(
    { theme, mainElements: main.els.length, frameCount: main.frames.length, frameElements: frameEls.length, errors: errors.length, bodyFont: main.bodyFont, screen: main.screen },
    null,
    2
  )
)
await browser.close()
