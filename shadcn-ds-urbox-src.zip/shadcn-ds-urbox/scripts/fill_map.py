#!/usr/bin/env python3
"""Dien cot "Ten trong code" vao Component Map va them sheet "Bang lech".

  python3 scripts/fill_map.py <Map goc .xlsx> <Map da dien .xlsx>

Chi ghi vao cot "Ten trong code" cua dong Giao Dev = Co va them sheet moi;
khong sua o nao khac cua Map.
"""
import json
import sys
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

ROOT = Path(__file__).resolve().parent.parent
CODE_MAP = json.loads((ROOT / "src" / "catalog" / "code-map.json").read_text(encoding="utf-8"))
SHEETS = ["Component Set", "Component đơn"]

# Class mac dinh do npx shadcn add sinh ra co mau ngoai theme (khong sua, chi ghi lai).
OFF_THEME = [
    ("CM-040", "dialog.tsx: DialogOverlay bg-black/50"),
    ("CM-041", "alert-dialog.tsx: AlertDialogOverlay bg-black/50"),
    ("CM-098", "sheet.tsx: SheetOverlay bg-black/50"),
    ("CM-099", "drawer.tsx: DrawerOverlay bg-black/50"),
    ("CM-009", "button.tsx: variant destructive dùng text-white (áp cho mọi set Button)"),
    ("CM-031", "badge.tsx: variant destructive dùng text-white (áp cho mọi set Badge)"),
    ("CM-071", "slider.tsx: SliderThumb bg-white"),
    ("CM-116", "chart.tsx: selector Recharts dùng #ccc và #fff (áp cho mọi set Chart CM-116 → CM-121)"),
]


def show(code):
    if code == "FIGMA_ONLY":
        return "Figma-only"
    if code.startswith("NO_PROP"):
        return "(không có prop)"
    return code


def cell_text(entry):
    lines = [entry["code"]]
    for prop, vals in entry["props"].items():
        lines.append("; ".join(f"{prop}={v} → {show(c)}" for v, c in vals.items()))
    if entry["bools"]:
        lines.append("; ".join(f"{b} → {c}" for b, c in entry["bools"].items()))
    for s, sw in entry["swaps"].items():
        lines.append(f"{s} → {sw['code']}")
    return "\n".join(lines)


def shadcn_name(entry):
    return entry["code"].split(" (")[0]


def lech_rows(code, figma, entry):
    rows = []
    for issue, detail, suggest in entry["lech"]:
        rows.append([code, figma, shadcn_name(entry), f"{issue}: {detail}", suggest])
    for prop, vals in entry["props"].items():
        missing = [(v, c.split(":", 1)[1] if ":" in c else "") for v, c in vals.items() if c.startswith("NO_PROP")]
        if not missing:
            continue
        reasons = sorted({r for _, r in missing if r})
        rows.append(
            [
                code,
                figma,
                shadcn_name(entry),
                f"property không có prop tương ứng: {prop} = {', '.join(v for v, _ in missing)}" + (f" ({'; '.join(reasons)})" if reasons else ""),
                entry.get("np_suggest", {}).get(prop)
                or "Catalog hiển thị giá trị mặc định. PD chọn: bỏ giá trị khỏi Figma, giữ ở mức Figma (không giao Dev), hoặc PD Lead bổ sung token rồi Dev ghép ở lớp composed.",
            ]
        )
    return rows


def main(src, dst):
    wb = openpyxl.load_workbook(src)
    figma_by_code = {}
    for sheet in SHEETS:
        ws = wb[sheet]
        header = [c.value for c in ws[1]]
        ci = {h: i + 1 for i, h in enumerate(header)}
        for r in range(2, ws.max_row + 1):
            code = ws.cell(r, ci["Mã"]).value
            if not code or ws.cell(r, ci["Giao Dev"]).value != "Có":
                continue
            figma_by_code[code] = ws.cell(r, ci["Component (Figma)"]).value
            c = ws.cell(r, ci["Tên trong code"])
            c.value = cell_text(CODE_MAP[code])
            c.alignment = Alignment(wrap_text=True, vertical="top")

    rows = []
    for code, entry in CODE_MAP.items():
        rows.extend(lech_rows(code, figma_by_code[code], entry))
    for code, detail in OFF_THEME:
        rows.append([code, figma_by_code[code], shadcn_name(CODE_MAP[code]), f"class mặc định ngoài theme: {detail}", "Không sửa source shadcn. PD Lead quyết định có bổ sung token overlay/foreground-on-destructive vào theme hay chấp nhận."])
    order = {c: i for i, c in enumerate(CODE_MAP)}
    rows.sort(key=lambda x: order[x[0]])

    if "Bảng lệch" in wb.sheetnames:
        del wb["Bảng lệch"]
    ws = wb.create_sheet("Bảng lệch")
    ws.append(["Mã", "Component (Figma)", "Tên trong shadcn", "Vấn đề", "Đề xuất"])
    for r in rows:
        ws.append(r)
    for c in ws[1]:
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="EEEEEE")
    for col, w in zip("ABCDE", [10, 26, 34, 80, 60]):
        ws.column_dimensions[col].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "A2"
    wb.save(dst)

    md = ["| Mã | Component (Figma) | Tên trong shadcn | Vấn đề | Đề xuất |", "|---|---|---|---|---|"]
    md += ["| " + " | ".join(str(x).replace("|", "/").replace("\n", " ") for x in r) + " |" for r in rows]
    (ROOT / "docs" / "Bang_lech.md").write_text("# Bảng lệch\n\nSinh bởi scripts/fill_map.py từ src/catalog/code-map.json.\n\n" + "\n".join(md) + "\n", encoding="utf-8")
    print(f"Da dien {len(figma_by_code)} dong, Bang lech {len(rows)} dong -> {dst}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
