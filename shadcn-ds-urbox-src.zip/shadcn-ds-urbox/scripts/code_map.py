#!/usr/bin/env python3
"""Nguon duy nhat cho cot "Ten trong code" va Bang lech.

Moi dong Giao Dev = Co trong Map co mot muc o day:
  code   : component (hoac phan con kem prop co dinh) trong repo
  props  : {Property Figma: {Gia tri Figma: anh xa}}
  bools  : {Boolean Figma: anh xa}
  swaps  : {Instance swap Figma: (anh xa, lua chon render)}
  lech   : cac dong Bang lech muc set (khong tinh lech theo gia tri, phan do tu sinh)

Quy uoc anh xa:
  'variant="outline"'   prop tuong ung trong code
  'children: ...'       ghep bang children/phan con, khong phai lech
  FO                    Figma-only (trang thai tuong tac), khong render
  NP("ly do")           khong co prop tuong ung -> vao Bang lech, render mac dinh
Ten property/gia tri so khong phan biet hoa/thuong (quy tac cua Map).

Chay: python3 scripts/code_map.py  -> src/catalog/code-map.json
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SPEC = ROOT / "src" / "catalog" / "map.generated.json"
OUT = ROOT / "src" / "catalog" / "code-map.json"

FO = "FIGMA_ONLY"


def NP(reason=""):
    return "NO_PROP" + (":" + reason if reason else "")


DEF = "(mặc định)"

# ---------------------------------------------------------------- Button
SIZE_BTN = {"xs": 'size="xs"', "sm": 'size="sm"', "md": 'size="default"', "lg": 'size="lg"'}
SIZE_ICON = {"xs": 'size="icon-xs"', "sm": 'size="icon-sm"', "md": 'size="icon"', "lg": 'size="icon-lg"'}
STATE_BTN = {
    "enabled": DEF,
    "disabled": "disabled",
    "invalid": 'aria-invalid="true"',
    "hover": FO,
    "active": FO,
    "focus": FO,
}
COLORS = ["primary", "secondary", "destructive", "success", "warning", "info"]
# Mau success/warning/info: token bo sung (src/styles/urbox-status-tokens.css) + tone() trong src/components/composed/tone.ts.
STYLE_SOLID = {
    "primary": 'variant="default"',
    "secondary": 'variant="secondary"',
    "destructive": 'variant="destructive"',
    "info": 'className={tone("solid", "info")}',
    "success": 'className={tone("solid", "success")}',
    "warning": 'className={tone("solid", "warning")}',
}


def style_tone(app):
    return {c: f'className={{tone("{app}", "{c}")}}' for c in COLORS}


BTN_BOOLS = {
    "Show Badge": "children: <Badge>",
    "Left Icon": "children: icon lucide-react trước nhãn",
    "Right Icon": "children: icon lucide-react sau nhãn",
    "Show KBD": "children: <Kbd>",
    "Show Spinner": "children: <Spinner>",
}
BTN_SWAPS = {
    "Icon (Left)": ("children: icon lucide-react (mặc định HeartIcon)", "star"),
    "Icon (Right)": ("children: icon lucide-react (mặc định HeartIcon)", "star"),
}
ICON_SWAP = {"Icon": ("children: icon lucide-react (mặc định HeartIcon)", "star")}


def button_set(code, style, icon, lech=None):
    return {
        "code": code,
        "props": {"style": style, "size": SIZE_ICON if icon else SIZE_BTN, "state": STATE_BTN},
        "bools": {} if icon else BTN_BOOLS,
        "swaps": ICON_SWAP if icon else BTN_SWAPS,
        "lech": lech or [],
    }


GRADIENT_LECH = [("property không có prop tương ứng", "Hiệu ứng Gradient không có variant trong Button và theme không có token gradient. Repo hiển thị màu theo Solid (variant + tone solid), không có gradient.", "Đã chốt 05/11/2026: bỏ Gradient khỏi phạm vi Portal. Gradient cạnh tranh với Solid primary làm mờ thứ bậc hành động chính, và không có token để giữ nhất quán Light/Dark. PD: đặt Giao Dev = Không cho CM-002 và CM-008 ở Map v1.1, thay instance Gradient trên màn bằng Solid. Dev: chạy lại map:spec, khối Gradient tự biến mất.")]

M = {}
M["CM-001"] = {
    "code": "ButtonGroup",
    "props": {
        "style": {"primary": 'variant="default" trên Button con', "Outline": 'variant="outline" trên Button con', "Secondary": 'variant="secondary" trên Button con'},
        "size": {k: v + " trên Button con" for k, v in SIZE_BTN.items()},
        "Flow": {"Horizontal": 'orientation="horizontal"', "Vertical": 'orientation="vertical"'},
    },
}
M["CM-002"] = button_set('Button size="icon"', STYLE_SOLID, True, GRADIENT_LECH)
M["CM-003"] = button_set('Button size="icon"', STYLE_SOLID, True)
M["CM-004"] = button_set('Button variant="ghost" size="icon" + className={tone("soft", màu)}', style_tone("soft"), True)
M["CM-005"] = button_set('Button variant="outline" size="icon" + className={tone("outline", màu)}', style_tone("outline"), True)
M["CM-006"] = button_set('Button variant="ghost" size="icon" + className={tone("ghost", màu)}', style_tone("ghost"), True)
M["CM-007"] = button_set('Button variant="link" size="icon" + className={tone("link", màu)}', style_tone("link"), True)
M["CM-008"] = button_set("Button", STYLE_SOLID, False, GRADIENT_LECH)
M["CM-009"] = button_set("Button", STYLE_SOLID, False)
M["CM-010"] = button_set('Button variant="ghost" + className={tone("soft", màu)}', style_tone("soft"), False)
M["CM-011"] = button_set('Button variant="outline" + className={tone("outline", màu)}', style_tone("outline"), False)
M["CM-012"] = button_set('Button variant="ghost" + className={tone("ghost", màu)}', style_tone("ghost"), False)
M["CM-013"] = button_set('Button variant="link" + className={tone("link", màu)}', style_tone("link"), False)

# ---------------------------------------------------------------- Accordion
FONT3 = {"SM": DEF + " text-sm", "MD": NP("không có prop cỡ chữ"), "LG": NP("không có prop cỡ chữ")}
M["CM-023"] = {
    "code": "AccordionItem",
    "props": {"Opened": {"Close": DEF + " Accordion value không chứa item", "Open": "Accordion value chứa value của item", "Close disable": "disabled", "Open disable": "disabled + Accordion value chứa item"}},
    "bools": {"Subtitle": "children: dòng phụ trong AccordionTrigger", "Avatar": "children: <Avatar> trong AccordionTrigger", "Left Icon": "children: icon trong AccordionTrigger"},
}
M["CM-024"] = {"code": "AccordionTrigger", "props": {"Font Size": FONT3}}
M["CM-025"] = {"code": "AccordionContent", "props": {"Font Size": FONT3}}
M["CM-026"] = {"code": "AccordionTrigger (ChevronDownIcon có sẵn)", "props": {"Icon Size": {"SM": DEF + " size-4", "MD": NP("không có prop cỡ icon"), "LG": NP("không có prop cỡ icon")}}}
M["CM-027"] = {
    "code": "Accordion",
    "props": {"Variants": {
        "Split": NP("không có kiểu tách rời từng item"),
        "Multi icons": "children: icon trong mỗi AccordionTrigger",
        "Basic": 'type="single" collapsible',
        "Multiple": 'type="multiple"',
        "With borders": NP("không có kiểu viền bao"),
        "In card": "children: Accordion đặt trong <Card>",
        "With disabled": "children: AccordionItem disabled",
    }},
}
# ---------------------------------------------------------------- Avatar
M["CM-028"] = {
    "code": "Avatar",
    "props": {
        "Size": {"sm": 'size="sm"', "md": 'size="default"', "lg": 'size="lg"'},
        "Shape": {"Rounded": NP("Avatar luôn rounded-full"), "Circle": DEF + " rounded-full"},
        "Type": {"Image": "children: <AvatarImage>", "Placeholder Initials": "children: <AvatarFallback> chữ viết tắt", "Placeholder Icon": "children: <AvatarFallback> icon"},
        "Indicator": {"False": DEF, "True": "children: <AvatarBadge>"},
    },
}
M["CM-029"] = {
    "code": "StatusIndicator (src/components/composed, ghép từ AvatarBadge; online=success, away=warning, busy=destructive)",
    "props": {"Type": {"Online": 'type="online"', "Away": 'type="away"', "Busy": 'type="busy"', "Offline": 'type="offline"', "Primary": 'type="primary"'}},
    "bools": {"Indicator Icon": "children: icon"},
    "swaps": {"Icon": ("children: icon lucide-react (mặc định PlusIcon)", "check")},
    "lech": [("không có trong shadcn/ui", "Ghép từ AvatarBadge trong src/components/composed/status-indicator.tsx, màu theo token success/warning/destructive.", "Giữ ở lớp composed.")],
}
M["CM-030"] = {
    "code": "AvatarGroup (+ AvatarGroupCount)",
    "props": {"Variants": {"Icon": "children: <Avatar> với AvatarFallback icon", "Image": "children: <Avatar> với AvatarImage", "Numbers": "children: <AvatarGroupCount>"}},
    "lech": [("tên khác", "Map ghi Loại = Không có trong shadcn/ui nhưng shadcn/ui new-york-v4 đã có AvatarGroup và AvatarGroupCount (trong avatar.tsx). Repo dùng thẳng AvatarGroup, không ghép riêng.", "Đổi Loại thành Khớp shadcn; tên Figma 'Avatar group' viết PascalCase đã khớp AvatarGroup.")],
}
# ---------------------------------------------------------------- Badge
BADGE_STYLE = {
    "Primary": 'variant="default"',
    "Secondary": 'variant="secondary"',
    "Destructive": 'variant="destructive"',
    "Info": 'className={badgeTone("solid", "info")}',
    "Success": 'className={badgeTone("solid", "success")}',
    "Warning": 'className={badgeTone("solid", "warning")}',
}
BADGE_SIZE = {"sm": DEF, "md": NP("Badge không có prop size"), "lg": NP("Badge không có prop size")}
BADGE_BOOLS = {"Left Icon": "children: icon trước nhãn", "Closable": "children: icon XIcon sau nhãn", "Avatar": "children: <Avatar size=\"sm\">", "Spinner": "children: <Spinner>"}


def badge_tone(app):
    return {c.capitalize(): f'className={{badgeTone("{app}", "{c}")}}' for c in COLORS}


M["CM-031"] = {"code": "Badge", "props": {"Style": BADGE_STYLE, "Size": BADGE_SIZE}, "bools": BADGE_BOOLS}
M["CM-032"] = {"code": 'Badge variant="outline" + className={badgeTone("soft", màu)}', "props": {"Style": badge_tone("soft"), "Size": BADGE_SIZE}, "bools": BADGE_BOOLS}
M["CM-033"] = {"code": 'Badge variant="outline" + className={badgeTone("outline", màu)}', "props": {"Style": badge_tone("outline"), "Size": BADGE_SIZE}, "bools": BADGE_BOOLS}
DOT = {c.capitalize(): f"children: chấm bg-{c}" for c in COLORS}
M["CM-034"] = {"code": 'Badge variant="outline" + chấm màu', "props": {"Style": DOT}, "bools": {"Left Icon": "children: chấm màu trước nhãn"}}
M["CM-035"] = {"code": 'Badge variant="outline" + className={badgeTone("outline", màu)} + icon', "props": {"Variants": {
    "Info": 'className={badgeTone("outline", "info")} + <InfoIcon>', "Warning": 'className={badgeTone("outline", "warning")} + <TriangleAlertIcon>',
    "Destructive": 'className={badgeTone("outline", "destructive")} + <OctagonXIcon>', "Success": 'className={badgeTone("outline", "success")} + <CircleCheckIcon>'}}}
M["CM-036"] = {"code": 'Badge variant="outline" + className={badgeTone("soft", màu)} + chấm màu', "props": {"Variants": {
    c.capitalize(): f'className={{badgeTone("soft", "{c}")}} + chấm bg-{c}' for c in ["destructive", "info", "success", "warning"]}}}
# ---------------------------------------------------------------- Card, Dialog
M["CM-039"] = {"code": "Card", "props": {"Variant": {
    "Default": "children: CardHeader + CardContent + CardFooter", "Default Small": NP("Card không có prop size"),
    "With Image": "children: ảnh đầu Card", "Login": "children: form đăng nhập (Field, Input, Button)", "Meeting Notes": "children: danh sách ghi chú"}}}
M["CM-040"] = {"code": "Dialog (data-ds trên DialogContent)", "props": {"Variant": {
    "Default": "children: DialogHeader + DialogFooter", "With Content": "children: nội dung form trong DialogContent",
    "No Close Button": "showCloseButton={false} trên DialogContent", "With Image": "children: ảnh trong DialogContent"}},
    "bools": {"Closable": "showCloseButton trên DialogContent", "Footer": "children: <DialogFooter>"}}
M["CM-041"] = {"code": "AlertDialog (data-ds trên AlertDialogContent)", "props": {"Variant": {
    "Default": DEF + ' size="default"', "Default Small": 'size="sm" trên AlertDialogContent',
    "Destructive": 'AlertDialogAction variant="destructive"', "Destructive Small": 'size="sm" + AlertDialogAction variant="destructive"'}},
    "bools": {"Icon": "children: <AlertDialogMedia> icon", "Show Avatar": "children: <AlertDialogMedia> <Avatar>"}}
M["CM-042"] = {"code": "Collapsible", "props": {"Type": {
    "Default": "children: CollapsibleTrigger + CollapsibleContent", "File Tree": "children: cây thư mục lồng Collapsible",
    "Setting Panel": "children: nhóm cài đặt (Switch) trong CollapsibleContent", "Basic": "children: một dòng trigger + nội dung"}}}
M["CM-043"] = {"code": "Carousel", "props": {"Variant": {
    "Single box carousel": DEF + " CarouselItem basis-full", "Three box carousel": 'CarouselItem className="basis-1/3"',
    "Two box carousel": 'CarouselItem className="basis-1/2"', "Vertical carousel": 'orientation="vertical"'}}}
M["CM-044"] = {"code": "Pagination", "props": {"Variant": {
    "Basic": "children: PaginationPrevious + PaginationLink + PaginationEllipsis + PaginationNext",
    "Simple": "children: PaginationPrevious + nhãn trang + PaginationNext", "With select": "children: <Select> số dòng + Pagination"}}}
M["CM-045"] = {"code": "PaginationLink", "props": {
    "size": {"xs": 'size="icon-xs"', "sm": 'size="icon-sm"', "md": 'size="icon"', "lg": 'size="icon-lg"'},
    "Variants": {"Default": "isActive={false} (ghost)", "Solid": NP("PaginationLink không có kiểu nền đặc"), "Outlined": "isActive (outline)"},
    "Shape": {"Square": DEF + " rounded-md", "Rounded": NP("PaginationLink không có prop bo tròn")}}}
M["CM-046"] = {"code": "BreadcrumbItem / BreadcrumbLink", "props": {"Variant": {
    "Active link": "<BreadcrumbPage>", "Ghost icon button": 'BreadcrumbLink asChild + Button variant="ghost" size="icon-sm"',
    "Icon placeholder": "<BreadcrumbEllipsis>", "Link": "<BreadcrumbLink>"}}}
M["CM-047"] = {"code": "BreadcrumbSeparator", "props": {"Variant": {"Chevron": DEF + " ChevronRightIcon", "Dot": "children: dấu chấm", "Slash": "children: <SlashIcon>"}}}
M["CM-048"] = {"code": "Breadcrumb", "props": {"Style": {
    "Default": "children: BreadcrumbList + BreadcrumbItem + BreadcrumbSeparator", "With dot": "children: BreadcrumbSeparator dấu chấm",
    "With dropdown": "children: <DropdownMenu> trong BreadcrumbItem", "With link": "children: BreadcrumbLink cho mọi cấp",
    "Custom Separator": "children: BreadcrumbSeparator <SlashIcon>", "Dropdown": "children: BreadcrumbEllipsis mở DropdownMenu",
    "With Badge": "children: <Badge> trong BreadcrumbItem", "Outline Badge": 'children: <Badge variant="outline">',
    "Mix": "children: icon + Badge + Ellipsis", "With Ring": NP("không có kiểu viền ring"), "Badge with icon": "children: <Badge> có icon",
    "With Dropdown": "children: <DropdownMenu> trong BreadcrumbItem"}},
    "lech": [("property không có prop tương ứng", "Style có hai giá trị chỉ khác hoa/thường: 'With dropdown' và 'With Dropdown'. Theo quy tắc so sánh không phân biệt hoa/thường thì đây là giá trị trùng.", "PD gộp hoặc đổi tên một trong hai variant trong Figma.")]}
# ---------------------------------------------------------------- Alert
def alert_v(app):
    d = {"Default": f'variant="default" + className={{alertTone("{app}", "neutral")}}', "Destructive": f'variant="destructive" + className={{alertTone("{app}", "destructive")}}'}
    for c in ["Info", "Success", "Warning"]:
        d[c] = f'className={{alertTone("{app}", "{c.lower()}")}}'
    d["Amber"] = f'className={{alertTone("{app}", "warning")}} (trùng Warning)'
    return d


AMBER_LECH = ("property không có prop tương ứng", "Variants có cả Warning và Amber; theme chỉ có một token warning nên hai giá trị hiển thị giống nhau.", "Đã chốt 05/11/2026: gộp Amber vào Warning. Hai màu cảnh báo gần nhau không mang hai nghĩa khác nhau cho người dùng. PD: xoá giá trị Amber khỏi Alert Outline/Solid/Soft, đổi instance Amber thành Warning. Trong code Amber đang map sang warning nên không cần sửa.")
ALERT_B = {"Show Actions": "children: <Button> hành động", "Close Icon": 'children: <Button variant="ghost" size="icon-xs"> XIcon',
           "Left Icon": "children: icon đầu Alert", "Show Title": "children: <AlertTitle>", "Show Description": "children: <AlertDescription>",
           "Avatar": "children: <Avatar>", "Show Badge": "children: <Badge>", "Badge": "children: <Badge>"}
M["CM-049"] = {"code": 'Alert + className={alertTone("outline", màu)}', "props": {"Variants": alert_v("outline")}, "bools": ALERT_B, "lech": [AMBER_LECH]}
M["CM-050"] = {"code": 'Alert + className={alertTone("solid", màu)}', "props": {"Variants": alert_v("solid")}, "bools": ALERT_B, "lech": [AMBER_LECH]}
M["CM-051"] = {"code": 'Alert + className={alertTone("soft", màu)}', "props": {"Variants": alert_v("soft")}, "bools": ALERT_B, "lech": [AMBER_LECH]}
# ---------------------------------------------------------------- Item, Tabs, Steps
M["CM-053"] = {"code": "Item", "props": {
    "Variants": {"Outline": 'variant="outline"', "Muted": 'variant="muted"', "Default": 'variant="default"'},
    "Size": {"Default": 'size="default"', "sm": 'size="sm"', "xs": NP("Item chỉ có size default và sm")}},
    "bools": {"Show Actions": "children: <ItemActions>", "Left Icon": 'children: <ItemMedia variant="icon">', "Show Title": "children: <ItemTitle>",
              "Show Description": "children: <ItemDescription>", "Avatar": "children: <ItemMedia> <Avatar>", "Show Badge": "children: <Badge>",
              "Show Media": 'children: <ItemMedia variant="image">', "Show Header": "children: <ItemHeader>", "Right Icon": "children: icon cuối Item"}}
M["CM-054"] = {"code": "TabsTrigger", "props": {
    "size": {"sm": NP("TabsTrigger không có prop size"), "md": DEF, "lg": NP("TabsTrigger không có prop size")},
    "State": {"inactive": DEF + " Tabs value khác value của trigger", "Active": "Tabs value = value của trigger", "disabled": "disabled", "Hover": FO},
    "Style": {"Lifted": NP("TabsList không có kiểu Lifted"), "Boxed": 'variant="default" trên TabsList', "Bordered": NP("TabsList không có kiểu Bordered (chỉ có default và line)")}},
    "bools": {"has_Left_Items": "children: TabsTrigger khác bên trái", "has_Right_Items": "children: TabsTrigger khác bên phải",
              "has_Active_onLeft": "Tabs value = trigger bên trái", "has_Active_onRight": "Tabs value = trigger bên phải",
              "Has Icon": "children: icon trong TabsTrigger", "text": "children: nhãn trong TabsTrigger"}}
STEP_LECH = [("không có trong shadcn/ui", "Stepper không có trong shadcn/ui. Repo ghép từ Button, Separator trong src/components/composed/steps.tsx.", "Giữ ở lớp composed; Code Connect map tới Steps/StepItem.")]
M["CM-057"] = {"code": "StepItem (src/components/composed/steps.tsx)", "props": {
    "Position": {"Start": 'position="start"', "Middle": 'position="middle"'},
    "isActive": {"False": "active={false}", "True": "active"},
    "Orientation": {"Horizontal": 'orientation="horizontal"', "Vertical": 'orientation="vertical"'},
    "Step bullet type": {"Text": 'bullet="text"', "Icon": 'bullet="icon"'},
    "Shape": {"Rounded": 'shape="rounded"', "Round": 'shape="round"'}},
    "bools": {"Icon": "children: icon trong bullet", "Subtext": 'description="..."'}, "lech": STEP_LECH}
M["CM-058"] = {"code": 'Steps orientation="horizontal" (src/components/composed/steps.tsx)', "props": {"Shape": {"Rounded": 'shape="rounded"', "Round": 'shape="round"'}}, "lech": STEP_LECH}
M["CM-059"] = {"code": 'Steps orientation="vertical" (src/components/composed/steps.tsx)', "props": {"Shape": {"Rounded": 'shape="rounded"', "Round": 'shape="round"'}}, "lech": STEP_LECH}
# ---------------------------------------------------------------- Tooltip, Progress, form controls
TIP_NP = NP("TooltipContent không có variant màu; mũi tên cố định bg-foreground trong source shadcn nên đổi nền bằng className sẽ lệch màu mũi tên")
M["CM-060"] = {"code": "Tooltip (data-ds trên TooltipContent)", "props": {
    "Style": {"Primary": DEF + " bg-foreground", "Info": TIP_NP, "Success": TIP_NP, "Warning": TIP_NP, "destructive": TIP_NP, "Secondary": TIP_NP},
    "Position": {"Top": 'side="top"', "Bottom": 'side="bottom"', "Left": 'side="left"', "Right": 'side="right"', "None": NP("TooltipContent luôn có mũi tên")},
    "Shape": {"Default": DEF, "Rounded": NP("TooltipContent không có prop bo góc")},
    "Type": {"Basic": DEF}},
    "bools": {"Show Subtext": "children: dòng phụ", "Show icon": "children: icon", "Avatar": "children: <Avatar>", "Kbd for Tooltip": "children: <Kbd>", "Show Title": "children: tiêu đề"},
    "swaps": {"icon": ("children: icon lucide-react (mặc định ContactIcon)", "info")},
    "np_suggest": {"Style": "Đã chốt 05/11/2026: Tooltip chỉ giữ Style=Primary. Tooltip là chú thích phụ, không mang trạng thái; màu trạng thái dùng Alert, Badge hoặc Sonner. PD: xoá Style Info/Success/Warning/destructive/Secondary khỏi set Tooltip."}}
M["CM-062"] = {"code": "Progress", "props": {
    "Variants": {"0%": "value={0}", "25%": "value={25}", "50%": "value={50}", "75%": "value={75}", "100%": "value={100}"},
    "Size": {"sm": DEF + " h-2", "md": NP("Progress không có prop size"), "lg": NP("Progress không có prop size")}},
    "bools": {"Top label": "children: nhãn phía trên (Field + FieldLabel)"}}
SIZE3 = lambda comp: {"sm": DEF, "md": NP(f"{comp} không có prop size"), "lg": NP(f"{comp} không có prop size")}
COLOR6 = lambda ctrl, keys: {k: (DEF if k.lower() == "primary" else f'className={{controlTone("{ctrl}", "{k.lower()}")}}') for k in keys}
M["CM-064"] = {"code": "Checkbox (data-ds trên Field bọc ngoài)", "props": {
    "Size": SIZE3("Checkbox"), "Variant": COLOR6("checkbox", ["Primary", "Secondary", "Info", "Success", "Warning", "destructive"]),
    "State": {"default": DEF, "focus": FO, "disabled": "disabled", "invalid": 'aria-invalid="true"', "indeterminate": 'checked="indeterminate"'},
    "Status": {"Checked": "checked", "Unchecked": "checked={false}"}},
    "bools": {"Show Label": "children: <Field> + <FieldLabel>", "Show Description Text": "children: <FieldDescription>"}}
M["CM-065"] = {"code": "RadioGroupItem (data-ds trên Field bọc ngoài)", "props": {
    "Status": {"Unchecked": DEF + " RadioGroup value khác", "Checked": "RadioGroup value = value của item"},
    "Size": SIZE3("RadioGroupItem"), "Variant": COLOR6("radio", ["Primary", "Secondary", "Success", "Info", "Destructive", "Warning"]),
    "State": {"Default": DEF, "Focus": FO, "Disabled": "disabled", "invalid": 'aria-invalid="true"'}},
    "bools": {"Label": "children: <FieldLabel>", "sub label": "children: <FieldDescription>"}}
M["CM-067"] = {"code": "Switch (data-ds trên Field bọc ngoài)", "props": {
    "State": {"Default": DEF, "Focus": FO, "Invalid": 'aria-invalid="true"', "Disabled": "disabled"},
    "Size": {"sm": 'size="sm"', "md": 'size="default"', "lg": NP("Switch chỉ có size sm và default")},
    "ON/OFF": {"Off": "checked={false}", "On": "checked"},
    "Style": {"Outline": NP("Switch không có kiểu Outline"), "Solid": DEF},
    "Variant": COLOR6("switch", ["primary", "warning", "secondary", "info", "success", "destructive"])},
    "bools": {"Show Right Label": "children: <FieldLabel> bên phải", "With Icon": "children: icon trong nhãn", "Show Right Description": "children: <FieldDescription> bên phải",
              "Show Left Side Content": "children: <FieldContent> bên trái", "Show Left Label": "children: <FieldLabel> bên trái", "Show Left Description": "children: <FieldDescription> bên trái"}}
M["CM-069"] = {"code": "Rating (src/components/composed/rating.tsx, ghép từ Toggle)", "props": {
    "Size": {"sm": 'size="sm"', "md": 'size="default"', "lg": 'size="lg"'},
    "Filled": {"False": "value={0}", "True": "value={5}"},
    "Type": {"Star": 'icon="star"', "Heart": 'icon="heart"'},
    "Colors": {"Primary": 'color="primary"', "Warning": 'color="warning"', "Destructive": 'color="destructive"'}},
    "lech": [("không có trong shadcn/ui", "Rating không có trong shadcn/ui. Repo ghép từ Toggle trong src/components/composed/rating.tsx.", "Giữ ở lớp composed.")]}
M["CM-071"] = {"code": "Slider (data-ds trên Field bọc ngoài)", "props": {
    "Variant": {"Basic": "defaultValue={[50]}", "Range": "defaultValue={[25, 75]}", "Multiple thumbs": "defaultValue={[20, 50, 80]}"},
    "Style": {"Empty": "value={[0]}", "Half-Full": "value={[50]}", "Full": "value={[100]}"},
    "Size": SIZE3("Slider"), "State": {"default": DEF, "disabled": "disabled", "focus": FO}},
    "bools": {"Show top": "children: nhãn và giá trị phía trên (Field)", "Sub label": "children: <FieldDescription>", "Label": "children: <FieldLabel>"}}
FIELD_BOOLS = {"Show Bottom": "children: dòng dưới (FieldDescription)", "- Bottom Left label": "children: <FieldDescription> trái",
               "Show Top": "children: dòng trên (FieldLabel)", "- Bottom Right label": "children: chữ phải dòng dưới",
               "- Top Right label": "children: chữ phải dòng trên", "- Label": "children: <FieldLabel>"}
SIZE4_INPUT = {"xs": NP("Input không có prop size"), "sm": NP("Input không có prop size"), "md": DEF + " h-9", "lg": NP("Input không có prop size")}
M["CM-072"] = {"code": "Input (data-ds trên Field bọc ngoài)", "props": {
    "Size": SIZE4_INPUT, "Filled": {"No": DEF + " placeholder", "Yes": "value"},
    "State": {"Default": DEF, "Focus": FO, "Invalid": 'aria-invalid="true"', "Disabled": "disabled"}},
    "bools": {**FIELD_BOOLS, "Left-icon": "children: InputGroup + InputGroupAddon icon trái", "Right-icon": 'children: InputGroupAddon align="inline-end" icon', "Badge": "children: <Badge> trong InputGroupAddon"},
    "swaps": {"Icon (Left)": ("children: icon lucide-react (mặc định UserIcon)", "mail"), "Icon (Right)": ("children: icon lucide-react (mặc định EyeOffIcon)", "eye")}}
M["CM-073"] = {"code": "InputGroup", "props": {"Variant": {
    "Default Input": "children: <InputGroupInput>", "Input Group": "children: InputGroupAddon + InputGroupText",
    "Text Link Input": 'children: <InputGroupText> tiền tố "https://"', "Dropdown Input": "children: InputGroupAddon + <DropdownMenu>",
    "With Button": "children: <InputGroupButton>", "With Icon Button": 'children: <InputGroupButton size="icon-xs">',
    "With Kbd": "children: <Kbd> trong InputGroupAddon", "With Spinner": "children: <Spinner> trong InputGroupAddon",
    "Textarea with Button": "children: <InputGroupTextarea> + InputGroupButton"}}}
M["CM-074"] = {"code": "Select (data-ds trên Field bọc ngoài; SelectTrigger nhận size)", "props": {
    "Size": {"xs": NP("SelectTrigger chỉ có size sm và default"), "sm": 'size="sm" trên SelectTrigger', "md": 'size="default" trên SelectTrigger', "lg": NP("SelectTrigger chỉ có size sm và default")},
    "State": {"Default": DEF, "Focus": FO, "Invalid": 'aria-invalid="true" trên SelectTrigger', "Disabled": "disabled"},
    "Filled": {"No": DEF + " SelectValue placeholder", "Yes": "value"}},
    "bools": {**FIELD_BOOLS, "Left Icon": "children: icon trong SelectTrigger", "Avatar": "children: <Avatar> trong SelectTrigger"}}
M["CM-075"] = {"code": "InputOTP (data-ds trên thẻ bọc ngoài)", "props": {"Variants": {"Default": "children: một InputOTPGroup 6 InputOTPSlot", "With Separator 123456": "children: 2 InputOTPGroup + <InputOTPSeparator>"}}}
M["CM-076"] = {"code": "InputOTPSlot", "props": {
    "State": {"Default": DEF, "Active": FO, "Invalid": 'aria-invalid="true" trên InputOTPSlot'},
    "Size": {"lg": NP("InputOTPSlot không có prop size"), "md": DEF + " size-9", "sm": NP("InputOTPSlot không có prop size"), "xs": NP("InputOTPSlot không có prop size")}}}
M["CM-077"] = {"code": 'Input type="file"', "props": {
    "size": {"sm": NP("Input không có prop size"), "md": DEF, "lg": NP("Input không có prop size")},
    "File added": {"False": DEF, "True": NP("tên file đã chọn là trạng thái runtime của trình duyệt, không đặt được bằng prop")},
    "isDisabled": {"False": DEF, "True": "disabled"}}}
M["CM-078"] = {"code": "Textarea (data-ds trên Field bọc ngoài)", "props": {
    "Filled": {"No": DEF + " placeholder", "Yes": "value"},
    "State": {"Default": DEF, "Focus": FO, "Invalid": 'aria-invalid="true"', "Disabled": "disabled"}},
    "bools": {**FIELD_BOOLS, "Badge": "children: <Badge> dòng trên"}}
M["CM-079"] = {"code": "DropdownMenuItem", "props": {"State": {"Default": DEF, "Hover": FO, "Disabled": "disabled", "Destructive Hover": 'variant="destructive" (hover là Figma-only)'}},
    "bools": {"Right Icon": "children: icon cuối", "Left Icon": "children: icon đầu", "Shortcuts": "children: <DropdownMenuShortcut>", "Avatar": "children: <Avatar size=\"sm\">",
              "Checkbox": "dùng DropdownMenuCheckboxItem thay DropdownMenuItem", "Badge": "children: <Badge>", "Show Description": "children: dòng mô tả", "switch": "children: <Switch size=\"sm\">"}}
M["CM-080"] = {"code": "DropdownMenu (data-ds trên DropdownMenuContent)", "props": {"Variant": {
    "Default": "children: DropdownMenuItem", "Complex Menu": "children: Label, Group, Sub, CheckboxItem, RadioItem, Separator, Shortcut"}}}
M["CM-081"] = {"code": "InputNumber (src/components/composed/input-number.tsx, ghép từ InputGroup + InputGroupButton; data-ds trên Field bọc ngoài)", "props": {
    "Variant": {"Horizontal Stretched Button": 'layout="stretched"', "Horizontally Stacked Button": 'layout="stacked-horizontal"',
                "Vertically Stacked Buttons": 'layout="stacked-vertical"', "Mini": 'layout="mini"', "Default": 'layout="default"'},
    "Filled": {"Yes": "value", "No": DEF + " placeholder"}, "State": {"Focus": FO, "Disabled": "disabled", "Default": DEF, "Invalid": 'aria-invalid="true"'},
    "Size": {"sm": NP("InputGroup không có prop size"), "md": DEF, "lg": NP("InputGroup không có prop size")}},
    "bools": {"Show Top": "children: <FieldLabel>", "Show Bottom": "children: <FieldDescription>"},
    "lech": [("không có trong shadcn/ui", "Input Number không có trong shadcn/ui. Repo ghép từ InputGroup trong src/components/composed/input-number.tsx.", "Giữ ở lớp composed.")]}
M["CM-082"] = {"code": "Popover (data-ds trên PopoverContent)", "props": {"Variant": {
    "Basic": "children: tiêu đề + mô tả", "With form": "children: Field + Input + Button", "Multiple input": "children: nhiều Field + Input"}}}
M["CM-083"] = {"code": "Timeline (src/components/composed/timeline.tsx)", "props": {"Variants": {
    "Basic Timeline": 'variant="basic"', "Timeline with icon": 'variant="icon"', "Centered Timeline": 'variant="centered"'}},
    "bools": {"Show Text Inline": "inline"},
    "lech": [("không có trong shadcn/ui", "Timeline không có trong shadcn/ui. Repo ghép từ Badge, Separator trong src/components/composed/timeline.tsx.", "Giữ ở lớp composed.")]}
M["CM-084"] = {"code": "FormWizard (src/components/composed/form-wizard.tsx, ghép từ Steps + Card + Button)", "props": {"Type": {
    "Form Wizard Horizontal": 'orientation="horizontal"', "Form Wizard Vertical": 'orientation="vertical"'}},
    "bools": {"Icon": "children: icon trong bullet", "Text": "children: nhãn bước", "Subtitle": "children: mô tả bước"},
    "lech": [("không có trong shadcn/ui", "Form Wizard không có trong shadcn/ui. Repo ghép từ Steps, Card, Button.", "Giữ ở lớp composed.")]}
M["CM-085"] = {"code": "Calendar", "props": {"Variants": {
    "Multiple": 'mode="multiple"', "Range": 'mode="range"', "Single": 'mode="single"', "Week numbers": "showWeekNumber",
    "Booked dates": "modifiers={{ booked }} + disabled", "Range multiple months": 'mode="range" numberOfMonths={2}',
    "Watch time": 'children: Calendar trong Card + Input type="time"', "With presets": "children: Calendar trong Card + Button preset",
    "Custom days": "components={{ DayButton }} hiển thị giá"}}}
M["CM-086"] = {"code": "DatePicker (src/components/composed/date-picker.tsx, ghép từ Popover + Button + Calendar; data-ds trên Field bọc ngoài)", "props": {
    "State": {"Inactive": "open={false}", "Active": "open"}, "Variant": {"Default": DEF, "Hover": FO, "Focus": FO}},
    "bools": {"Show Top Text": "children: <FieldLabel>", "Show Bottom Text": "children: <FieldDescription>", "Left Icon": "children: CalendarIcon trong Button"},
    "lech": [("không có trong shadcn/ui", "Date Picker là pattern trong docs shadcn, không phải component. Repo ghép từ Popover + Button + Calendar.", "Giữ ở lớp composed.")]}
M["CM-089"] = {"code": "DashboardFooter (src/components/composed/dashboard-footer.tsx)", "props": {"Variant": {
    "Default": 'variant="default"', "With social links": 'variant="social"', "With actions": 'variant="actions"', "With breadcrumb": 'variant="breadcrumb"',
    "With centered logo and pages": 'variant="centered"', "Two footer": 'variant="two-rows"', "Two footer With button": 'variant="two-rows-button"'}},
    "lech": [("không có trong shadcn/ui", "Footer dashboard không có trong shadcn/ui. Repo ghép từ Separator, Button, Breadcrumb.", "Giữ ở lớp composed.")]}
M["CM-091"] = {"code": "MenubarItem", "props": {
    "State": {"default": DEF, "hover": FO, "disabled": "disabled"},
    "Style": {"default": 'variant="default"', "destructive": 'variant="destructive"', "submenu": "dùng MenubarSub + MenubarSubTrigger", "checkbox": "dùng MenubarCheckboxItem"}},
    "bools": {"Left icon": "children: icon đầu", "Short cut": "children: <MenubarShortcut>"}}
M["CM-093"] = {"code": "NavigationMenuLink", "props": {"Variant": {"With Subtext": "children: tiêu đề + mô tả", "With icon": "children: icon + tiêu đề", "Basic": DEF}, "State": {"Default": DEF, "Hover": FO}}}
M["CM-094"] = {"code": "NavigationMenuContent", "props": {"Variant": {
    "Single column list": "children: danh sách 1 cột NavigationMenuLink", "2 column list": "children: lưới 2 cột NavigationMenuLink",
    "Without subtext": "children: NavigationMenuLink chỉ có tiêu đề", "With icon": "children: NavigationMenuLink có icon"}}}
M["CM-095"] = {"code": "Separator", "props": {"Variant": {"Default": 'orientation="horizontal"', "Full width separator": "children: Separator đặt sát mép container (w-full mặc định)"}}}
M["CM-097"] = {"code": "Skeleton", "props": {"Type": {
    "Skeleton Avatar": "children: Skeleton tròn + 2 dòng", "Skeleton Card": "children: khối ảnh + 2 dòng", "Skeleton Text": "children: nhiều dòng",
    "Skeleton Form": "children: nhãn + ô nhập + nút", "Skeleton Table": "children: lưới dòng bảng"}}}
M["CM-098"] = {"code": "Sheet (data-ds trên SheetContent)", "props": {"Type": {
    "Bottom": 'side="bottom"', "Left": 'side="left"', "Open": DEF + ' side="right", trạng thái mở', "Right": 'side="right"', "Top": 'side="top"'}}}
M["CM-099"] = {"code": "Drawer (data-ds trên DrawerContent)", "props": {"Type": {
    "Bottom": 'direction="bottom"', "Left": 'direction="left"', "Right": 'direction="right"', "Chart": "children: biểu đồ trong DrawerContent",
    "Center": NP("Drawer (vaul) không có hướng center"), "Top": 'direction="top"'}}}
M["CM-100"] = {"code": "ScrollArea", "props": {"Type": {"Vertical": DEF + " ScrollBar dọc", "Horizontal": '<ScrollBar orientation="horizontal">'}}}
M["CM-101"] = {"code": "Spinner", "props": {"Size": {"3": 'className="size-3"', "4": DEF + " size-4", "6": 'className="size-6"', "8": 'className="size-8"'}},
    "lech": [("property không có prop tương ứng", "Spinner không có prop size; kích thước đặt bằng className size-* theo docs shadcn.", "Chấp nhận className; Code Connect map Size → className.")]}
M["CM-102"] = {"code": "Toaster + toast() (shadcn đặt tên file sonner.tsx, component là Toaster)", "props": {"Variant": {
    "With icon": "toast.success()", "With subtitle": "toast(…, { description })", "Basic": "toast()", "With action": "toast(…, { action })"}},
    "lech": [("tên khác", "Figma 'Sonner' viết PascalCase là Sonner nhưng component shadcn export là Toaster (file sonner.tsx), toast tạo bằng hàm toast().", "PD đổi tên set thành 'Toaster' hoặc chấp nhận ngoại lệ; Code Connect map Sonner → Toaster.")]}
M["CM-103"] = {"code": "ComboboxInput / ComboboxChips (data-ds trên Field bọc ngoài)", "props": {"Variant": {
    "Combobox multiple invalid with detail": "multiple + ComboboxChips aria-invalid + <FieldError>", "Basic": "<ComboboxInput>",
    "With icon addon": "children: InputGroupAddon icon trong ComboboxInput", "Disabled": "disabled", "Combobox multiple": "multiple + <ComboboxChips>",
    "Combobox multiple (no remove)": "multiple + ComboboxChip showRemove={false}", "Invalid": 'aria-invalid="true"',
    "Invalid with detail": 'aria-invalid="true" + <FieldError>', "Combobox multiple invalid": "multiple + ComboboxChips aria-invalid"}}}
M["CM-104"] = {"code": "ComboboxItem", "props": {
    "Variant": {"With subtext": "children: tiêu đề + mô tả", "simple": DEF, "Label": "dùng <ComboboxLabel>"},
    "State": {"Default": DEF, "Hover": FO, "active": "giá trị đang chọn (Combobox value)"}}}
M["CM-105"] = {"code": "Combobox (data-ds trên thẻ bọc ngoài, Combobox root không render DOM)", "props": {"Variant": {
    "With Groups": "children: ComboboxGroup + ComboboxLabel", "With Groups and Separator": "children: + ComboboxSeparator",
    "With clear button": "showClear trên ComboboxInput", "Disabled Items": "children: ComboboxItem disabled", "Combobox in Popup": "ComboboxTrigger render Button",
    "With Custom Item Rendering": "children: ComboboxItem có Avatar + mô tả", "Combobox Multiple (No Remove)": "multiple + ComboboxChip showRemove={false}",
    "Combobox Multiple": "multiple + ComboboxChips", "Invalid": 'aria-invalid="true"', "Basic": "ComboboxInput + ComboboxContent + ComboboxList"}}}
M["CM-106"] = {"code": "Command", "props": {"Variant": {"Basic": "children: CommandInput + CommandList + CommandGroup + CommandItem", "Inline": "children: Command nhúng trong trang, không viền"}}}
M["CM-107"] = {"code": "Kbd", "props": {"Style": {"Default": DEF, "Primary": NP("Kbd không có variant")}},
    "bools": {"Show icon": "children: icon", "Show Title": "children: chữ phím"}, "swaps": {"icon": ("children: icon lucide-react (mặc định CommandIcon)", "option")}}
M["CM-108"] = {"code": "HoverCard (data-ds trên HoverCardContent)", "props": {"Variants": {"Default": "children: Avatar + tiêu đề", "With sub text": "children: + mô tả"}}}
M["CM-109"] = {"code": "TableHead", "props": {"State": {"Default": DEF, "Hover": FO}}, "bools": {"Checkbox": "children: <Checkbox>", "Title": "children: tiêu đề cột"}}
M["CM-110"] = {"code": "TableCell", "props": {
    "State": {"Default": DEF, "Hover": FO},
    "Variant": {"With Text": "children: chữ", "With Badge": "children: <Badge>", "with avatar": "children: <Avatar>", "Switch": "children: <Switch>",
                "Progress": "children: <Progress>", "Checkbox": "children: <Checkbox>", "Button": "children: <Button>", "Select": "children: <Select>", "with icon": "children: icon"}},
    "bools": {"Title": "children: dòng chính", "Description": "children: dòng phụ"}}
M["CM-111"] = {"code": "SidebarMenuItem (+ SidebarMenuButton)", "props": {
    "Type": {"Default": "children: <SidebarMenuButton>", "With sub item": "children: + <SidebarMenuSub>"},
    "State": {"Default": DEF, "Hover": FO, "Active": "isActive trên SidebarMenuButton"}},
    "bools": {"Left icon": "children: icon trong SidebarMenuButton", "Right icon": "children: icon cuối", "Badge": "children: <SidebarMenuBadge>"}}
M["CM-112"] = {"code": "Sidebar", "props": {"Variant": {"Default": 'variant="sidebar"', "With icon": 'collapsible="icon" (SidebarProvider open={false})', "Inset": 'variant="inset"', "Floating": 'variant="floating"'}}}
M["CM-113"] = {"code": "Toggle", "props": {
    "Type": {"Outline": 'variant="outline"', "Basic": 'variant="default"'},
    "Size": {"Default": 'size="default"', "sm": 'size="sm"', "lg": 'size="lg"'},
    "State": {"Default": DEF, "Disabled": "disabled", "Hover": FO, "Focus": FO}},
    "bools": {"Text": "children: nhãn", "Icon": "children: icon"}}
M["CM-114"] = {"code": "ToggleGroup", "props": {"Variant": {
    "Basic": 'type="single"', "Outline with icons": 'variant="outline" + icon', "With spacing": "spacing={2}", "Vertical with spacing": 'orientation="vertical" spacing={2}',
    "With input and select": "children: ToggleGroup + Input + Select", "Vertical": 'orientation="vertical"', "Vertical outline": 'orientation="vertical" variant="outline"',
    "Vertical outline with icons": 'orientation="vertical" variant="outline" + icon', "Font Weight Selector": "children: ToggleGroupItem theo weight",
    "Outline": 'variant="outline"', "Sort": "children: ToggleGroupItem sắp xếp + icon", "Disabled": "disabled"}}}


M["CM-116"] = {"code": "ChartContainer + Recharts RadarChart", "props": {"Variant": {
    "Legend": "children: <ChartLegend>", "Multiple": "children: 2 <Radar>", "Grid filled": "PolarGrid fill", "Grid circle filled": 'PolarGrid gridType="circle" fill',
    "No lines": "PolarGrid radialLines={false}", "Grid circle": 'PolarGrid gridType="circle"', "Radius axis": "children: <PolarRadiusAxis>", "Icons": "ChartConfig icon + ChartLegend",
    "Dots": "Radar dot", "Lines only": "Radar fillOpacity={0}", "Custom label": "PolarAngleAxis tick tuỳ biến", "Grid custom": "PolarGrid radialLines={false} polarRadius",
    "Grid none": "không có PolarGrid", "basic": "PolarAngleAxis + PolarGrid + Radar"}}}
M["CM-117"] = {"code": "ChartContainer + Recharts AreaChart", "props": {"Type": {
    "Linear": 'Area type="linear"', "Icons": "ChartConfig icon + ChartLegend", "Axes": "children: XAxis + YAxis", "Gradient": "children: <defs> linearGradient",
    "Basic": 'Area type="natural"', "Interactive": "children: Select khoảng thời gian + Area", "Step": 'Area type="step"', "Legend": "children: <ChartLegend>",
    "Stacked": "2 Area stackId", "Stacked expended": 'AreaChart stackOffset="expand"'}}}
M["CM-118"] = {"code": "ChartContainer + Recharts RadialBarChart", "props": {"Type": {
    "Grid": "children: <PolarGrid>", "Label": "RadialBar + LabelList", "Stacked": "2 RadialBar stackId", "Shape": "PolarGrid gridType circle + nền", "Text": "children: Label ở giữa", "Basic": "RadialBar"}}}
M["CM-119"] = {"code": "ChartContainer + Recharts LineChart", "props": {"Type": {
    "Interactive": "children: nút chọn chuỗi + Line", "Label": "Line + LabelList", "Dots colors": "Line dot theo màu từng điểm", "Basic": 'Line type="natural"',
    "Linear": 'Line type="linear"', "Step": 'Line type="step"', "Multiple": "2 <Line>", "Dots": "Line dot", "Custom Dots": "Line dot tuỳ biến (icon)", "Custom Label": "LabelList content tuỳ biến"}}}
M["CM-120"] = {"code": "ChartContainer + Recharts PieChart", "props": {"Type": {
    "Label": "Pie label", "Separator none": "Pie stroke 0", "Legend": "children: <ChartLegend>", "Interactive": "children: Select + Pie activeIndex",
    "Stacked": "2 <Pie> lồng nhau", "Donut With Text": "Pie innerRadius + Label giữa", "Custom label": "Pie label tuỳ biến", "Label list": "Pie + LabelList",
    "Donut": "Pie innerRadius", "Donut Active": "Pie innerRadius + activeIndex", "Basic": "Pie"}}}
M["CM-121"] = {"code": "ChartContainer + Recharts BarChart", "props": {"Type": {
    "Interactive": "children: nút chọn chuỗi + Bar", "Negative": "Bar + Cell màu theo dấu", "Active": "Bar activeIndex", "Stacked + Legend": "2 Bar stackId + ChartLegend",
    "Basic": "Bar", "Horizontal": 'BarChart layout="vertical"', "Multiple": "2 <Bar>", "Label": "Bar + LabelList", "Custom": "Bar + LabelList trong cột", "Mixed": "Bar + Cell nhiều màu"}}}

# ---------------------------------------------------------------- Component don
M["CS-012"] = {"code": "Form (react-hook-form; data-ds trên thẻ <form>, Form là FormProvider không render DOM)"}
M["CS-013"] = {"code": "DropdownMenuLabel"}
M["CS-015"] = {"code": "ContextMenu (data-ds trên ContextMenuContent)"}
M["CS-017"] = {"code": "Menubar"}
M["CS-018"] = {"code": "MenubarContent"}
M["CS-019"] = {"code": "NavigationMenu"}
M["CS-020"] = {"code": "toast() (một toast trong Toaster; data-ds trên thẻ bọc ngoài)", "bools": {"Icon": "toast.success() / icon", "button": "action", "Subtitle": "description"},
               "lech": [("tên khác", "Một toast của Toaster; trùng vai với set Sonner (CM-102) như ghi chú trong Map.", "PD Lead chọn giữ một trong hai (CM-102 hoặc CS-020).")]}
M["CS-021"] = {"code": "ComboboxList"}
M["CS-023"] = {"code": "Table", "bools": {"Footer": "children: <TableFooter>", "Table Caption": "children: <TableCaption>", "Show empty-header": "children: TableHead rỗng đầu dòng"}}
M["CS-024"] = {"code": "SidebarGroup", "bools": {"Label": "children: <SidebarGroupLabel>"}}
M["CS-030"] = {"code": "Field"}

# ---------------------------------------------------------------- build
AUTO_FO = {"hover", "focus", "active", "pressed"}


def find(d, key):
    for k, v in d.items():
        if k.lower() == key.lower():
            return v
    return None


def main():
    spec = json.loads(SPEC.read_text(encoding="utf-8"))
    out = {}
    missing = []
    for row in spec:
        m = M.get(row["id"])
        if m is None:
            missing.append(row["id"])
            continue
        entry = {"code": m["code"], "props": {}, "bools": {}, "swaps": {}, "lech": [list(x) for x in m.get("lech", [])], "np_suggest": m.get("np_suggest", {})}
        for p in row["props"]:
            pm = find(m.get("props", {}), p["name"]) or {}
            entry["props"][p["name"]] = {}
            for v in p["values"]:
                code = find(pm, v)
                if code is None and p["name"].lower() == "state" and v.lower() in AUTO_FO:
                    code = FO
                if code is None:
                    missing.append(f'{row["id"]} {p["name"]}={v}')
                    continue
                entry["props"][p["name"]][v] = code
        for b in row["bools"]:
            code = find(m.get("bools", {}), b["name"])
            if code is None:
                missing.append(f'{row["id"]} bool {b["name"]}')
                continue
            entry["bools"][b["name"]] = code
        for s in row["swaps"]:
            sw = find(m.get("swaps", {}), s["name"])
            if sw is None:
                missing.append(f'{row["id"]} swap {s["name"]}')
                continue
            entry["swaps"][s["name"]] = {"code": sw[0], "option": sw[1]}
        out[row["id"]] = entry
    if missing:
        raise SystemExit("Thieu anh xa:\n  " + "\n  ".join(missing))
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{len(out)} muc -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
