#!/usr/bin/env python3
"""Doi chieu catalog voi Component Map va kiem token.

  python3 scripts/verify.py <Component_Map.xlsx> <catalog-check.json> [<theme goc .css>]

1. So phan tu du kien (tinh doc lap tu Map theo quy tac buoc 7) voi phan tu thuc te
   theo tung data-ds, so ca tap data-ds-props.
2. Moi data-ds tren catalog phai co trong cot data-ds cua Map.
3. Ngoai src/components/ui (do npx shadcn add sinh ra), src khong co ma mau hex/rgb/hsl/oklch
   hay bien CSS ngoai file theme.
4. File theme trong repo giong het file goc (neu truyen vao).
"""
import json
import math
import re
import sys
from collections import Counter
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parent.parent
THEME = ROOT / "src" / "styles" / "urbox-portal-theme.css"
EXTRA_TOKENS = ROOT / "src" / "styles" / "urbox-status-tokens.css"  # token bo sung PD xac nhan 05/11/2026
CODE_MAP = json.loads((ROOT / "src" / "catalog" / "code-map.json").read_text(encoding="utf-8"))
MAX = 24


def rows_from_map(xlsx):
    sys.path.insert(0, str(ROOT / "scripts"))
    from map_to_spec import SHEETS, clean, parse_bools, parse_props, parse_swaps

    wb = openpyxl.load_workbook(xlsx, read_only=True)
    rows, all_ds = [], set()
    for sheet in SHEETS:
        it = wb[sheet].iter_rows(values_only=True)
        header = [clean(h) for h in next(it)]
        col = {h: i for i, h in enumerate(header)}
        for r in it:
            if not clean(r[col["Mã"]]):
                continue
            all_ds.add(clean(r[col["data-ds"]]))
            if clean(r[col["Giao Dev"]]) != "Có":
                continue
            rows.append(
                {
                    "id": clean(r[col["Mã"]]),
                    "ds": clean(r[col["data-ds"]]),
                    "props": parse_props(clean(r[col["Property và giá trị"]]), r[col["data-ds-props mặc định"]]),
                    "bools": parse_bools(clean(r[col["Boolean"]])),
                    "swaps": parse_swaps(clean(r[col["Instance swap"]])),
                }
            )
    return rows, all_ds


def swap_bool(row, name):
    low = name.lower()
    side = "left" if "(left)" in low else "right" if "(right)" in low else ""
    rx = re.compile(f"{side}.?icon", re.I) if side else re.compile(r"^(show icon|indicator icon|icon)$", re.I)
    return next((b["name"] for b in row["bools"] if rx.search(b["name"])), None)


def parent_of(row, name):
    if not name.startswith("- "):
        return None
    want = "show bottom" if "bottom" in name.lower() else "show top"
    return next((b["name"] for b in row["bools"] if b["name"].lower() == want), None)


def expected(row):
    cm = CODE_MAP[row["id"]]
    props = []
    for p in row["props"]:
        vals = [v for v in p["values"] if cm["props"][p["name"]][v] != "FIGMA_ONLY"]
        if vals:
            props.append({**p, "values": vals, "default": p["default"] if p["default"] in vals else vals[0]})
    bdef = {b["name"]: b["default"] for b in row["bools"]}
    dflt = {p["name"]: p["default"] for p in props}
    combos = []
    total = math.prod(len(p["values"]) for p in props) if props else 0
    if 0 < total <= MAX:
        acc = [{}]
        for p in props:
            acc = [{**c, p["name"]: v} for c in acc for v in p["values"]]
        combos = acc
    elif total > MAX:
        combos = [{**dflt, p["name"]: v} for p in props for v in p["values"]]
    els = [(c, dict(bdef), None) for c in combos]
    for b in row["bools"]:
        for on in (True, False):
            bb = {**bdef, b["name"]: on}
            par = parent_of(row, b["name"])
            if par:
                bb[par] = True
            els.append((dict(dflt), bb, None))
    for s in row["swaps"]:
        bb = dict(bdef)
        rel = swap_bool(row, s["name"])
        if rel:
            bb[rel] = True
        els.append((dict(dflt), bb, (s["name"], cm["swaps"][s["name"]]["option"])))
    if not els:
        els = [({}, {}, None)]
    out = []
    for vals, bools, swap in els:
        parts = [f'{p["name"]}={vals[p["name"]]}' for p in props]
        parts += [f'{b["name"]}={"true" if bools[b["name"]] else "false"}' for b in row["bools"]]
        if swap:
            parts.append(f"{swap[0]}={swap[1]}")
        out.append("; ".join(parts))
    return out


COLOR_RE = re.compile(r"#[0-9a-fA-F]{3,8}\b|\b(?:rgb|rgba|hsl|hsla|oklch|oklab|lab|lch)\(")
VAR_RE = re.compile(r"var\(\s*(--[\w-]+)|(?<![\w-])(--[a-zA-Z][\w-]*)\s*:")


def theme_vars():
    css = THEME.read_text(encoding="utf-8") + (EXTRA_TOKENS.read_text(encoding="utf-8") if EXTRA_TOKENS.exists() else "")
    return set(re.findall(r"(--[\w-]+)\s*:", css))


def scan_src():
    allowed = theme_vars()
    issues = []
    for f in sorted((ROOT / "src").rglob("*")):
        if not f.is_file() or f.suffix not in {".ts", ".tsx", ".css"}:
            continue
        rel = f.relative_to(ROOT)
        if rel.parts[:3] == ("src", "components", "ui") or f in (THEME, EXTRA_TOKENS) or f.name.endswith(".json"):
            continue
        for n, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
            if line.strip().startswith(("//", "/*", "*")):
                continue
            for m in COLOR_RE.finditer(line):
                issues.append(f"{rel}:{n} mau: {m.group(0)}")
            for m in VAR_RE.finditer(line):
                v = m.group(1) or m.group(2)
                if v not in allowed:
                    issues.append(f"{rel}:{n} bien CSS ngoai theme: {v}")
    return issues


def main():
    xlsx, check = sys.argv[1], sys.argv[2]
    rows, all_ds = rows_from_map(xlsx)
    data = json.loads(Path(check).read_text(encoding="utf-8"))
    actual = {}
    for e in data["els"]:
        actual.setdefault(e["ds"], Counter())[e["props"] or ""] += 1

    ok = 0
    exp_total = act_total = 0
    report = []
    for row in rows:
        exp = Counter(expected(row))
        act = actual.get(row["ds"], Counter())
        exp_total += sum(exp.values())
        act_total += sum(act.values())
        if exp == act:
            ok += 1
        else:
            report.append(f'{row["id"]} {row["ds"]}: du kien {sum(exp.values())}, thuc te {sum(act.values())}; thieu {list((exp - act).elements())[:3]}; thua {list((act - exp).elements())[:3]}')
    unknown = sorted(set(actual) - all_ds)
    src_issues = scan_src()
    theme_same = None
    if len(sys.argv) > 3:
        theme_same = Path(sys.argv[3]).read_bytes() == THEME.read_bytes()

    summary = {
        "theme": data.get("theme"),
        "component_dung": f"{ok}/{len(rows)}",
        "phan_tu_data_ds": f"{act_total}/{exp_total}",
        "data_ds_ngoai_map": unknown,
        "bien_css_mau_ngoai_theme": len(src_issues),
        "loi_console": len(data["errors"]),
        "font_body": data.get("bodyFont"),
        "data_screen": data.get("screen"),
        "font_vietnamese_tai": any("U+102-103" in f for f in data.get("fontFaces", [])),
        "theme_giong_file_goc": theme_same,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    for r in report:
        print("LECH", r)
    for i in src_issues:
        print("SRC", i)
    bad = report or unknown or src_issues or data["errors"] or theme_same is False
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
