import * as React from "react"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TooltipProvider } from "@/components/ui/tooltip"

import { buildElements, codeMap, Ctx, type MapRow, spec } from "./engine"
import { R } from "./registry"
import { BRANDS, T } from "./sample"

const MAP_VERSION = "Component Map v1.0 (bản giao Dev 03/11/2026, quét lần 13)"
const THEME_VERSION = "urbox-portal-theme.css (shadcn/studio Theme Generator, bản đính kèm 05/11/2026) + urbox-status-tokens.css (success, warning, info)"

type Theme = "light" | "dark"

function params() {
  return new URLSearchParams(window.location.search)
}

export function applyTheme(theme: Theme) {
  document.documentElement.classList.toggle("dark", theme === "dark")
}

function Caption({ c }: { c: Ctx }) {
  return (
    <figcaption className="max-w-80 text-xs break-words text-muted-foreground">
      {c.el.propsString || "Không có property"}
      {c.el.noProp.length > 0 && <span className="text-destructive"> · không có prop: {c.el.noProp.join(", ")}</span>}
    </figcaption>
  )
}

function Frame({ src, w, h, title }: { src: string; w: number; h: number; title: string }) {
  return <iframe src={src} width={w} height={h} title={title} loading="lazy" data-overlay-frame className="rounded-md border bg-background" />
}

function frameSrc(theme: Theme, id: string, i?: number) {
  const q = new URLSearchParams({ frame: id, theme })
  if (i !== undefined) q.set("i", String(i))
  return `?${q.toString()}`
}

function SelectOpenDemo() {
  return (
    <Select open defaultValue="hl">
      <SelectTrigger className="w-64"><SelectValue /></SelectTrigger>
      <SelectContent>
        {BRANDS.map((b, i) => <SelectItem key={b} value={i === 0 ? "hl" : b}>{b}</SelectItem>)}
      </SelectContent>
    </Select>
  )
}

function Block({ row, theme }: { row: MapRow; theme: Theme }) {
  const r = R[row.id]
  const els = buildElements(row)
  const ctxs = els.map((el) => new Ctx(row, el))
  const code = codeMap[row.id].code
  return (
    <section id={row.id} className="flex flex-col gap-4 border-t pt-8">
      <div className="flex flex-col gap-1">
        <h3>{row.figma}</h3>
        <p className="text-sm text-muted-foreground">
          {row.id} · {row.kind} · data-ds="{row.ds}" · {els.length} phần tử · code: {code}
        </p>
        {r.note && <p className="text-sm text-muted-foreground">{r.note}</p>}
      </div>
      {r.frame?.group ? (
        <figure className="flex flex-col gap-2">
          <Frame src={frameSrc(theme, row.id)} w={r.frame.w} h={r.frame.h} title={`${row.figma} (mở)`} />
          <figcaption className="text-xs text-muted-foreground">{els.length} phần tử trong một overlay mở, nhãn đặt dưới từng phần tử.</figcaption>
        </figure>
      ) : (
        <div className="flex flex-wrap items-start gap-8">
          {ctxs.map((c, i) => (
            <figure key={c.el.key} className="flex flex-col items-start gap-2">
              {r.frame && (!r.frame.when || r.frame.when(c)) ? (
                <Frame src={frameSrc(theme, row.id, i)} w={r.frame.w} h={r.frame.h} title={`${row.figma} ${c.el.propsString}`} />
              ) : (
                r.render?.(c)
              )}
              <Caption c={c} />
            </figure>
          ))}
        </div>
      )}
      {row.id === "CM-074" && (
        <figure className="flex flex-col items-start gap-2">
          <Frame src={frameSrc(theme, "select-open")} w={400} h={360} title="Select (mở)" />
          <figcaption className="text-xs text-muted-foreground">Select ở trạng thái mở, minh hoạ overlay, không gắn data-ds.</figcaption>
        </figure>
      )}
    </section>
  )
}

const SIZES = ["text-xs", "text-sm", "text-base", "text-lg", "text-xl", "text-2xl", "text-3xl", "text-4xl"]
const WEIGHTS = ["font-normal", "font-medium", "font-semibold", "font-bold"]

function Typography() {
  return (
    <section id="typography" className="flex flex-col gap-4 border-t pt-8">
      <h3>Kiểm chữ tiếng Việt (Manrope 400, 500, 600, 700)</h3>
      <div className="flex flex-col gap-2">
        <h1>H1 · {T.title}</h1>
        <h2>H2 · {T.title}</h2>
        <h3>H3 · {T.title}</h3>
        <h4>H4 · {T.title}</h4>
        <h5>H5 · {T.title}</h5>
        <h6>H6 · {T.title}</h6>
      </div>
      <div className="flex flex-col gap-2">
        {SIZES.map((s) => (
          <div key={s} className="flex flex-wrap gap-x-8 gap-y-1">
            {WEIGHTS.map((w) => (
              <span key={w} className={`${s} ${w}`}>
                {s.replace("text-", "")} · {w.replace("font-", "")} · Ưu đãi ạ ặ ẩ ố ữ ỹ Đ
              </span>
            ))}
          </div>
        ))}
      </div>
    </section>
  )
}

export function Catalog() {
  const [theme, setTheme] = React.useState<Theme>(params().get("theme") === "dark" ? "dark" : "light")
  const total = React.useMemo(() => spec.reduce((n, row) => n + buildElements(row).length, 0), [])
  const toggle = () => {
    const next: Theme = theme === "dark" ? "light" : "dark"
    applyTheme(next)
    const q = params()
    q.set("theme", next)
    window.history.replaceState(null, "", `?${q.toString()}`)
    setTheme(next)
  }
  return (
    <TooltipProvider>
      <main data-screen="DS-Catalog" className="flex min-h-screen flex-col gap-8 bg-background p-8 text-foreground">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex flex-col gap-2">
            <h1>UrBox shadcn Design System · Catalog</h1>
            <p className="text-sm text-muted-foreground">Repo tham chiếu cho thiết kế, không dùng cho production.</p>
            <p className="text-sm text-muted-foreground">{MAP_VERSION} · {THEME_VERSION}</p>
            <p className="text-sm text-muted-foreground">{spec.length} component · {total} phần tử data-ds</p>
          </div>
          <button type="button" onClick={toggle} className="rounded-md border bg-background px-4 py-2 text-sm font-medium hover:bg-accent">
            {theme === "dark" ? "Chuyển sang Light" : "Chuyển sang Dark"}
          </button>
        </header>
        <nav className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
          {spec.map((row) => (
            <a key={row.id} href={`#${row.id}`} className="text-primary hover:underline">{row.figma}</a>
          ))}
        </nav>
        <Typography />
        {spec.map((row) => <Block key={row.id} row={row} theme={theme} />)}
      </main>
    </TooltipProvider>
  )
}

/** Trang con trong iframe: render mot overlay (hoac mot nhom) o trang thai mo. */
export function FrameView({ id, index }: { id: string; index?: number }) {
  let content: React.ReactNode = null
  if (id === "select-open") content = <SelectOpenDemo />
  else {
    const row = spec.find((r) => r.id === id)
    const r = R[id]
    if (row && r) {
      const ctxs = buildElements(row).map((el) => new Ctx(row, el))
      content = r.group ? r.group(ctxs, (c) => <Caption c={c} />) : index !== undefined && ctxs[index] ? r.render?.(ctxs[index]) : null
    }
  }
  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background p-6 text-foreground">{content}</div>
    </TooltipProvider>
  )
}

export function App() {
  const q = params()
  applyTheme(q.get("theme") === "dark" ? "dark" : "light")
  const frame = q.get("frame")
  if (frame) return <FrameView id={frame} index={q.has("i") ? Number(q.get("i")) : undefined} />
  return <Catalog />
}
