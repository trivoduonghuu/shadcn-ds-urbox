import {
  CircleCheckIcon,
  InfoIcon,
  OctagonXIcon,
  PlusIcon,
  CheckIcon,
  StarIcon,
  TriangleAlertIcon,
  UserIcon,
  XIcon,
} from "lucide-react"

import { StatusIndicator } from "@/components/composed/status-indicator"
import { Avatar, AvatarFallback, AvatarGroup, AvatarGroupCount, AvatarImage, AvatarBadge } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Spinner } from "@/components/ui/spinner"
import { cn } from "@/lib/utils"
import { BADGE_BASE, badgeTone, toColor } from "@/components/composed/tone"

import type { Ctx } from "../engine"
import { T } from "../sample"
import type { Registry } from "../types"

const AVATAR_SRC = "/avatar-placeholder.svg"

function badge(appearance: "solid" | "soft" | "outline") {
  return (c: Ctx) => {
    const color = toColor(c.v("Style"))
    return (
      <Badge {...c.ds} variant={BADGE_BASE[appearance][color]} className={badgeTone(appearance, color) || undefined}>
        {c.b("Spinner") && <Spinner className="size-3" />}
        {c.b("Avatar") && (
          <Avatar size="sm" className="size-4">
            <AvatarFallback className="text-xs">{T.initials}</AvatarFallback>
          </Avatar>
        )}
        {c.b("Left Icon") && <StarIcon />}
        {T.badge}
        {c.b("Closable") && <XIcon />}
      </Badge>
    )
  }
}

const DOT: Record<string, string> = { primary: "bg-primary", secondary: "bg-secondary", destructive: "bg-destructive", success: "bg-success", warning: "bg-warning", info: "bg-info" }
const dot = (key: string) => <span className={cn("size-2 rounded-full", DOT[key.toLowerCase()] ?? "bg-muted-foreground")} />

const STATUS_ICON: Record<string, React.ReactNode> = {
  info: <InfoIcon />,
  warning: <TriangleAlertIcon />,
  destructive: <OctagonXIcon />,
  success: <CircleCheckIcon />,
}

const STATUS_TEXT: Record<string, string> = {
  info: "Đang xử lý",
  warning: "Sắp hết hạn",
  destructive: "Đã huỷ",
  success: "Đã phát quà",
}

export const badges: Registry = {
  "CM-028": {
    render: (c) => (
      <Avatar {...c.ds} size={c.is("Size", "sm") ? "sm" : c.is("Size", "lg") ? "lg" : "default"}>
        {c.is("Type", "Image") && <AvatarImage src={AVATAR_SRC} alt={T.person} />}
        <AvatarFallback>{c.is("Type", "Placeholder Icon") ? <UserIcon className="size-4" /> : T.initials}</AvatarFallback>
        {c.is("Indicator", "True") && <AvatarBadge />}
      </Avatar>
    ),
  },
  "CM-029": {
    render: (c) => (
      <Avatar size="lg">
        <AvatarFallback>{T.initials}</AvatarFallback>
        <StatusIndicator {...c.ds} type={c.v("Type").toLowerCase() as "online"}>
          {c.b("Indicator Icon") && (c.swap("Icon") === "check" ? <CheckIcon /> : <PlusIcon />)}
        </StatusIndicator>
      </Avatar>
    ),
  },
  "CM-030": {
    render: (c) => (
      <AvatarGroup {...c.ds}>
        {["HN", "TM", "QA"].map((s) => (
          <Avatar key={s}>
            {c.is("Variants", "Image") && <AvatarImage src={AVATAR_SRC} alt={s} />}
            <AvatarFallback>{c.is("Variants", "Icon") ? <UserIcon className="size-4" /> : s}</AvatarFallback>
          </Avatar>
        ))}
        {c.is("Variants", "Numbers") && <AvatarGroupCount>+12</AvatarGroupCount>}
      </AvatarGroup>
    ),
  },
  "CM-031": { render: badge("solid") },
  "CM-032": { render: badge("soft") },
  "CM-033": { render: badge("outline") },
  "CM-034": {
    render: (c) => (
      <Badge {...c.ds} variant="outline">
        {c.b("Left Icon") && dot(c.v("Style"))}
        {T.badge}
      </Badge>
    ),
  },
  "CM-035": {
    render: (c) => (
      <Badge {...c.ds} variant="outline" className={badgeTone("outline", toColor(c.v("Variants")))}>
        {STATUS_ICON[c.v("Variants").toLowerCase()]}
        {STATUS_TEXT[c.v("Variants").toLowerCase()]}
      </Badge>
    ),
  },
  "CM-036": {
    render: (c) => (
      <Badge {...c.ds} variant="outline" className={badgeTone("soft", toColor(c.v("Variants")))}>
        {dot(c.v("Variants"))}
        {STATUS_TEXT[c.v("Variants").toLowerCase()]}
      </Badge>
    ),
  },
}
