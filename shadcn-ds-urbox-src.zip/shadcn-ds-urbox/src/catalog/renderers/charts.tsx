import * as React from "react"
import { GiftIcon, TicketIcon } from "lucide-react"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Label,
  LabelList,
  Line,
  LineChart,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  RadialBar,
  RadialBarChart,
  XAxis,
  YAxis,
} from "recharts"

import { Button } from "@/components/ui/button"
import {
  type ChartConfig,
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

import type { Ctx } from "../engine"
import { MONTHS } from "../sample"
import type { Registry } from "../types"

// Mau chi lay tu bien --chart-1..5 trong file theme.
const C = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"]
const VOUCHER = [186, 305, 237, 73, 209, 214]
const EGIFT = [80, 200, 120, 190, 130, 140]
const DATA = MONTHS.map((month, i) => ({ month, voucher: VOUCHER[i], egift: EGIFT[i], net: VOUCHER[i] - EGIFT[i] * 1.4 }))

const config = {
  voucher: { label: "Voucher", color: C[0], icon: TicketIcon },
  egift: { label: "eGift", color: C[1], icon: GiftIcon },
} satisfies ChartConfig

const PIE = [
  { brand: "highlands", label: "Highlands", value: 275, fill: C[0] },
  { brand: "phuclong", label: "Phúc Long", value: 200, fill: C[1] },
  { brand: "grab", label: "Grab", value: 187, fill: C[2] },
  { brand: "shopee", label: "Shopee", value: 173, fill: C[3] },
  { brand: "cgv", label: "CGV", value: 90, fill: C[4] },
]
const pieConfig = {
  value: { label: "Lượt đổi" },
  ...Object.fromEntries(PIE.map((p) => [p.brand, { label: p.label, color: p.fill }])),
} satisfies ChartConfig

const BOX = "aspect-auto h-60 w-80"
const NOANIM = { isAnimationActive: false }

function Interactive({ c, kind }: { c: Ctx; kind: "area" | "line" | "bar" }) {
  const [key, setKey] = React.useState<"voucher" | "egift">("voucher")
  return (
    <div {...c.ds} className="flex w-80 flex-col gap-2">
      <div className="flex gap-2">
        {(["voucher", "egift"] as const).map((k) => (
          <Button key={k} size="sm" variant={key === k ? "default" : "outline"} onClick={() => setKey(k)}>
            {config[k].label}
          </Button>
        ))}
      </div>
      <ChartContainer config={config} className={BOX}>
        {kind === "area" ? (
          <AreaChart data={DATA}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Area dataKey={key} type="natural" fill={config[key].color} fillOpacity={0.4} stroke={config[key].color} {...NOANIM} />
          </AreaChart>
        ) : kind === "line" ? (
          <LineChart data={DATA}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <Line dataKey={key} type="monotone" stroke={config[key].color} strokeWidth={2} dot={false} {...NOANIM} />
          </LineChart>
        ) : (
          <BarChart data={DATA}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <Bar dataKey={key} fill={config[key].color} radius={4} {...NOANIM} />
          </BarChart>
        )}
      </ChartContainer>
    </div>
  )
}

function area(c: Ctx) {
  const t = c.v("Type").toLowerCase()
  if (t === "interactive") return <Interactive c={c} kind="area" />
  const stacked = t === "stacked" || t === "stacked expended" || t === "legend" || t === "icons"
  const type = t === "linear" ? "linear" : t === "step" ? "step" : "natural"
  return (
    <ChartContainer {...c.ds} config={config} className={BOX}>
      <AreaChart data={DATA} stackOffset={t === "stacked expended" ? "expand" : undefined}>
        <CartesianGrid vertical={false} />
        <XAxis dataKey="month" tickLine={false} axisLine={false} />
        {t === "axes" && <YAxis tickLine={false} axisLine={false} width={32} />}
        {t === "gradient" && (
          <defs>
            <linearGradient id={`g-${c.el.key}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={C[0]} stopOpacity={0.8} />
              <stop offset="95%" stopColor={C[0]} stopOpacity={0.1} />
            </linearGradient>
          </defs>
        )}
        {stacked && <Area dataKey="egift" type={type} stackId="a" fill={C[1]} fillOpacity={0.4} stroke={C[1]} {...NOANIM} />}
        <Area dataKey="voucher" type={type} stackId="a" fill={t === "gradient" ? `url(#g-${c.el.key})` : C[0]} fillOpacity={0.4} stroke={C[0]} {...NOANIM} />
        {(t === "legend" || t === "icons") && <ChartLegend content={<ChartLegendContent hideIcon={t !== "icons"} />} />}
      </AreaChart>
    </ChartContainer>
  )
}

function bar(c: Ctx) {
  const t = c.v("Type").toLowerCase()
  if (t === "interactive") return <Interactive c={c} kind="bar" />
  if (t === "horizontal")
    return (
      <ChartContainer {...c.ds} config={config} className={BOX}>
        <BarChart data={DATA} layout="vertical">
          <XAxis type="number" dataKey="voucher" hide />
          <YAxis dataKey="month" type="category" tickLine={false} axisLine={false} width={64} />
          <Bar dataKey="voucher" fill={C[0]} radius={4} {...NOANIM} />
        </BarChart>
      </ChartContainer>
    )
  return (
    <ChartContainer {...c.ds} config={config} className={BOX}>
      <BarChart data={DATA}>
        <CartesianGrid vertical={false} />
        <XAxis dataKey="month" tickLine={false} axisLine={false} />
        {t === "negative" ? (
          <Bar dataKey="net" {...NOANIM}>
            {DATA.map((d) => <Cell key={d.month} fill={d.net > 0 ? C[0] : "var(--destructive)"} />)}
          </Bar>
        ) : (
          <Bar dataKey="voucher" stackId={t === "stacked + legend" ? "a" : undefined} fill={C[0]} radius={t === "stacked + legend" ? 0 : 4} {...NOANIM}>
            {t === "active" && DATA.map((d, i) => <Cell key={d.month} fill={C[0]} fillOpacity={i === 1 ? 1 : 0.4} stroke={i === 1 ? C[3] : undefined} strokeWidth={2} />)}
            {t === "mixed" && DATA.map((d, i) => <Cell key={d.month} fill={C[i % 5]} />)}
            {t === "label" && <LabelList dataKey="voucher" position="top" className="fill-foreground" fontSize={12} />}
            {t === "custom" && <LabelList dataKey="month" position="insideTop" className="fill-primary-foreground" fontSize={10} />}
          </Bar>
        )}
        {(t === "multiple" || t === "stacked + legend") && <Bar dataKey="egift" stackId={t === "stacked + legend" ? "a" : undefined} fill={C[1]} radius={4} {...NOANIM} />}
        {t === "stacked + legend" && <ChartLegend content={<ChartLegendContent />} />}
      </BarChart>
    </ChartContainer>
  )
}

function line(c: Ctx) {
  const t = c.v("Type").toLowerCase()
  if (t === "interactive") return <Interactive c={c} kind="line" />
  const type = t === "linear" ? "linear" : t === "step" ? "step" : "natural"
  const dotted = ["dots", "dots colors", "custom dots", "label", "custom label"].includes(t)
  return (
    <ChartContainer {...c.ds} config={config} className={BOX}>
      <LineChart data={DATA} margin={{ top: 24, left: 12, right: 12 }}>
        <CartesianGrid vertical={false} />
        <XAxis dataKey="month" tickLine={false} axisLine={false} />
        <Line
          dataKey="voucher"
          type={type}
          stroke={C[0]}
          strokeWidth={2}
          dot={
            t === "custom dots"
              ? ({ cx, cy, index }: { cx?: number; cy?: number; index?: number }) => <GiftIcon key={index} x={(cx ?? 0) - 8} y={(cy ?? 0) - 8} width={16} height={16} className="text-primary" />
              : t === "dots colors"
                ? ({ cx, cy, index }: { cx?: number; cy?: number; index?: number }) => <circle key={index} cx={cx} cy={cy} r={5} fill={C[(index ?? 0) % 5]} />
                : dotted
                  ? { fill: C[0] }
                  : false
          }
          {...NOANIM}
        >
          {t === "label" && <LabelList position="top" offset={12} className="fill-foreground" fontSize={12} />}
          {t === "custom label" && <LabelList position="top" offset={12} className="fill-foreground" fontSize={12} dataKey="month" />}
        </Line>
        {t === "multiple" && <Line dataKey="egift" type="monotone" stroke={C[1]} strokeWidth={2} dot={false} {...NOANIM} />}
      </LineChart>
    </ChartContainer>
  )
}

function PieDemo({ c }: { c: Ctx }) {
  const t = c.v("Type").toLowerCase()
  const [month, setMonth] = React.useState("t11")
  const total = PIE.reduce((s, p) => s + p.value, 0)
  const donut = t.startsWith("donut") || t === "interactive"
  const center = (
    <Label
      content={({ viewBox }) => {
        const vb = viewBox as { cx?: number; cy?: number }
        return (
          <text x={vb.cx} y={vb.cy} textAnchor="middle" dominantBaseline="middle">
            <tspan x={vb.cx} y={vb.cy} className="fill-foreground text-2xl font-bold">{total}</tspan>
            <tspan x={vb.cx} y={(vb.cy ?? 0) + 20} className="fill-muted-foreground text-xs">lượt đổi</tspan>
          </text>
        )
      }}
    />
  )
  const activeAngle = (PIE[0].value / total) * 360
  const chart = (
    <ChartContainer {...(t === "interactive" ? {} : c.ds)} config={pieConfig} className="aspect-auto h-60 w-72">
      <PieChart>
        <Pie
          data={PIE}
          dataKey="value"
          nameKey="brand"
          startAngle={90}
          endAngle={-270}
          innerRadius={donut ? 60 : t === "stacked" ? 0 : 0}
          outerRadius={t === "stacked" ? 60 : 90}
          strokeWidth={t === "separator none" ? 0 : 2}
          stroke="var(--background)"
          label={t === "label" ? true : t === "custom label" ? ({ payload }: { payload?: { label: string } }) => payload?.label ?? "" : undefined}
          labelLine={t === "label" || t === "custom label"}
          {...NOANIM}
        >
          {t === "label list" && <LabelList dataKey="label" className="fill-background" stroke="none" fontSize={11} />}
          {(t === "donut with text" || t === "interactive") && center}
        </Pie>
        {t === "stacked" && <Pie data={PIE} dataKey="value" nameKey="brand" innerRadius={70} outerRadius={95} startAngle={90} endAngle={-270} {...NOANIM} />}
        {t === "donut active" && (
          <Pie data={[PIE[0]]} dataKey="value" nameKey="brand" innerRadius={60} outerRadius={100} startAngle={90} endAngle={90 - activeAngle} {...NOANIM} />
        )}
        {t === "legend" && <ChartLegend content={<ChartLegendContent nameKey="brand" />} className="flex-wrap gap-2" />}
      </PieChart>
    </ChartContainer>
  )
  if (t !== "interactive") return chart
  return (
    <div {...c.ds} className="flex w-72 flex-col gap-2">
      <Select value={month} onValueChange={setMonth}>
        <SelectTrigger size="sm" className="self-end"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="t10">Tháng 10</SelectItem>
          <SelectItem value="t11">Tháng 11</SelectItem>
        </SelectContent>
      </Select>
      {chart}
    </div>
  )
}

const RADAR = MONTHS.map((month, i) => ({ month, voucher: VOUCHER[i], egift: EGIFT[i] }))

function radar(c: Ctx) {
  const t = c.v("Variant").toLowerCase()
  const circle = t === "grid circle" || t === "grid circle filled"
  const filled = t === "grid filled" || t === "grid circle filled"
  return (
    <ChartContainer {...c.ds} config={config} className="aspect-auto h-64 w-72">
      <RadarChart data={RADAR}>
        {t === "custom label" ? (
          <PolarAngleAxis
            dataKey="month"
            tick={({ x, y, textAnchor, index }: { x?: number | string; y?: number | string; textAnchor?: string; index?: number }) => (
              <text x={x} y={y} textAnchor={textAnchor as "middle"} fontSize={11} className="fill-foreground">
                <tspan>{RADAR[index ?? 0].month}</tspan>
                <tspan x={x} dy="1.2em" className="fill-muted-foreground">{RADAR[index ?? 0].voucher}</tspan>
              </text>
            )}
          />
        ) : (
          <PolarAngleAxis dataKey="month" />
        )}
        {t !== "grid none" && (
          <PolarGrid
            gridType={circle ? "circle" : "polygon"}
            radialLines={t !== "no lines" && t !== "grid custom" && !circle}
            polarRadius={t === "grid custom" ? [90] : undefined}
            className={filled ? "fill-chart-2 opacity-30" : undefined}
          />
        )}
        {t === "radius axis" && <PolarRadiusAxis angle={60} stroke="var(--muted-foreground)" orientation="middle" axisLine={false} />}
        <Radar
          dataKey="voucher"
          fill={C[0]}
          fillOpacity={t === "lines only" ? 0 : 0.6}
          stroke={C[0]}
          strokeWidth={t === "lines only" ? 2 : 1}
          dot={t === "dots" ? { r: 4, fillOpacity: 1 } : false}
          {...NOANIM}
        />
        {(t === "multiple" || t === "legend" || t === "icons" || t === "lines only") && (
          <Radar dataKey="egift" fill={C[1]} fillOpacity={t === "lines only" ? 0 : 0.6} stroke={C[1]} strokeWidth={t === "lines only" ? 2 : 1} {...NOANIM} />
        )}
        {(t === "legend" || t === "icons") && <ChartLegend content={<ChartLegendContent hideIcon={t !== "icons"} />} />}
      </RadarChart>
    </ChartContainer>
  )
}

function radial(c: Ctx) {
  const t = c.v("Type").toLowerCase()
  if (t === "stacked")
    return (
      <ChartContainer {...c.ds} config={config} className="aspect-auto h-60 w-72">
        <RadialBarChart data={[{ voucher: 1260, egift: 570 }]} endAngle={180} innerRadius={80} outerRadius={130}>
          <PolarRadiusAxis tick={false} tickLine={false} axisLine={false} />
          <RadialBar dataKey="voucher" stackId="a" cornerRadius={4} fill={C[0]} {...NOANIM} />
          <RadialBar dataKey="egift" stackId="a" cornerRadius={4} fill={C[1]} {...NOANIM} />
        </RadialBarChart>
      </ChartContainer>
    )
  if (t === "shape" || t === "text")
    return (
      <ChartContainer {...c.ds} config={pieConfig} className="aspect-auto h-60 w-72">
        <RadialBarChart data={[PIE[0]]} startAngle={0} endAngle={t === "shape" ? 250 : 300} innerRadius={80} outerRadius={110}>
          <PolarGrid gridType="circle" radialLines={false} stroke="none" className="first:fill-muted last:fill-background" polarRadius={[86, 74]} />
          <RadialBar dataKey="value" background cornerRadius={10} {...NOANIM} />
          <PolarRadiusAxis tick={false} tickLine={false} axisLine={false}>
            <Label
              content={({ viewBox }) => {
                const vb = viewBox as { cx?: number; cy?: number }
                return (
                  <text x={vb.cx} y={vb.cy} textAnchor="middle" dominantBaseline="middle">
                    <tspan x={vb.cx} y={vb.cy} className="fill-foreground text-3xl font-bold">{PIE[0].value}</tspan>
                    <tspan x={vb.cx} y={(vb.cy ?? 0) + 24} className="fill-muted-foreground text-xs">lượt đổi</tspan>
                  </text>
                )
              }}
            />
          </PolarRadiusAxis>
        </RadialBarChart>
      </ChartContainer>
    )
  return (
    <ChartContainer {...c.ds} config={pieConfig} className="aspect-auto h-60 w-72">
      <RadialBarChart data={PIE} innerRadius={30} outerRadius={110} startAngle={t === "label" ? -90 : 0} endAngle={t === "label" ? 380 : 360}>
        {t === "grid" && <PolarGrid gridType="circle" />}
        <RadialBar dataKey="value" background {...NOANIM}>
          {t === "label" && <LabelList position="insideStart" dataKey="label" className="fill-background capitalize" fontSize={11} />}
        </RadialBar>
      </RadialBarChart>
    </ChartContainer>
  )
}

export const charts: Registry = {
  "CM-116": { render: radar },
  "CM-117": { render: area },
  "CM-118": { render: radial },
  "CM-119": { render: line },
  "CM-120": { render: (c) => <PieDemo c={c} /> },
  "CM-121": { render: bar },
}
