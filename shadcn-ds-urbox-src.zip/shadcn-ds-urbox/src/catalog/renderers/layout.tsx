import {
  ArrowDownUpIcon,
  BoldIcon,
  CalendarDaysIcon,
  ChevronsUpDownIcon,
  CircleAlertIcon,
  FileIcon,
  FolderIcon,
  GiftIcon,
  HomeIcon,
  ItalicIcon,
  MoreHorizontalIcon,
  SlashIcon,
  TicketIcon,
  UnderlineIcon,
  WalletIcon,
  XIcon,
} from "lucide-react"

import { DashboardFooter } from "@/components/composed/dashboard-footer"
import { FormWizard } from "@/components/composed/form-wizard"
import { StepItem, Steps } from "@/components/composed/steps"
import { Timeline } from "@/components/composed/timeline"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Breadcrumb,
  BreadcrumbEllipsis,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import { Card, CardAction, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"
import { Checkbox } from "@/components/ui/checkbox"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command"
import { DropdownMenu, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Field, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import {
  Item,
  ItemActions,
  ItemContent,
  ItemDescription,
  ItemHeader,
  ItemMedia,
  ItemTitle,
} from "@/components/ui/item"
import { Kbd } from "@/components/ui/kbd"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Progress } from "@/components/ui/progress"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Switch } from "@/components/ui/switch"
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Toggle } from "@/components/ui/toggle"
import { alertTone, type AlertColor } from "@/components/composed/tone"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { CommandIcon, OptionIcon, TagIcon } from "lucide-react"

import type { Ctx } from "../engine"
import { BRANDS, T } from "../sample"
import type { Registry } from "../types"

const FAQ = [
  { q: "Voucher có thời hạn sử dụng bao lâu?", a: "Mỗi voucher có hạn 90 ngày kể từ ngày phát, hiển thị trên thẻ quà." },
  { q: "Doanh nghiệp nạp ngân sách bằng cách nào?", a: "Chuyển khoản theo hợp đồng, số dư cập nhật trong vòng 2 giờ làm việc." },
  { q: "Người nhận đổi quà ở đâu?", a: "Tại cửa hàng của thương hiệu đối tác hoặc trên Zalo Mini App." },
]

function accordionItemTrigger(c: Ctx) {
  return (
    <AccordionTrigger>
      <span className="flex items-center gap-3">
        {c.b("Avatar") && (
          <Avatar size="sm">
            <AvatarFallback>{T.initials}</AvatarFallback>
          </Avatar>
        )}
        {c.b("Left Icon") && <GiftIcon className="size-4" />}
        <span className="flex flex-col gap-1">
          <span>{FAQ[0].q}</span>
          {c.b("Subtitle") && <span className="text-xs font-normal text-muted-foreground">Cập nhật ngày 05/11/2026</span>}
        </span>
      </span>
    </AccordionTrigger>
  )
}

const BREAD = ["Trang chủ", "Chiến dịch", "Ngân sách ưu đãi"]

function breadcrumbDemo(c: Ctx) {
  const s = c.v("Style").toLowerCase()
  const sep = s === "with dot" ? <BreadcrumbSeparator>·</BreadcrumbSeparator> : s === "custom separator" ? <BreadcrumbSeparator><SlashIcon /></BreadcrumbSeparator> : <BreadcrumbSeparator />
  const badgeVariant = s === "outline badge" ? "outline" : "secondary"
  const withBadge = ["with badge", "outline badge", "badge with icon", "mix"].includes(s)
  const crumb = (label: string, i: number) => {
    const content = withBadge ? (
      <Badge variant={badgeVariant}>
        {(s === "badge with icon" || s === "mix") && i === 0 && <HomeIcon />}
        {label}
      </Badge>
    ) : (
      label
    )
    return i === BREAD.length - 1 ? <BreadcrumbPage>{content}</BreadcrumbPage> : <BreadcrumbLink href="#">{content}</BreadcrumbLink>
  }
  return (
    <Breadcrumb {...c.ds}>
      <BreadcrumbList>
        <BreadcrumbItem>{crumb(BREAD[0], 0)}</BreadcrumbItem>
        {sep}
        {(s === "dropdown" || s === "mix") && (
          <>
            <BreadcrumbItem>
              <BreadcrumbEllipsis />
            </BreadcrumbItem>
            {sep}
          </>
        )}
        <BreadcrumbItem>
          {s === "with dropdown" ? (
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-1">
                {BREAD[1]}
                <ChevronsUpDownIcon className="size-3.5" />
              </DropdownMenuTrigger>
            </DropdownMenu>
          ) : (
            crumb(BREAD[1], 1)
          )}
        </BreadcrumbItem>
        {sep}
        <BreadcrumbItem>{s === "with link" ? <BreadcrumbLink href="#">{BREAD[2]}</BreadcrumbLink> : crumb(BREAD[2], 2)}</BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  )
}

function alertDemo(appearance: "outline" | "solid" | "soft") {
  return (c: Ctx) => {
    const v = c.v("Variants").toLowerCase()
    const color = (v === "default" ? "neutral" : v === "amber" ? "warning" : v) as AlertColor
    return alertBody(c, appearance, color)
  }
}

function alertBody(c: Ctx, appearance: "outline" | "solid" | "soft", color: AlertColor) {
  return (
    <Alert {...c.ds} variant={color === "destructive" ? "destructive" : "default"} className={`w-96 ${alertTone(appearance, color)}`}>
      {c.b("Left Icon") && <CircleAlertIcon />}
      {c.b("Show Title") && (
        <AlertTitle className="flex items-center gap-2">
          {c.b("Avatar") && (
            <Avatar size="sm">
              <AvatarFallback>{T.initials}</AvatarFallback>
            </Avatar>
          )}
          Ngân sách chiến dịch sắp hết
          {(c.b("Show Badge") || c.b("Badge")) && <Badge variant="secondary">{T.badge}</Badge>}
        </AlertTitle>
      )}
      {c.b("Show Description") && <AlertDescription>Còn 12% hạn mức, nạp thêm để không gián đoạn phát quà.</AlertDescription>}
      {(c.b("Show Actions") || c.b("Close Icon")) && (
        <div className="col-start-2 flex items-center gap-2 pt-2">
          {c.b("Show Actions") && <Button size="sm">Nạp ngân sách</Button>}
          {c.b("Close Icon") && (
            <Button variant="ghost" size="icon-xs" aria-label="Đóng">
              <XIcon />
            </Button>
          )}
        </div>
      )}
    </Alert>
  )
}

const TL_ITEMS = [
  { title: "Tạo chiến dịch", time: "08:30", description: "Thiết lập ngân sách 200 triệu đồng.", icon: <WalletIcon /> },
  { title: "Phê duyệt", time: "10:15", description: "Kế toán xác nhận hạn mức.", icon: <CalendarDaysIcon /> },
  { title: "Phát quà", time: "14:00", description: "Gửi 1.250 eGift qua Zalo.", icon: <GiftIcon /> },
]

const STEPS = [
  { title: "Thông tin", description: "Tên và thời gian" },
  { title: "Ngân sách", description: "Hạn mức chi" },
  { title: "Quà tặng", description: "Chọn voucher" },
]

function tableCellContent(c: Ctx) {
  const v = c.v("Variant").toLowerCase()
  if (v === "with badge") return <Badge variant="secondary">Đang chạy</Badge>
  if (v === "with avatar")
    return (
      <span className="flex items-center gap-2">
        <Avatar size="sm"><AvatarFallback>{T.initials}</AvatarFallback></Avatar>
        {T.person}
      </span>
    )
  if (v === "switch") return <Switch defaultChecked aria-label="Bật" />
  if (v === "progress") return <Progress value={60} className="w-24" />
  if (v === "checkbox") return <Checkbox aria-label="Chọn" />
  if (v === "button") return <Button size="sm" variant="outline">Xem</Button>
  if (v === "select")
    return (
      <Select defaultValue="active">
        <SelectTrigger size="sm"><SelectValue /></SelectTrigger>
        <SelectContent><SelectItem value="active">Đang chạy</SelectItem></SelectContent>
      </Select>
    )
  if (v === "with icon")
    return (
      <span className="flex items-center gap-2">
        <TicketIcon className="size-4" />
        Voucher
      </span>
    )
  return (
    <span className="flex flex-col">
      {c.b("Title") && <span>{T.item}</span>}
      {c.b("Description") && <span className="text-xs text-muted-foreground">Hết hạn 31/12/2026</span>}
    </span>
  )
}

export const layout: Registry = {
  "CM-023": {
    render: (c) => {
      const open = c.is("Opened", "Open") || c.is("Opened", "Open disable")
      return (
        <Accordion type="single" collapsible value={open ? "a" : ""} className="w-96">
          <AccordionItem {...c.ds} value="a" disabled={c.v("Opened").toLowerCase().includes("disable")}>
            {accordionItemTrigger(c)}
            <AccordionContent>{FAQ[0].a}</AccordionContent>
          </AccordionItem>
        </Accordion>
      )
    },
  },
  "CM-024": {
    render: (c) => (
      <Accordion type="single" collapsible className="w-96">
        <AccordionItem value="a">
          <AccordionTrigger {...c.ds}>{FAQ[1].q}</AccordionTrigger>
          <AccordionContent>{FAQ[1].a}</AccordionContent>
        </AccordionItem>
      </Accordion>
    ),
  },
  "CM-025": {
    render: (c) => (
      <Accordion type="single" collapsible value="a" className="w-96">
        <AccordionItem value="a">
          <AccordionTrigger>{FAQ[2].q}</AccordionTrigger>
          <AccordionContent {...c.ds}>{FAQ[2].a}</AccordionContent>
        </AccordionItem>
      </Accordion>
    ),
  },
  "CM-026": {
    render: (c) => (
      <Accordion type="single" collapsible className="w-72">
        <AccordionItem value="a">
          <AccordionTrigger {...c.ds}>Chi tiết</AccordionTrigger>
          <AccordionContent>{FAQ[0].a}</AccordionContent>
        </AccordionItem>
      </Accordion>
    ),
  },
  "CM-027": {
    render: (c) => {
      const v = c.v("Variants").toLowerCase()
      const icons = [<TicketIcon key="t" className="size-4" />, <WalletIcon key="w" className="size-4" />, <GiftIcon key="g" className="size-4" />]
      const items = FAQ.map((f, i) => (
        <AccordionItem key={i} value={`i${i}`} disabled={v === "with disabled" && i === 2}>
          <AccordionTrigger>
            <span className="flex items-center gap-2">
              {v === "multi icons" && icons[i]}
              {f.q}
            </span>
          </AccordionTrigger>
          <AccordionContent>{f.a}</AccordionContent>
        </AccordionItem>
      ))
      const acc =
        v === "multiple" ? (
          <Accordion {...c.ds} type="multiple" defaultValue={["i0", "i1"]} className="w-96">{items}</Accordion>
        ) : (
          <Accordion {...(v === "in card" ? {} : c.ds)} type="single" collapsible defaultValue="i0" className="w-96">{items}</Accordion>
        )
      if (v !== "in card") return acc
      return (
        <Card {...c.ds} className="w-[26rem]">
          <CardHeader><CardTitle>Câu hỏi thường gặp</CardTitle></CardHeader>
          <CardContent>{acc}</CardContent>
        </Card>
      )
    },
  },
  "CM-039": {
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      if (v === "login")
        return (
          <Card {...c.ds} className="w-96">
            <CardHeader>
              <CardTitle>Đăng nhập Portal</CardTitle>
              <CardDescription>Dành cho quản trị viên doanh nghiệp</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <Field><FieldLabel htmlFor="login-email">Email</FieldLabel><Input id="login-email" placeholder={T.email} /></Field>
              <Field><FieldLabel htmlFor="login-pw">Mật khẩu</FieldLabel><Input id="login-pw" type="password" /></Field>
            </CardContent>
            <CardFooter><Button className="w-full">Đăng nhập</Button></CardFooter>
          </Card>
        )
      if (v === "meeting notes")
        return (
          <Card {...c.ds} className="w-96">
            <CardHeader>
              <CardTitle>Ghi chú họp với Vietcombank</CardTitle>
              <CardDescription>05/11/2026 · 45 phút</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="flex list-disc flex-col gap-2 pl-4 text-sm">
                <li>Chốt ngân sách quý I năm 2027.</li>
                <li>Bổ sung 3 thương hiệu ẩm thực vào danh mục.</li>
                <li>Đối soát định kỳ vào ngày 5 hằng tháng.</li>
              </ul>
            </CardContent>
          </Card>
        )
      return (
        <Card {...c.ds} className="w-96">
          {v === "with image" && <Skeleton className="mx-6 h-32" />}
          <CardHeader>
            <CardTitle>{T.title}</CardTitle>
            <CardDescription>{T.desc}</CardDescription>
            <CardAction><Badge variant="secondary">{T.badge}</Badge></CardAction>
          </CardHeader>
          <CardContent><p className="text-sm">Đã dùng 128.500.000 ₫ trên tổng 200.000.000 ₫.</p></CardContent>
          <CardFooter className="gap-2">
            <Button size="sm">Nạp thêm</Button>
            <Button size="sm" variant="outline">Xem báo cáo</Button>
          </CardFooter>
        </Card>
      )
    },
  },
  "CM-042": {
    render: (c) => {
      const t = c.v("Type").toLowerCase()
      return (
        <Collapsible {...c.ds} defaultOpen className="flex w-80 flex-col gap-2">
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm font-semibold">{t === "file tree" ? "Tài liệu chiến dịch" : t === "setting panel" ? "Cài đặt thông báo" : "Danh sách thương hiệu"}</span>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="icon-sm" aria-label="Mở rộng"><ChevronsUpDownIcon /></Button>
            </CollapsibleTrigger>
          </div>
          {t !== "basic" && t !== "setting panel" && <div className="rounded-md border px-4 py-2 text-sm">{t === "file tree" ? "Hợp đồng 2026.pdf" : BRANDS[0]}</div>}
          <CollapsibleContent className="flex flex-col gap-2">
            {t === "file tree" &&
              ["Báo cáo đối soát", "Danh sách người nhận"].map((f) => (
                <div key={f} className="flex items-center gap-2 pl-4 text-sm"><FolderIcon className="size-4" />{f}<FileIcon className="size-4 text-muted-foreground" /></div>
              ))}
            {t === "setting panel" &&
              ["Email khi phát quà", "Cảnh báo ngân sách"].map((f) => (
                <label key={f} className="flex items-center justify-between rounded-md border px-4 py-2 text-sm">{f}<Switch defaultChecked /></label>
              ))}
            {(t === "default" || t === "basic") &&
              BRANDS.slice(1, 3).map((b) => (
                <div key={b} className="rounded-md border px-4 py-2 text-sm">{b}</div>
              ))}
          </CollapsibleContent>
        </Collapsible>
      )
    },
  },
  "CM-043": {
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      const vertical = v.startsWith("vertical")
      const basis = v.startsWith("three") ? "basis-1/3" : v.startsWith("two") ? "basis-1/2" : ""
      return (
        <div className={vertical ? "px-4 py-12" : "px-12"}>
          <Carousel {...c.ds} orientation={vertical ? "vertical" : "horizontal"} className={vertical ? "w-64" : "w-80"}>
            <CarouselContent className={vertical ? "h-48" : ""}>
              {BRANDS.map((b) => (
                <CarouselItem key={b} className={vertical ? "basis-1/2" : basis}>
                  <Card className="py-4"><CardContent className="flex h-16 items-center justify-center px-4 text-sm font-medium">{b}</CardContent></Card>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        </div>
      )
    },
  },
  "CM-044": {
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      const nav =
        v === "simple" ? (
          <PaginationContent>
            <PaginationItem><PaginationPrevious href="#" /></PaginationItem>
            <PaginationItem><span className="px-2 text-sm">Trang 2 / 10</span></PaginationItem>
            <PaginationItem><PaginationNext href="#" /></PaginationItem>
          </PaginationContent>
        ) : (
          <PaginationContent>
            <PaginationItem><PaginationPrevious href="#" /></PaginationItem>
            {[1, 2, 3].map((n) => (
              <PaginationItem key={n}><PaginationLink href="#" isActive={n === 2}>{n}</PaginationLink></PaginationItem>
            ))}
            <PaginationItem><PaginationEllipsis /></PaginationItem>
            <PaginationItem><PaginationNext href="#" /></PaginationItem>
          </PaginationContent>
        )
      if (v !== "with select") return <Pagination {...c.ds}>{nav}</Pagination>
      return (
        <div {...c.ds} className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm">
            Số dòng
            <Select defaultValue="20">
              <SelectTrigger size="sm"><SelectValue /></SelectTrigger>
              <SelectContent>{["10", "20", "50"].map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <Pagination className="mx-0 w-auto">{nav}</Pagination>
        </div>
      )
    },
    note: "Variant=With select: Pagination nằm trong khung chứa Select số dòng, data-ds gắn trên thẻ bọc ngoài.",
  },
  "CM-045": {
    render: (c) => {
      const size = ({ xs: "icon-xs", sm: "icon-sm", md: "icon", lg: "icon-lg" } as const)[c.v("size") as "xs"] ?? "icon"
      return (
        <Pagination className="mx-0 w-auto">
          <PaginationContent>
            <PaginationItem>
              <PaginationLink {...c.ds} href="#" size={size} isActive={c.is("Variants", "Outlined")}>2</PaginationLink>
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      )
    },
  },
  "CM-046": {
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      return (
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem {...c.ds}>
              {v === "active link" && <BreadcrumbPage>Ngân sách ưu đãi</BreadcrumbPage>}
              {v === "link" && <BreadcrumbLink href="#">Chiến dịch</BreadcrumbLink>}
              {v === "icon placeholder" && <BreadcrumbEllipsis />}
              {v === "ghost icon button" && (
                <BreadcrumbLink asChild>
                  <Button variant="ghost" size="icon-sm" aria-label="Trang chủ"><HomeIcon /></Button>
                </BreadcrumbLink>
              )}
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      )
    },
  },
  "CM-047": {
    render: (c) => (
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem><BreadcrumbLink href="#">Chiến dịch</BreadcrumbLink></BreadcrumbItem>
          <BreadcrumbSeparator {...c.ds}>
            {c.is("Variant", "Dot") ? "·" : c.is("Variant", "Slash") ? <SlashIcon /> : undefined}
          </BreadcrumbSeparator>
          <BreadcrumbItem><BreadcrumbPage>Ngân sách</BreadcrumbPage></BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
    ),
  },
  "CM-048": { render: breadcrumbDemo },
  "CM-049": { render: alertDemo("outline") },
  "CM-050": { render: alertDemo("solid") },
  "CM-051": { render: alertDemo("soft") },
  "CM-053": {
    render: (c) => (
      <Item {...c.ds} className="w-[26rem]" variant={c.v("Variants").toLowerCase() as "outline"} size={c.is("Size", "sm") ? "sm" : "default"}>
        {c.b("Show Header") && <ItemHeader className="text-xs text-muted-foreground">Đối tác thương hiệu</ItemHeader>}
        {c.b("Show Media") && <ItemMedia variant="image"><Skeleton className="size-full" /></ItemMedia>}
        {c.b("Left Icon") && <ItemMedia variant="icon"><TicketIcon /></ItemMedia>}
        {c.b("Avatar") && (
          <ItemMedia>
            <Avatar><AvatarFallback>{T.initials}</AvatarFallback></Avatar>
          </ItemMedia>
        )}
        <ItemContent>
          {c.b("Show Title") && (
            <ItemTitle>
              {T.item}
              {c.b("Show Badge") && <Badge variant="secondary">{T.badge}</Badge>}
            </ItemTitle>
          )}
          {c.b("Show Description") && <ItemDescription>Áp dụng tại 1.200 cửa hàng trên toàn quốc.</ItemDescription>}
        </ItemContent>
        {c.b("Show Actions") && <ItemActions><Button size="sm" variant="outline">Chọn</Button></ItemActions>}
        {c.b("Right Icon") && <MoreHorizontalIcon className="size-4" />}
      </Item>
    ),
  },
  "CM-054": {
    render: (c) => {
      const value = c.is("State", "Active") ? "me" : c.b("has_Active_onLeft") ? "left" : c.b("has_Active_onRight") ? "right" : "none"
      return (
        <Tabs value={value}>
          <TabsList variant="default">
            {c.b("has_Left_Items") && <TabsTrigger value="left">Tổng quan</TabsTrigger>}
            <TabsTrigger {...c.ds} value="me" disabled={c.is("State", "disabled")}>
              {c.b("Has Icon") && <GiftIcon />}
              {c.b("text") && "Quà tặng"}
            </TabsTrigger>
            {c.b("has_Right_Items") && <TabsTrigger value="right">Báo cáo</TabsTrigger>}
          </TabsList>
        </Tabs>
      )
    },
  },
  "CM-057": {
    render: (c) => (
      <StepItem
        {...c.ds}
        index={2}
        title="Ngân sách"
        description={c.b("Subtext") ? "Hạn mức chi theo tháng" : undefined}
        position={c.is("Position", "Middle") ? "middle" : "start"}
        active={c.is("isActive", "True")}
        orientation={c.is("Orientation", "Vertical") ? "vertical" : "horizontal"}
        bullet={c.is("Step bullet type", "Icon") ? "icon" : "text"}
        shape={c.is("Shape", "Round") ? "round" : "rounded"}
        icon={c.b("Icon") ? <WalletIcon className="size-4" /> : <span className="text-xs">2</span>}
      />
    ),
  },
  "CM-058": { render: (c) => <Steps {...c.ds} steps={STEPS} current={1} orientation="horizontal" shape={c.is("Shape", "Round") ? "round" : "rounded"} /> },
  "CM-059": { render: (c) => <Steps {...c.ds} steps={STEPS} current={1} orientation="vertical" shape={c.is("Shape", "Round") ? "round" : "rounded"} /> },
  "CM-062": {
    render: (c) => {
      const value = Number.parseInt(c.v("Variants"), 10)
      if (!c.b("Top label")) return <Progress {...c.ds} value={value} className="w-72" />
      return (
        <Field {...c.ds} className="w-72">
          <FieldLabel className="flex justify-between">Ngân sách đã dùng<span>{value}%</span></FieldLabel>
          <Progress value={value} />
        </Field>
      )
    },
    note: "Top label=true: Progress đặt trong Field kèm nhãn, data-ds gắn trên Field.",
  },
  "CM-083": {
    render: (c) => (
      <Timeline {...c.ds} className="w-96" items={TL_ITEMS} inline={c.b("Show Text Inline")} variant={c.is("Variants", "Timeline with icon") ? "icon" : c.is("Variants", "Centered Timeline") ? "centered" : "basic"} />
    ),
  },
  "CM-084": {
    render: (c) => (
      <FormWizard
        {...c.ds}
        className="w-[36rem]"
        current={1}
        bullet={c.b("Icon") ? "icon" : "text"}
        orientation={c.is("Type", "Form Wizard Vertical") ? "vertical" : "horizontal"}
        steps={STEPS.map((s) => ({ title: c.b("Text") ? s.title : "", description: c.b("Subtitle") ? s.description : undefined }))}
      >
        <Field><FieldLabel htmlFor="wz-budget">Hạn mức chi</FieldLabel><Input id="wz-budget" placeholder="200.000.000 ₫" /></Field>
      </FormWizard>
    ),
  },
  "CM-089": {
    render: (c) => {
      const map: Record<string, "default"> = {
        default: "default",
        "with social links": "social" as "default",
        "with actions": "actions" as "default",
        "with breadcrumb": "breadcrumb" as "default",
        "with centered logo and pages": "centered" as "default",
        "two footer": "two-rows" as "default",
        "two footer with button": "two-rows-button" as "default",
      }
      return <DashboardFooter {...c.ds} className="w-[44rem]" variant={map[c.v("Variant").toLowerCase()]} />
    },
  },
  "CM-095": {
    render: (c) =>
      c.is("Variant", "Default") ? (
        <div className="flex w-72 flex-col gap-2 p-4 text-sm">
          Thông tin chiến dịch
          <Separator {...c.ds} orientation="horizontal" />
          Ngân sách
        </div>
      ) : (
        <div className="flex w-72 flex-col gap-2 py-4 text-sm">
          <span className="px-4">Thông tin chiến dịch</span>
          <Separator {...c.ds} />
          <span className="px-4">Ngân sách</span>
        </div>
      ),
  },
  "CM-097": {
    render: (c) => {
      const t = c.v("Type").toLowerCase()
      if (t === "skeleton avatar")
        return (
          <div {...c.ds} className="flex items-center gap-4">
            <Skeleton className="size-12 rounded-full" />
            <div className="flex flex-col gap-2"><Skeleton className="h-4 w-48" /><Skeleton className="h-4 w-32" /></div>
          </div>
        )
      if (t === "skeleton card")
        return (
          <div {...c.ds} className="flex w-64 flex-col gap-3">
            <Skeleton className="h-32 w-full" /><Skeleton className="h-4 w-48" /><Skeleton className="h-4 w-32" />
          </div>
        )
      if (t === "skeleton text")
        return (
          <div {...c.ds} className="flex w-72 flex-col gap-2">
            <Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-2/3" />
          </div>
        )
      if (t === "skeleton form")
        return (
          <div {...c.ds} className="flex w-72 flex-col gap-3">
            <Skeleton className="h-4 w-24" /><Skeleton className="h-9 w-full" /><Skeleton className="h-9 w-28" />
          </div>
        )
      return (
        <div {...c.ds} className="flex w-96 flex-col gap-2">
          {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-8 w-full" />)}
        </div>
      )
    },
    note: "Skeleton là một khối nhiều Skeleton ghép; data-ds gắn trên thẻ bọc ngoài.",
  },
  "CM-100": {
    render: (c) =>
      c.is("Type", "Horizontal") ? (
        <ScrollArea {...c.ds} className="w-80 rounded-md border whitespace-nowrap">
          <div className="flex w-max gap-4 p-4">
            {BRANDS.map((b) => <div key={b} className="flex h-20 w-32 items-center justify-center rounded-md bg-muted text-sm">{b}</div>)}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      ) : (
        <ScrollArea {...c.ds} className="h-48 w-64 rounded-md border">
          <div className="flex flex-col gap-2 p-4 text-sm">
            {[...BRANDS, ...BRANDS].map((b, i) => <div key={i}>{b}</div>)}
          </div>
        </ScrollArea>
      ),
  },
  "CM-101": { render: (c) => <Spinner {...c.ds} className={({ "3": "size-3", "6": "size-6", "8": "size-8" } as Record<string, string>)[c.v("Size")]} /> },
  "CM-106": {
    render: (c) => (
      <Command {...c.ds} className={c.is("Variant", "Basic") ? "w-80 rounded-lg border shadow-md" : "w-80"}>
        <CommandInput placeholder="Tìm chiến dịch, thương hiệu..." />
        <CommandList>
          <CommandEmpty>Không tìm thấy kết quả.</CommandEmpty>
          <CommandGroup heading="Gợi ý">
            <CommandItem><GiftIcon />Tạo chiến dịch quà tặng<CommandShortcut>⌘N</CommandShortcut></CommandItem>
            <CommandItem><WalletIcon />Nạp ngân sách</CommandItem>
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="Thương hiệu">
            {BRANDS.slice(0, 3).map((b) => <CommandItem key={b}><TagIcon />{b}</CommandItem>)}
          </CommandGroup>
        </CommandList>
      </Command>
    ),
  },
  "CM-107": {
    render: (c) => (
      <Kbd {...c.ds}>
        {c.b("Show icon") && (c.swap("icon") === "option" ? <OptionIcon /> : <CommandIcon />)}
        {c.b("Show Title") && "K"}
      </Kbd>
    ),
  },
  "CM-109": {
    render: (c) => (
      <Table className="w-64">
        <TableHeader>
          <TableRow>
            <TableHead {...c.ds}>
              <span className="flex items-center gap-2">
                {c.b("Checkbox") && <Checkbox aria-label="Chọn tất cả" />}
                {c.b("Title") && "Tên chiến dịch"}
              </span>
            </TableHead>
          </TableRow>
        </TableHeader>
      </Table>
    ),
  },
  "CM-110": {
    render: (c) => (
      <Table className="w-72">
        <TableBody>
          <TableRow>
            <TableCell {...c.ds}>{tableCellContent(c)}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    ),
  },
  "CM-113": {
    render: (c) => (
      <Toggle
        {...c.ds}
        variant={c.is("Type", "Outline") ? "outline" : "default"}
        size={c.is("Size", "sm") ? "sm" : c.is("Size", "lg") ? "lg" : "default"}
        disabled={c.is("State", "Disabled")}
        aria-label="In đậm"
      >
        {c.b("Icon") && <BoldIcon />}
        {c.b("Text") && "In đậm"}
      </Toggle>
    ),
  },
  "CM-114": {
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      const vertical = v.startsWith("vertical")
      const outline = v.includes("outline")
      const icons = v.includes("icons")
      const spacing = v.includes("spacing") ? 2 : 0
      if (v === "with input and select")
        return (
          <div {...c.ds} className="flex items-center gap-2">
            <ToggleGroup type="single" variant="outline" defaultValue="all">
              <ToggleGroupItem value="all">Tất cả</ToggleGroupItem>
              <ToggleGroupItem value="active">Đang chạy</ToggleGroupItem>
            </ToggleGroup>
            <Input className="w-48" placeholder="Tìm chiến dịch" />
            <Select defaultValue="month">
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="month">Tháng này</SelectItem></SelectContent>
            </Select>
          </div>
        )
      if (v === "font weight selector")
        return (
          <ToggleGroup {...c.ds} type="single" variant="outline" defaultValue="600">
            {["400", "500", "600", "700"].map((w) => <ToggleGroupItem key={w} value={w} aria-label={`Weight ${w}`}>{w}</ToggleGroupItem>)}
          </ToggleGroup>
        )
      if (v === "sort")
        return (
          <ToggleGroup {...c.ds} type="single" variant="outline" defaultValue="new">
            <ToggleGroupItem value="new"><ArrowDownUpIcon />Mới nhất</ToggleGroupItem>
            <ToggleGroupItem value="budget">Ngân sách</ToggleGroupItem>
            <ToggleGroupItem value="name">Tên A–Z</ToggleGroupItem>
          </ToggleGroup>
        )
      return (
        <ToggleGroup
          {...c.ds}
          type="multiple"
          defaultValue={["b"]}
          variant={outline || v === "outline with icons" ? "outline" : "default"}
          orientation={vertical ? "vertical" : "horizontal"}
          spacing={spacing}
          disabled={v === "disabled"}
          className={vertical ? "flex-col" : undefined}
        >
          <ToggleGroupItem value="b" aria-label="In đậm">{icons || v === "outline with icons" ? <BoldIcon /> : "Đậm"}</ToggleGroupItem>
          <ToggleGroupItem value="i" aria-label="In nghiêng">{icons || v === "outline with icons" ? <ItalicIcon /> : "Nghiêng"}</ToggleGroupItem>
          <ToggleGroupItem value="u" aria-label="Gạch chân">{icons || v === "outline with icons" ? <UnderlineIcon /> : "Gạch chân"}</ToggleGroupItem>
        </ToggleGroup>
      )
    },
    note: "Variant=With input and select: ToggleGroup đặt cạnh Input và Select, data-ds gắn trên thẻ bọc ngoài.",
  },
  "CS-023": {
    render: (c) => (
      <Table {...c.ds} className="w-[32rem]">
        {c.b("Table Caption") && <TableCaption>Danh sách chiến dịch quý IV năm 2026</TableCaption>}
        <TableHeader>
          <TableRow>
            {c.b("Show empty-header") && <TableHead className="w-8" />}
            <TableHead>Chiến dịch</TableHead>
            <TableHead>Trạng thái</TableHead>
            <TableHead className="text-right">Ngân sách</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[
            ["Ưu đãi Tết Nguyên Đán", "Đang chạy", "200.000.000 ₫"],
            ["Tri ân khách hàng VIP", "Nháp", "85.000.000 ₫"],
          ].map((r) => (
            <TableRow key={r[0]}>
              {c.b("Show empty-header") && <TableCell><Checkbox aria-label="Chọn" /></TableCell>}
              <TableCell>{r[0]}</TableCell>
              <TableCell>{r[1]}</TableCell>
              <TableCell className="text-right">{r[2]}</TableCell>
            </TableRow>
          ))}
        </TableBody>
        {c.b("Footer") && (
          <TableFooter>
            <TableRow>
              <TableCell colSpan={c.b("Show empty-header") ? 3 : 2}>Tổng</TableCell>
              <TableCell className="text-right">285.000.000 ₫</TableCell>
            </TableRow>
          </TableFooter>
        )}
      </Table>
    ),
  },
}
