import * as React from "react"
import {
  BarChart3Icon,
  ChevronRightIcon,
  CircleCheckIcon,
  ContactIcon,
  CopyIcon,
  DownloadIcon,
  GiftIcon,
  HomeIcon,
  InfoIcon,
  LayoutDashboardIcon,
  PauseIcon,
  SettingsIcon,
  StoreIcon,
  Trash2Icon,
  UsersIcon,
  WalletIcon,
} from "lucide-react"
import { Bar, BarChart, XAxis } from "recharts"
import { toast } from "sonner"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { type ChartConfig, ChartContainer } from "@/components/ui/chart"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogMedia,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Combobox,
  ComboboxCollection,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxGroup,
  ComboboxInput,
  ComboboxItem,
  ComboboxLabel,
  ComboboxList,
  ComboboxSeparator,
  ComboboxTrigger,
  ComboboxValue,
  ComboboxChip,
  ComboboxChips,
  ComboboxChipsInput,
} from "@/components/ui/combobox"
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuShortcut,
  ContextMenuTrigger,
} from "@/components/ui/context-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Field, FieldLabel } from "@/components/ui/field"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card"
import { Input } from "@/components/ui/input"
import { Kbd } from "@/components/ui/kbd"
import {
  Menubar,
  MenubarCheckboxItem,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarSeparator,
  MenubarShortcut,
  MenubarSub,
  MenubarSubContent,
  MenubarSubTrigger,
  MenubarTrigger,
} from "@/components/ui/menubar"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Skeleton } from "@/components/ui/skeleton"
import { Switch } from "@/components/ui/switch"
import { Toaster } from "@/components/ui/sonner"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"

import type { Ctx } from "../engine"
import { BRANDS, MENU, MONTHS, T } from "../sample"
import type { Registry } from "../types"

const MENU_ICONS = [<InfoIcon key="0" />, <CopyIcon key="1" />, <DownloadIcon key="2" />, <PauseIcon key="3" />]

function useOnce(fn: () => void) {
  const done = React.useRef(false)
  React.useEffect(() => {
    if (done.current) return
    done.current = true
    fn()
  }, [fn])
}

function ToastFrame({ ds, show }: { ds: Ctx["ds"]; show: () => void }) {
  useOnce(show)
  return (
    <div {...ds} className="h-full w-full">
      <Toaster position="top-center" expand duration={Number.POSITIVE_INFINITY} />
    </div>
  )
}

function ContextMenuFrame({ c }: { c: Ctx }) {
  const ref = React.useRef<HTMLSpanElement>(null)
  React.useEffect(() => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    el.dispatchEvent(new MouseEvent("contextmenu", { bubbles: true, clientX: r.left + 24, clientY: r.top + 24 }))
  }, [])
  return (
    <ContextMenu>
      <ContextMenuTrigger asChild>
        <span ref={ref} className="flex h-32 w-72 items-center justify-center rounded-md border border-dashed text-sm text-muted-foreground">Nhấp chuột phải vào thẻ chiến dịch</span>
      </ContextMenuTrigger>
      <ContextMenuContent {...c.ds} className="w-56">
        {MENU.slice(0, 3).map((m, i) => (
          <ContextMenuItem key={m}>{MENU_ICONS[i]}{m}</ContextMenuItem>
        ))}
        <ContextMenuSeparator />
        <ContextMenuItem variant="destructive"><Trash2Icon />Xoá chiến dịch<ContextMenuShortcut>⌫</ContextMenuShortcut></ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  )
}

function menuItem(c: Ctx) {
  const body = (
    <>
      {c.b("Left Icon") && <GiftIcon />}
      {c.b("Avatar") && (
        <Avatar size="sm"><AvatarFallback>{T.initials}</AvatarFallback></Avatar>
      )}
      <span className="flex flex-col">
        <span>{MENU[1]}</span>
        {c.b("Show Description") && <span className="text-xs text-muted-foreground">Sao chép cấu hình và ngân sách</span>}
      </span>
      {c.b("Badge") && <Badge variant="secondary">{T.badge}</Badge>}
      {c.b("switch") && <Switch size="sm" className="ml-auto" defaultChecked aria-label="Bật" />}
      {c.b("Shortcuts") && <DropdownMenuShortcut>⌘D</DropdownMenuShortcut>}
      {c.b("Right Icon") && <ChevronRightIcon className="ml-auto" />}
    </>
  )
  if (c.b("Checkbox"))
    return (
      <DropdownMenuCheckboxItem {...c.ds} checked disabled={c.is("State", "Disabled")} onSelect={(e) => e.preventDefault()}>
        {body}
      </DropdownMenuCheckboxItem>
    )
  return (
    <DropdownMenuItem {...c.ds} variant={c.is("State", "Destructive Hover") ? "destructive" : "default"} disabled={c.is("State", "Disabled")} onSelect={(e) => e.preventDefault()}>
      {body}
    </DropdownMenuItem>
  )
}

function menubarItem(c: Ctx) {
  const icon = c.b("Left icon") ? <GiftIcon /> : null
  const sc = c.b("Short cut") ? <MenubarShortcut>⌘N</MenubarShortcut> : null
  const disabled = c.is("State", "disabled")
  if (c.is("Style", "submenu"))
    return (
      <MenubarSub>
        <MenubarSubTrigger {...c.ds} disabled={disabled}>{icon}Xuất dữ liệu</MenubarSubTrigger>
        <MenubarSubContent><MenubarItem>Excel</MenubarItem></MenubarSubContent>
      </MenubarSub>
    )
  if (c.is("Style", "checkbox"))
    return <MenubarCheckboxItem {...c.ds} checked disabled={disabled} onSelect={(e) => e.preventDefault()}>{icon}Hiện ngân sách{sc}</MenubarCheckboxItem>
  return (
    <MenubarItem {...c.ds} variant={c.is("Style", "destructive") ? "destructive" : "default"} disabled={disabled} onSelect={(e) => e.preventDefault()}>
      {icon}
      {c.is("Style", "destructive") ? "Xoá chiến dịch" : "Chiến dịch mới"}
      {sc}
    </MenubarItem>
  )
}

const GROUPS = [
  { value: "Ẩm thực", items: [BRANDS[0], BRANDS[1]] },
  { value: "Mua sắm", items: [BRANDS[3], BRANDS[4]] },
  { value: "Di chuyển & giải trí", items: [BRANDS[2], BRANDS[5]] },
]

function ComboboxFrame({ c }: { c: Ctx }) {
  const v = c.v("Variant").toLowerCase()
  const grouped = v.startsWith("with groups")
  const multiple = v.startsWith("combobox multiple")
  const items = grouped ? GROUPS : BRANDS
  const list = (
    <ComboboxList>
      {grouped
        ? (g: (typeof GROUPS)[number], gi: number) => (
            <React.Fragment key={g.value}>
              {v === "with groups and separator" && gi > 0 && <ComboboxSeparator />}
              <ComboboxGroup items={g.items}>
                <ComboboxLabel>{g.value}</ComboboxLabel>
                <ComboboxCollection>{(it: string) => <ComboboxItem key={it} value={it}>{it}</ComboboxItem>}</ComboboxCollection>
              </ComboboxGroup>
            </React.Fragment>
          )
        : (it: string, i: number) => (
            <ComboboxItem key={it} value={it} disabled={v === "disabled items" && i % 2 === 1}>
              {v === "with custom item rendering" ? (
                <span className="flex items-center gap-2">
                  <Avatar size="sm"><AvatarFallback>{it.slice(0, 2)}</AvatarFallback></Avatar>
                  <span className="flex flex-col"><span>{it}</span><span className="text-xs text-muted-foreground">Đối tác từ 2021</span></span>
                </span>
              ) : (
                it
              )}
            </ComboboxItem>
          )}
    </ComboboxList>
  )
  if (v === "combobox in popup")
    return (
      <div {...c.ds} className="w-fit">
        <Combobox items={BRANDS} open defaultValue={BRANDS[0]}>
          <ComboboxTrigger render={<Button variant="outline" className="w-64 justify-between font-normal" />}>
            <ComboboxValue />
          </ComboboxTrigger>
          <ComboboxContent>
            <ComboboxInput showTrigger={false} placeholder="Tìm thương hiệu" />
            <ComboboxEmpty>Không có thương hiệu phù hợp.</ComboboxEmpty>
            {list}
          </ComboboxContent>
        </Combobox>
      </div>
    )
  if (multiple)
    return (
      <div {...c.ds} className="w-80">
        <Combobox items={BRANDS} multiple open defaultValue={[BRANDS[0], BRANDS[1]]}>
          <ComboboxChips>
            <ComboboxValue>
              {(values: string[]) => (
                <>
                  {values.map((x) => <ComboboxChip key={x} showRemove={v !== "combobox multiple (no remove)"}>{x}</ComboboxChip>)}
                  <ComboboxChipsInput placeholder="Thêm thương hiệu" />
                </>
              )}
            </ComboboxValue>
          </ComboboxChips>
          <ComboboxContent>{list}</ComboboxContent>
        </Combobox>
      </div>
    )
  return (
    <div {...c.ds} className="w-72">
      <Combobox items={items} open defaultValue={grouped ? undefined : BRANDS[1]}>
        <ComboboxInput placeholder="Tìm thương hiệu" showClear={v === "with clear button"} aria-invalid={v === "invalid" || undefined} />
        <ComboboxContent>
          <ComboboxEmpty>Không có thương hiệu phù hợp.</ComboboxEmpty>
          {list}
        </ComboboxContent>
      </Combobox>
    </div>
  )
}

const NAV_LINKS = [
  { title: "Quà tặng nhân viên", desc: "Phúc lợi sinh nhật, lễ Tết", icon: <UsersIcon /> },
  { title: "Khách hàng thân thiết", desc: "Tích điểm, đổi quà", icon: <GiftIcon /> },
  { title: "Thương hiệu đối tác", desc: "Hơn 300 merchant", icon: <StoreIcon /> },
  { title: "Báo cáo đối soát", desc: "Theo ngày, theo chiến dịch", icon: <BarChart3Icon /> },
]

const chartConfig = { value: { label: "Lượt đổi", color: "var(--chart-1)" } } satisfies ChartConfig
const chartData = MONTHS.map((m, i) => ({ month: m, value: [186, 305, 237, 273, 209, 314][i] }))

function SidebarDemo({ c }: { c: Ctx }) {
  const v = c.v("Variant").toLowerCase()
  const icon = v === "with icon"
  return (
    <SidebarProvider defaultOpen={!icon} className="min-h-full">
      <Sidebar {...c.ds} variant={v === "inset" ? "inset" : v === "floating" ? "floating" : "sidebar"} collapsible={icon ? "icon" : "offcanvas"}>
        <SidebarHeader><span className="px-2 text-base font-semibold text-primary">{icon ? "U" : "UrBox Portal"}</span></SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Vận hành</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {[
                  { t: "Tổng quan", i: <LayoutDashboardIcon /> },
                  { t: "Chiến dịch", i: <GiftIcon /> },
                  { t: "Ngân sách", i: <WalletIcon /> },
                  { t: "Cài đặt", i: <SettingsIcon /> },
                ].map((m, idx) => (
                  <SidebarMenuItem key={m.t}>
                    <SidebarMenuButton isActive={idx === 1} tooltip={m.t}>{m.i}<span>{m.t}</span></SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter><span className="px-2 text-xs text-muted-foreground">{icon ? "" : T.email}</span></SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="flex h-12 items-center gap-2 border-b px-4"><SidebarTrigger />{T.title}</header>
        <div className="flex flex-col gap-4 p-4"><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /></div>
      </SidebarInset>
    </SidebarProvider>
  )
}

export const overlays: Registry = {
  "CM-040": {
    frame: { w: 640, h: 560 },
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      return (
        <Dialog open>
          <DialogContent {...c.ds} showCloseButton={v !== "no close button" && c.b("Closable")}>
            {v === "with image" && <Skeleton className="h-40 w-full" />}
            <DialogHeader>
              <DialogTitle>{T.title}</DialogTitle>
              <DialogDescription>{T.desc}</DialogDescription>
            </DialogHeader>
            {v === "with content" && (
              <div className="flex flex-col gap-4">
                <Field><FieldLabel htmlFor={`${c.el.key}-n`}>{T.label}</FieldLabel><Input id={`${c.el.key}-n`} defaultValue={T.value} /></Field>
                <Field><FieldLabel htmlFor={`${c.el.key}-b`}>Ngân sách</FieldLabel><Input id={`${c.el.key}-b`} defaultValue="200.000.000 ₫" /></Field>
              </div>
            )}
            {c.b("Footer") && (
              <DialogFooter>
                <Button variant="outline">Huỷ</Button>
                <Button>Lưu thay đổi</Button>
              </DialogFooter>
            )}
          </DialogContent>
        </Dialog>
      )
    },
  },
  "CM-041": {
    frame: { w: 640, h: 420 },
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      const small = v.includes("small")
      const destructive = v.startsWith("destructive")
      return (
        <AlertDialog open>
          <AlertDialogContent {...c.ds} size={small ? "sm" : "default"}>
            <AlertDialogHeader>
              {(c.b("Icon") || c.b("Show Avatar")) && (
                <AlertDialogMedia>
                  {c.b("Show Avatar") ? (
                    <Avatar><AvatarFallback>{T.initials}</AvatarFallback></Avatar>
                  ) : destructive ? (
                    <Trash2Icon />
                  ) : (
                    <CircleCheckIcon />
                  )}
                </AlertDialogMedia>
              )}
              <AlertDialogTitle>{destructive ? "Xoá chiến dịch này?" : "Kích hoạt chiến dịch?"}</AlertDialogTitle>
              <AlertDialogDescription>{destructive ? "Toàn bộ voucher chưa phát sẽ bị huỷ và hoàn ngân sách." : "Quà sẽ được gửi tới 1.250 người nhận ngay sau khi kích hoạt."}</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Huỷ</AlertDialogCancel>
              <AlertDialogAction variant={destructive ? "destructive" : "default"}>{destructive ? "Xoá" : "Kích hoạt"}</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )
    },
  },
  "CM-060": {
    frame: { w: 400, h: 240 },
    render: (c) => {
      const side = (c.v("Position").toLowerCase() || "top") as "top"
      return (
        <div className="flex h-full items-center justify-center">
          <Tooltip open>
            <TooltipTrigger asChild><Button variant="outline">Số dư khả dụng</Button></TooltipTrigger>
            <TooltipContent {...c.ds} side={side === ("none" as string) ? "top" : side}>
              <span className="flex items-center gap-2">
                {c.b("Avatar") && (
                  <Avatar size="sm"><AvatarFallback>{T.initials}</AvatarFallback></Avatar>
                )}
                {c.b("Show icon") && (c.swap("icon") === "info" ? <InfoIcon className="size-3" /> : <ContactIcon className="size-3" />)}
                <span className="flex flex-col">
                  {c.b("Show Title") && <span className="font-medium">Còn 71.500.000 ₫</span>}
                  {c.b("Show Subtext") && <span>Cập nhật lúc 09:30</span>}
                </span>
                {c.b("Kbd for Tooltip") && <Kbd>⌘B</Kbd>}
              </span>
            </TooltipContent>
          </Tooltip>
        </div>
      )
    },
  },
  "CM-079": {
    frame: { w: 440, h: 1880, group: true },
    group: (cs, caption) => (
      <DropdownMenu open modal={false}>
        <DropdownMenuTrigger asChild><Button variant="outline">Tác vụ chiến dịch</Button></DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-96">
          {cs.map((c) => (
            <div key={c.el.key} className="flex flex-col gap-1 py-1">
              {menuItem(c)}
              <div className="px-2">{caption(c)}</div>
            </div>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    ),
  },
  "CS-013": {
    frame: { w: 400, h: 320 },
    render: (c) => (
      <DropdownMenu open modal={false}>
        <DropdownMenuTrigger asChild><Button variant="outline">Tài khoản</Button></DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-64">
          <DropdownMenuLabel {...c.ds}>{T.email}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {MENU.slice(0, 2).map((m) => <DropdownMenuItem key={m}>{m}</DropdownMenuItem>)}
        </DropdownMenuContent>
      </DropdownMenu>
    ),
  },
  "CM-080": {
    frame: { w: 480, h: 480 },
    render: (c) => (
      <DropdownMenu open modal={false}>
        <DropdownMenuTrigger asChild><Button variant="outline">Tác vụ chiến dịch</Button></DropdownMenuTrigger>
        {c.is("Variant", "Default") ? (
          <DropdownMenuContent {...c.ds} align="start" className="w-64">
            {MENU.map((m, i) => <DropdownMenuItem key={m}>{MENU_ICONS[i]}{m}</DropdownMenuItem>)}
          </DropdownMenuContent>
        ) : (
          <DropdownMenuContent {...c.ds} align="start" className="w-72">
            <DropdownMenuLabel>Chiến dịch Tết 2027</DropdownMenuLabel>
            <DropdownMenuGroup>
              <DropdownMenuItem><InfoIcon />Xem chi tiết<DropdownMenuShortcut>⌘I</DropdownMenuShortcut></DropdownMenuItem>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger><DownloadIcon />Xuất báo cáo</DropdownMenuSubTrigger>
                <DropdownMenuSubContent><DropdownMenuItem>Excel</DropdownMenuItem></DropdownMenuSubContent>
              </DropdownMenuSub>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuCheckboxItem checked>Gửi email nhắc hạn</DropdownMenuCheckboxItem>
            <DropdownMenuSeparator />
            <DropdownMenuRadioGroup value="zalo">
              <DropdownMenuRadioItem value="zalo">Kênh Zalo</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="sms">Kênh SMS</DropdownMenuRadioItem>
            </DropdownMenuRadioGroup>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive"><Trash2Icon />Xoá chiến dịch</DropdownMenuItem>
          </DropdownMenuContent>
        )}
      </DropdownMenu>
    ),
  },
  "CM-082": {
    frame: { w: 440, h: 400 },
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      return (
        <Popover open>
          <PopoverTrigger asChild><Button variant="outline">Điều chỉnh hạn mức</Button></PopoverTrigger>
          <PopoverContent {...c.ds} align="start" className="flex w-80 flex-col gap-4">
            <div className="flex flex-col gap-1">
              <span className="text-sm font-medium">Hạn mức chiến dịch</span>
              <span className="text-sm text-muted-foreground">Đặt mức chi tối đa cho mỗi người nhận.</span>
            </div>
            {v !== "basic" && (
              <Field orientation="horizontal"><FieldLabel htmlFor={`${c.el.key}-a`} className="w-24">Mỗi người</FieldLabel><Input id={`${c.el.key}-a`} defaultValue="500.000 ₫" /></Field>
            )}
            {v === "multiple input" && (
              <>
                <Field orientation="horizontal"><FieldLabel htmlFor={`${c.el.key}-b`} className="w-24">Mỗi ngày</FieldLabel><Input id={`${c.el.key}-b`} defaultValue="20.000.000 ₫" /></Field>
                <Field orientation="horizontal"><FieldLabel htmlFor={`${c.el.key}-c`} className="w-24">Tổng</FieldLabel><Input id={`${c.el.key}-c`} defaultValue="200.000.000 ₫" /></Field>
              </>
            )}
            {v === "with form" && <Button size="sm" className="self-end">Lưu</Button>}
          </PopoverContent>
        </Popover>
      )
    },
  },
  "CM-091": {
    frame: { w: 440, h: 1000, group: true },
    group: (cs, caption) => (
      <Menubar value="m">
        <MenubarMenu value="m">
          <MenubarTrigger>Chiến dịch</MenubarTrigger>
          <MenubarContent className="w-96">
            {cs.map((c) => (
              <div key={c.el.key} className="flex flex-col gap-1 py-1">
                {menubarItem(c)}
                <div className="px-2">{caption(c)}</div>
              </div>
            ))}
          </MenubarContent>
        </MenubarMenu>
        <MenubarMenu value="r"><MenubarTrigger>Báo cáo</MenubarTrigger></MenubarMenu>
      </Menubar>
    ),
  },
  "CM-093": {
    render: (c) => (
      <NavigationMenu viewport={false}>
        <NavigationMenuList>
          <NavigationMenuItem>
            <NavigationMenuLink {...c.ds} href="#" className="w-64">
              {c.is("Variant", "With icon") ? (
                <span className="flex flex-row items-center gap-2">{NAV_LINKS[0].icon}{NAV_LINKS[0].title}</span>
              ) : c.is("Variant", "With Subtext") ? (
                <>
                  <span className="font-medium">{NAV_LINKS[0].title}</span>
                  <span className="text-muted-foreground">{NAV_LINKS[0].desc}</span>
                </>
              ) : (
                NAV_LINKS[0].title
              )}
            </NavigationMenuLink>
          </NavigationMenuItem>
        </NavigationMenuList>
      </NavigationMenu>
    ),
  },
  "CM-094": {
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      return (
        <div className="h-72 w-[34rem]">
          <NavigationMenu value="sol">
            <NavigationMenuList>
              <NavigationMenuItem value="sol">
                <NavigationMenuTrigger>Giải pháp</NavigationMenuTrigger>
                <NavigationMenuContent {...c.ds}>
                  <ul className={v === "2 column list" ? "grid w-[30rem] grid-cols-2 gap-2" : "grid w-72 gap-2"}>
                    {NAV_LINKS.map((l) => (
                      <li key={l.title}>
                        <NavigationMenuLink href="#">
                          {v === "with icon" ? (
                            <span className="flex flex-row items-center gap-2">{l.icon}{l.title}</span>
                          ) : (
                            <>
                              <span className="font-medium">{l.title}</span>
                              {v !== "without subtext" && <span className="text-muted-foreground">{l.desc}</span>}
                            </>
                          )}
                        </NavigationMenuLink>
                      </li>
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem><NavigationMenuLink href="#">Bảng giá</NavigationMenuLink></NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>
      )
    },
    note: "NavigationMenu không render qua portal nên hiển thị mở ngay trên trang (value điều khiển).",
  },
  "CM-098": {
    frame: { w: 720, h: 480 },
    render: (c) => {
      const t = c.v("Type").toLowerCase()
      const side = (t === "open" ? "right" : t) as "right"
      return (
        <Sheet open>
          <SheetContent {...c.ds} side={side}>
            <SheetHeader>
              <SheetTitle>Bộ lọc chiến dịch</SheetTitle>
              <SheetDescription>Lọc theo thương hiệu, thời gian và trạng thái.</SheetDescription>
            </SheetHeader>
            <div className="flex flex-col gap-4 px-4">
              <Field><FieldLabel htmlFor={`${c.el.key}-s`}>Thương hiệu</FieldLabel><Input id={`${c.el.key}-s`} placeholder="Tìm thương hiệu" /></Field>
            </div>
            <SheetFooter><Button>Áp dụng</Button></SheetFooter>
          </SheetContent>
        </Sheet>
      )
    },
  },
  "CM-099": {
    frame: { w: 720, h: 520 },
    render: (c) => {
      const t = c.v("Type").toLowerCase()
      const direction = (["left", "right", "top"].includes(t) ? t : "bottom") as "bottom"
      return (
        <Drawer open direction={direction}>
          <DrawerContent {...c.ds}>
            <DrawerHeader>
              <DrawerTitle>Lượt đổi quà theo tháng</DrawerTitle>
              <DrawerDescription>Số voucher đã đổi trong 6 tháng gần nhất.</DrawerDescription>
            </DrawerHeader>
            {t === "chart" && (
              <div className="px-4">
                <ChartContainer config={chartConfig} className="h-40 w-full">
                  <BarChart data={chartData}>
                    <XAxis dataKey="month" tickLine={false} axisLine={false} />
                    <Bar dataKey="value" fill="var(--chart-1)" radius={4} />
                  </BarChart>
                </ChartContainer>
              </div>
            )}
            <DrawerFooter><Button>Xem báo cáo</Button><Button variant="outline">Đóng</Button></DrawerFooter>
          </DrawerContent>
        </Drawer>
      )
    },
  },
  "CM-102": {
    frame: { w: 480, h: 220 },
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      const show = () => {
        const id = c.el.key
        if (v === "with icon") toast.success("Đã phát 1.250 eGift", { id })
        else if (v === "with subtitle") toast("Đã lưu chiến dịch", { id, description: "Thứ Năm, 05/11/2026 lúc 09:30" })
        else if (v === "with action") toast("Đã tạm dừng chiến dịch", { id, action: { label: "Hoàn tác", onClick: () => undefined } })
        else toast("Đã lưu chiến dịch", { id })
      }
      return <ToastFrame ds={c.ds} show={show} />
    },
  },
  "CS-020": {
    frame: { w: 480, h: 220 },
    render: (c) => {
      const show = () => {
        const opts = {
          id: c.el.key,
          description: c.b("Subtitle") ? "Ngân sách còn lại 71.500.000 ₫" : undefined,
          action: c.b("button") ? { label: "Xem", onClick: () => undefined } : undefined,
        }
        if (c.b("Icon")) toast.warning("Ngân sách sắp hết", opts)
        else toast("Ngân sách sắp hết", opts)
      }
      return <ToastFrame ds={c.ds} show={show} />
    },
  },
  "CS-015": { frame: { w: 440, h: 360 }, render: (c) => <ContextMenuFrame c={c} /> },
  "CS-017": {
    render: (c) => (
      <Menubar {...c.ds}>
        {["Chiến dịch", "Ngân sách", "Báo cáo"].map((m) => (
          <MenubarMenu key={m}><MenubarTrigger>{m}</MenubarTrigger></MenubarMenu>
        ))}
      </Menubar>
    ),
  },
  "CS-018": {
    frame: { w: 400, h: 340 },
    render: (c) => (
      <Menubar value="m">
        <MenubarMenu value="m">
          <MenubarTrigger>Chiến dịch</MenubarTrigger>
          <MenubarContent {...c.ds}>
            <MenubarItem>Chiến dịch mới<MenubarShortcut>⌘N</MenubarShortcut></MenubarItem>
            <MenubarItem>Nhân bản</MenubarItem>
            <MenubarSeparator />
            <MenubarItem variant="destructive">Xoá</MenubarItem>
          </MenubarContent>
        </MenubarMenu>
      </Menubar>
    ),
  },
  "CS-019": {
    render: (c) => (
      <NavigationMenu {...c.ds} viewport={false}>
        <NavigationMenuList>
          {["Giải pháp", "Thương hiệu", "Bảng giá", "Liên hệ"].map((m) => (
            <NavigationMenuItem key={m}><NavigationMenuLink href="#">{m}</NavigationMenuLink></NavigationMenuItem>
          ))}
        </NavigationMenuList>
      </NavigationMenu>
    ),
  },
  "CM-104": {
    frame: { w: 400, h: 620, group: true },
    group: (cs, caption) => (
      <Combobox items={BRANDS} open value={BRANDS[0]}>
        <ComboboxInput placeholder="Tìm thương hiệu" className="w-72" />
        <ComboboxContent>
          <ComboboxList>
            {cs.map((c) => (
              <div key={c.el.key} className="flex flex-col gap-1 py-1">
                {c.is("Variant", "Label") ? (
                  <ComboboxGroup items={[]}>
                    <ComboboxLabel {...c.ds}>Ẩm thực</ComboboxLabel>
                  </ComboboxGroup>
                ) : (
                  <ComboboxItem {...c.ds} value={c.is("State", "active") ? BRANDS[0] : `${BRANDS[1]} ${c.el.key}`}>
                    {c.is("Variant", "With subtext") ? (
                      <span className="flex flex-col"><span>{BRANDS[0]}</span><span className="text-xs text-muted-foreground">Đối tác từ 2021</span></span>
                    ) : (
                      BRANDS[0]
                    )}
                  </ComboboxItem>
                )}
                <div className="px-2">{caption(c)}</div>
              </div>
            ))}
          </ComboboxList>
        </ComboboxContent>
      </Combobox>
    ),
  },
  "CM-105": { frame: { w: 440, h: 440 }, render: (c) => <ComboboxFrame c={c} /> },
  "CS-021": {
    frame: { w: 400, h: 400 },
    render: (c) => (
      <Combobox items={BRANDS} open>
        <ComboboxInput placeholder="Tìm thương hiệu" className="w-72" />
        <ComboboxContent>
          <ComboboxList {...c.ds}>{(it: string) => <ComboboxItem key={it} value={it}>{it}</ComboboxItem>}</ComboboxList>
        </ComboboxContent>
      </Combobox>
    ),
  },
  "CM-108": {
    frame: { w: 440, h: 300 },
    render: (c) => (
      <HoverCard open>
        <HoverCardTrigger asChild><Button variant="link">@highlandscoffee</Button></HoverCardTrigger>
        <HoverCardContent {...c.ds} align="start" className="w-80">
          <div className="flex gap-4">
            <Avatar><AvatarFallback>HC</AvatarFallback></Avatar>
            <div className="flex flex-col gap-1">
              <span className="text-sm font-semibold">{BRANDS[0]}</span>
              {c.is("Variants", "With sub text") && <span className="text-sm text-muted-foreground">Đối tác ẩm thực, 600 cửa hàng trên toàn quốc.</span>}
              <span className="text-xs text-muted-foreground">Tham gia từ tháng 3/2021</span>
            </div>
          </div>
        </HoverCardContent>
      </HoverCard>
    ),
  },
  "CM-111": {
    render: (c) => (
      <SidebarProvider className="min-h-0 w-64">
        <SidebarMenu className="rounded-md bg-sidebar p-2">
          <SidebarMenuItem {...c.ds}>
            <SidebarMenuButton isActive={c.is("State", "Active")}>
              {c.b("Left icon") && <GiftIcon />}
              <span>Chiến dịch</span>
              {c.b("Right icon") && <ChevronRightIcon className="ml-auto" />}
            </SidebarMenuButton>
            {c.b("Badge") && <SidebarMenuBadge>12</SidebarMenuBadge>}
            {c.is("Type", "With sub item") && (
              <SidebarMenuSub>
                {["Đang chạy", "Nháp"].map((s) => (
                  <SidebarMenuSubItem key={s}><SidebarMenuSubButton href="#">{s}</SidebarMenuSubButton></SidebarMenuSubItem>
                ))}
              </SidebarMenuSub>
            )}
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarProvider>
    ),
  },
  "CM-112": { frame: { w: 960, h: 560 }, render: (c) => <SidebarDemo c={c} /> },
  "CS-024": {
    render: (c) => (
      <SidebarProvider className="min-h-0 w-64">
        <SidebarGroup {...c.ds} className="rounded-md bg-sidebar">
          {c.b("Label") && <SidebarGroupLabel>Vận hành</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {[
                { t: "Tổng quan", i: <HomeIcon /> },
                { t: "Chiến dịch", i: <GiftIcon /> },
              ].map((m) => (
                <SidebarMenuItem key={m.t}><SidebarMenuButton>{m.i}<span>{m.t}</span></SidebarMenuButton></SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarProvider>
    ),
  },
}

