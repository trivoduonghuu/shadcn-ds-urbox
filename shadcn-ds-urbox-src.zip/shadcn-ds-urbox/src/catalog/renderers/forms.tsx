import * as React from "react"
import {
  EyeIcon,
  EyeOffIcon,
  LinkIcon,
  MailIcon,
  SearchIcon,
  SendIcon,
  TicketIcon,
  UserIcon,
} from "lucide-react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"

import { DatePicker } from "@/components/composed/date-picker"
import { InputNumber } from "@/components/composed/input-number"
import { Rating } from "@/components/composed/rating"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Combobox,
  ComboboxChip,
  ComboboxChips,
  ComboboxChipsInput,
  ComboboxInput,
  ComboboxValue,
} from "@/components/ui/combobox"
import { DropdownMenu, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Field, FieldContent, FieldDescription, FieldError, FieldLabel } from "@/components/ui/field"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupInput,
  InputGroupText,
  InputGroupTextarea,
} from "@/components/ui/input-group"
import { InputOTP, InputOTPGroup, InputOTPSeparator, InputOTPSlot } from "@/components/ui/input-otp"
import { Kbd } from "@/components/ui/kbd"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Spinner } from "@/components/ui/spinner"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { controlTone, toColor } from "@/components/composed/tone"

import type { Ctx } from "../engine"
import { BRANDS, T } from "../sample"
import type { Registry } from "../types"

const MONTH = new Date(2026, 10, 1)
const day = (d: number) => new Date(2026, 10, d)

/** Dong tren / duoi cua o nhap theo boolean Show Top, Show Bottom cua Figma. */
function TopRow({ c, id, extra }: { c: Ctx; id: string; extra?: React.ReactNode }) {
  if (!c.b("Show Top")) return null
  return (
    <div className="flex items-center justify-between gap-2">
      {c.b("- Label") && <FieldLabel htmlFor={id}>{T.label}</FieldLabel>}
      {extra}
      {c.b("- Top Right label") && <span className="text-xs text-muted-foreground">Bắt buộc</span>}
    </div>
  )
}

function BottomRow({ c }: { c: Ctx }) {
  if (!c.b("Show Bottom")) return null
  return (
    <div className="flex items-center justify-between gap-2">
      {c.b("- Bottom Left label") && (c.is("State", "Invalid") ? <FieldError>{T.error}</FieldError> : <FieldDescription>{T.hint}</FieldDescription>)}
      {c.b("- Bottom Right label") && <span className="text-xs text-muted-foreground">{T.right}</span>}
    </div>
  )
}

const fieldState = (c: Ctx) => ({
  "data-invalid": c.is("State", "Invalid") || c.is("State", "invalid") || undefined,
  "data-disabled": c.is("State", "Disabled") || c.is("State", "disabled") || undefined,
})

function InputField(c: Ctx) {
  const id = c.el.key
  const invalid = c.is("State", "Invalid")
  const disabled = c.is("State", "Disabled")
  const value = c.is("Filled", "Yes") ? T.value : undefined
  const grouped = c.b("Left-icon") || c.b("Right-icon") || c.b("Badge")
  return (
    <Field {...c.ds} {...fieldState(c)} className="w-80">
      <TopRow c={c} id={id} />
      {grouped ? (
        <InputGroup data-disabled={disabled || undefined}>
          <InputGroupInput id={id} placeholder={T.placeholder} defaultValue={value} aria-invalid={invalid || undefined} disabled={disabled} />
          {c.b("Left-icon") && <InputGroupAddon>{c.swap("Icon (Left)") === "mail" ? <MailIcon /> : <UserIcon />}</InputGroupAddon>}
          {(c.b("Right-icon") || c.b("Badge")) && (
            <InputGroupAddon align="inline-end">
              {c.b("Badge") && <Badge variant="secondary">{T.badge}</Badge>}
              {c.b("Right-icon") && (c.swap("Icon (Right)") === "eye" ? <EyeIcon /> : <EyeOffIcon />)}
            </InputGroupAddon>
          )}
        </InputGroup>
      ) : (
        <Input id={id} placeholder={T.placeholder} defaultValue={value} aria-invalid={invalid || undefined} disabled={disabled} />
      )}
      <BottomRow c={c} />
    </Field>
  )
}

function SelectField(c: Ctx) {
  const id = c.el.key
  return (
    <Field {...c.ds} {...fieldState(c)} className="w-80">
      <TopRow c={c} id={id} />
      <Select defaultValue={c.is("Filled", "Yes") ? "hl" : undefined} disabled={c.is("State", "Disabled")}>
        <SelectTrigger id={id} size={c.is("Size", "sm") ? "sm" : "default"} aria-invalid={c.is("State", "Invalid") || undefined} className="w-full">
          {c.b("Left Icon") && <TicketIcon />}
          {c.b("Avatar") && (
            <Avatar size="sm"><AvatarFallback>{T.initials}</AvatarFallback></Avatar>
          )}
          <SelectValue placeholder="Chọn thương hiệu" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="hl">{BRANDS[0]}</SelectItem>
          <SelectItem value="pl">{BRANDS[1]}</SelectItem>
        </SelectContent>
      </Select>
      <BottomRow c={c} />
    </Field>
  )
}

function TextareaField(c: Ctx) {
  const id = c.el.key
  return (
    <Field {...c.ds} {...fieldState(c)} className="w-80">
      <TopRow c={c} id={id} extra={c.b("Badge") ? <Badge variant="secondary">{T.badge}</Badge> : undefined} />
      <Textarea
        id={id}
        placeholder="Lời chúc gửi kèm quà tặng"
        defaultValue={c.is("Filled", "Yes") ? "Chúc mừng năm mới, cảm ơn bạn đã đồng hành cùng chúng tôi." : undefined}
        aria-invalid={c.is("State", "Invalid") || undefined}
        disabled={c.is("State", "Disabled")}
      />
      <BottomRow c={c} />
    </Field>
  )
}

function CheckboxField(c: Ctx) {
  const id = c.el.key
  const checked = c.is("State", "indeterminate") ? "indeterminate" : c.is("Status", "Checked")
  return (
    <Field {...c.ds} {...fieldState(c)} orientation="horizontal" className="w-72">
      <Checkbox id={id} className={controlTone("checkbox", toColor(c.v("Variant"))) || undefined} checked={checked} disabled={c.is("State", "disabled")} aria-invalid={c.is("State", "invalid") || undefined} />
      {(c.b("Show Label") || c.b("Show Description Text")) && (
        <FieldContent>
          {c.b("Show Label") && <FieldLabel htmlFor={id}>Gửi email khi phát quà</FieldLabel>}
          {c.b("Show Description Text") && <FieldDescription>Người nhận nhận thông báo kèm mã voucher.</FieldDescription>}
        </FieldContent>
      )}
    </Field>
  )
}

function RadioField(c: Ctx) {
  const id = c.el.key
  return (
    <RadioGroup value={c.is("Status", "Checked") ? "me" : "other"} disabled={c.is("State", "Disabled")}>
      <Field {...c.ds} {...fieldState(c)} orientation="horizontal" className="w-72">
        <RadioGroupItem id={id} value="me" className={controlTone("radio", toColor(c.v("Variant"))) || undefined} aria-invalid={c.is("State", "invalid") || undefined} />
        {(c.b("Label") || c.b("sub label")) && (
          <FieldContent>
            {c.b("Label") && <FieldLabel htmlFor={id}>Phát quà ngay</FieldLabel>}
            {c.b("sub label") && <FieldDescription>Gửi eGift ngay khi chiến dịch được duyệt.</FieldDescription>}
          </FieldContent>
        )}
      </Field>
    </RadioGroup>
  )
}

function SwitchField(c: Ctx) {
  const id = c.el.key
  const side = (left: boolean) => {
    const label = c.b(left ? "Show Left Label" : "Show Right Label")
    const desc = c.b(left ? "Show Left Description" : "Show Right Description")
    if (!label && !desc && !(left && c.b("Show Left Side Content"))) return null
    return (
      <FieldContent>
        {label && (
          <FieldLabel htmlFor={id}>
            {c.b("With Icon") && <MailIcon className="size-4" />}
            {left ? "Thông báo" : "Tự động gia hạn"}
          </FieldLabel>
        )}
        {desc && <FieldDescription>{left ? "Nhận email báo cáo tuần." : "Gia hạn chiến dịch khi hết hạn."}</FieldDescription>}
        {left && c.b("Show Left Side Content") && <Badge variant="secondary">{T.badge}</Badge>}
      </FieldContent>
    )
  }
  return (
    <Field {...c.ds} {...fieldState(c)} orientation="horizontal" className="w-96">
      {side(true)}
      <Switch
        id={id}
        className={controlTone("switch", toColor(c.v("Variant"))) || undefined}
        size={c.is("Size", "sm") ? "sm" : "default"}
        checked={c.is("ON/OFF", "On")}
        disabled={c.is("State", "Disabled")}
        aria-invalid={c.is("State", "Invalid") || undefined}
      />
      {side(false)}
    </Field>
  )
}

function SliderField(c: Ctx) {
  const value = c.is("Variant", "Range") ? [25, 75] : c.is("Variant", "Multiple thumbs") ? [20, 50, 80] : [c.is("Style", "Full") ? 100 : c.is("Style", "Half-Full") ? 50 : 0]
  return (
    <Field {...c.ds} {...fieldState(c)} className="w-72">
      {c.b("Show top") && (
        <div className="flex items-center justify-between gap-2">
          {c.b("Label") && <FieldLabel>Tỷ lệ chiết khấu</FieldLabel>}
          <span className="text-sm text-muted-foreground">{value.join(" – ")}%</span>
        </div>
      )}
      <Slider value={value} max={100} step={1} disabled={c.is("State", "disabled")} />
      {c.b("Sub label") && <FieldDescription>Áp dụng cho toàn bộ voucher của chiến dịch.</FieldDescription>}
    </Field>
  )
}

const comboItems = BRANDS

function ComboToolbar(c: Ctx) {
  const v = c.v("Variant").toLowerCase()
  const multiple = v.includes("multiple")
  const invalid = v.includes("invalid")
  const detail = v.includes("detail")
  const disabled = v === "disabled"
  return (
    <Field {...c.ds} data-invalid={invalid || undefined} className="w-80">
      <FieldLabel>Thương hiệu áp dụng</FieldLabel>
      {multiple ? (
        <Combobox items={comboItems} multiple defaultValue={[BRANDS[0], BRANDS[2]]}>
          <ComboboxChips aria-invalid={invalid || undefined}>
            <ComboboxValue>
              {(values: string[]) => (
                <>
                  {values.map((v) => (
                    <ComboboxChip key={v} showRemove={!c.is("Variant", "Combobox multiple (no remove)")}>{v}</ComboboxChip>
                  ))}
                  <ComboboxChipsInput placeholder="Thêm thương hiệu" />
                </>
              )}
            </ComboboxValue>
          </ComboboxChips>
        </Combobox>
      ) : (
        <Combobox items={comboItems}>
          <ComboboxInput placeholder="Tìm thương hiệu" disabled={disabled} aria-invalid={invalid || undefined}>
            {v === "with icon addon" && <InputGroupAddon><SearchIcon /></InputGroupAddon>}
          </ComboboxInput>
        </Combobox>
      )}
      {detail && <FieldError>Chọn ít nhất một thương hiệu.</FieldError>}
    </Field>
  )
}

const formSchema = z.object({ name: z.string().min(1, "Tên chiến dịch không được để trống.") })

function DemoForm({ ds }: { ds: Ctx["ds"] }) {
  const form = useForm<z.infer<typeof formSchema>>({ resolver: zodResolver(formSchema), defaultValues: { name: "" } })
  return (
    <Form {...form}>
      <form {...ds} onSubmit={form.handleSubmit(() => undefined)} className="flex w-80 flex-col gap-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{T.label}</FormLabel>
              <FormControl><Input placeholder={T.placeholder} {...field} /></FormControl>
              <FormDescription>{T.hint}</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="self-start">Lưu chiến dịch</Button>
      </form>
    </Form>
  )
}

function CalendarDemo(c: Ctx) {
  const v = c.v("Variants").toLowerCase()
  const booked = [day(12), day(13), day(20)]
  if (v === "multiple") return <Calendar {...c.ds} mode="multiple" defaultMonth={MONTH} selected={[day(5), day(11), day(18)]} className="rounded-lg border" />
  if (v === "range") return <Calendar {...c.ds} mode="range" defaultMonth={MONTH} selected={{ from: day(9), to: day(15) }} className="rounded-lg border" />
  if (v === "single") return <Calendar {...c.ds} mode="single" defaultMonth={MONTH} selected={day(5)} className="rounded-lg border" />
  if (v === "week numbers") return <Calendar {...c.ds} mode="single" showWeekNumber defaultMonth={MONTH} selected={day(5)} className="rounded-lg border" />
  if (v === "booked dates")
    return <Calendar {...c.ds} mode="single" defaultMonth={MONTH} disabled={booked} modifiers={{ booked }} modifiersClassNames={{ booked: "line-through" }} className="rounded-lg border" />
  if (v === "range multiple months")
    return <Calendar {...c.ds} mode="range" numberOfMonths={2} defaultMonth={MONTH} selected={{ from: day(24), to: new Date(2026, 11, 3) }} className="rounded-lg border" />
  if (v === "custom days")
    return (
      <Calendar
        {...c.ds}
        mode="single"
        defaultMonth={MONTH}
        selected={day(5)}
        className="rounded-lg border"
        components={{
          DayButton: ({ children, modifiers: _m, day: d, ...props }) => (
            <Button variant="ghost" size="icon" className="flex h-full w-full flex-col gap-0" {...props}>
              {children}
              {!_m.outside && <span className="text-xs text-muted-foreground">{d.date.getDate() % 3 === 0 ? "50k" : "30k"}</span>}
            </Button>
          ),
        }}
      />
    )
  return (
    <Card {...c.ds} className="w-fit py-4">
      <CardContent className="px-4">
        <Calendar mode="single" defaultMonth={MONTH} selected={day(5)} className="p-0" />
      </CardContent>
      <CardFooter className="flex gap-2 border-t px-4 pt-4">
        {v === "watch time" ? (
          <Field>
            <FieldLabel htmlFor="cal-time">Giờ phát quà</FieldLabel>
            <Input id="cal-time" type="time" defaultValue="09:00" />
          </Field>
        ) : (
          ["Hôm nay", "Ngày mai", "Sau 1 tuần"].map((p) => (
            <Button key={p} variant="outline" size="sm">{p}</Button>
          ))
        )}
      </CardFooter>
    </Card>
  )
}

export function DatePickerField(c: Ctx) {
  return (
    <Field {...c.ds} className="w-72">
      {c.b("Show Top Text") && <FieldLabel>Ngày bắt đầu chiến dịch</FieldLabel>}
      <DatePicker open={c.is("State", "Active")} value={c.is("State", "Active") ? day(5) : undefined} showIcon={c.b("Left Icon")} className="w-full" />
      {c.b("Show Bottom Text") && <FieldDescription>Quà được phát từ 00:00 ngày đã chọn.</FieldDescription>}
    </Field>
  )
}

export const forms: Registry = {
  "CM-064": { render: CheckboxField },
  "CM-065": { render: RadioField },
  "CM-067": { render: SwitchField },
  "CM-069": {
    render: (c) => (
      <Rating
        {...c.ds}
        value={c.is("Filled", "True") ? 5 : 0}
        icon={c.is("Type", "Heart") ? "heart" : "star"}
        size={c.is("Size", "sm") ? "sm" : c.is("Size", "lg") ? "lg" : "default"}
        color={c.is("Colors", "Destructive") ? "destructive" : c.is("Colors", "Warning") ? "warning" : "primary"}
      />
    ),
  },
  "CM-071": { render: SliderField },
  "CM-072": { render: InputField },
  "CM-073": {
    render: (c) => {
      const v = c.v("Variant").toLowerCase()
      if (v === "textarea with button")
        return (
          <InputGroup {...c.ds} className="w-80">
            <InputGroupTextarea placeholder="Lời chúc gửi kèm quà" />
            <InputGroupAddon align="block-end">
              <InputGroupButton size="sm" variant="default" className="ml-auto">Gửi<SendIcon /></InputGroupButton>
            </InputGroupAddon>
          </InputGroup>
        )
      return (
        <InputGroup {...c.ds} className="w-80">
          {v === "text link input" && <InputGroupAddon><InputGroupText>https://</InputGroupText></InputGroupAddon>}
          {v === "input group" && <InputGroupAddon><LinkIcon /></InputGroupAddon>}
          {v === "dropdown input" && (
            <InputGroupAddon>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <InputGroupButton variant="ghost">VND</InputGroupButton>
                </DropdownMenuTrigger>
              </DropdownMenu>
            </InputGroupAddon>
          )}
          <InputGroupInput placeholder={v === "text link input" ? "urbox.vn/chien-dich" : T.placeholder} />
          {v === "input group" && <InputGroupAddon align="inline-end"><InputGroupText>.urbox.vn</InputGroupText></InputGroupAddon>}
          {v === "with button" && <InputGroupAddon align="inline-end"><InputGroupButton variant="secondary">Kiểm tra</InputGroupButton></InputGroupAddon>}
          {v === "with icon button" && <InputGroupAddon align="inline-end"><InputGroupButton size="icon-xs" aria-label="Tìm"><SearchIcon /></InputGroupButton></InputGroupAddon>}
          {v === "with kbd" && <InputGroupAddon align="inline-end"><Kbd>⌘K</Kbd></InputGroupAddon>}
          {v === "with spinner" && <InputGroupAddon align="inline-end"><Spinner /></InputGroupAddon>}
        </InputGroup>
      )
    },
  },
  "CM-074": { render: SelectField },
  "CM-075": {
    render: (c) => (
      <div {...c.ds} className="w-fit">
        <InputOTP maxLength={6} value="123">
          {c.is("Variants", "Default") ? (
            <InputOTPGroup>{[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} />)}</InputOTPGroup>
          ) : (
            <>
              <InputOTPGroup>{[0, 1, 2].map((i) => <InputOTPSlot key={i} index={i} />)}</InputOTPGroup>
              <InputOTPSeparator />
              <InputOTPGroup>{[3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} />)}</InputOTPGroup>
            </>
          )}
        </InputOTP>
      </div>
    ),
    note: "InputOTP đưa props xuống thẻ input ẩn, nên data-ds gắn trên thẻ bọc ngoài.",
  },
  "CM-076": {
    render: (c) => (
      <InputOTP maxLength={1} value="5">
        <InputOTPGroup>
          <InputOTPSlot {...c.ds} index={0} aria-invalid={c.is("State", "Invalid") || undefined} />
        </InputOTPGroup>
      </InputOTP>
    ),
  },
  "CM-077": { render: (c) => <Input {...c.ds} type="file" className="w-72" disabled={c.is("isDisabled", "True")} /> },
  "CM-078": { render: TextareaField },
  "CM-081": {
    render: (c) => (
      <Field {...c.ds} {...fieldState(c)} className="w-64">
        {c.b("Show Top") && <FieldLabel>Số lượng voucher</FieldLabel>}
        <InputNumber
          layout={({ "horizontal stretched button": "stretched", "horizontally stacked button": "stacked-horizontal", "vertically stacked buttons": "stacked-vertical", mini: "mini" } as Record<string, React.ComponentProps<typeof InputNumber>["layout"]>)[c.v("Variant").toLowerCase()] ?? "default"}
          defaultValue={c.is("Filled", "Yes") ? 250 : undefined}
          placeholder="0"
          disabled={c.is("State", "Disabled")}
          aria-invalid={c.is("State", "Invalid") || undefined}
        />
        {c.b("Show Bottom") && <FieldDescription>Tối đa 10.000 voucher mỗi đợt.</FieldDescription>}
      </Field>
    ),
  },
  "CM-085": { render: CalendarDemo },
  "CM-086": { render: DatePickerField, frame: { w: 400, h: 480, when: (c) => c.is("State", "Active") } },
  "CM-103": { render: ComboToolbar },
  "CS-012": { render: (c) => <DemoForm ds={c.ds} /> },
  "CS-030": {
    render: (c) => (
      <Field {...c.ds} className="w-80">
        <FieldLabel htmlFor="cs030">{T.label}</FieldLabel>
        <Input id="cs030" placeholder={T.placeholder} />
        <FieldDescription>{T.hint}</FieldDescription>
      </Field>
    ),
  },
}

