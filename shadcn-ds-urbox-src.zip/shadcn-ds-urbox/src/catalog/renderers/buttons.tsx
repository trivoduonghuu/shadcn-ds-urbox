import { HeartIcon, StarIcon } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ButtonGroup } from "@/components/ui/button-group"
import { Kbd } from "@/components/ui/kbd"
import { Spinner } from "@/components/ui/spinner"
import { BASE_VARIANT, tone, toColor, type ToneAppearance } from "@/components/composed/tone"

import type { Ctx } from "../engine"
import { T } from "../sample"
import type { Registry } from "../types"

const SIZE = { xs: "xs", sm: "sm", md: "default", lg: "lg" } as const
const ICON_SIZE = { xs: "icon-xs", sm: "icon-sm", md: "icon", lg: "icon-lg" } as const

const swapIcon = (option?: string) => (option === "star" ? <StarIcon /> : <HeartIcon />)

/** Kieu Figma (Solid, Soft, Outline...) + style mau -> variant shadcn + className tone. */
function toneProps(c: Ctx, appearance: ToneAppearance) {
  const color = toColor(c.v("style"))
  return { variant: BASE_VARIANT[appearance][color], className: tone(appearance, color) || undefined }
}

function textButton(appearance: ToneAppearance) {
  return (c: Ctx) => (
    <Button
      {...c.ds}
      {...toneProps(c, appearance)}
      size={SIZE[c.v("size") as keyof typeof SIZE] ?? "default"}
      disabled={c.is("state", "disabled")}
      aria-invalid={c.is("state", "invalid") || undefined}
    >
      {c.b("Show Spinner") && <Spinner />}
      {c.b("Left Icon") && swapIcon(c.swap("Icon (Left)"))}
      {T.short}
      {c.b("Show Badge") && <Badge variant="secondary">{T.badge}</Badge>}
      {c.b("Show KBD") && <Kbd>⌘K</Kbd>}
      {c.b("Right Icon") && swapIcon(c.swap("Icon (Right)"))}
    </Button>
  )
}

function iconButton(appearance: ToneAppearance) {
  return (c: Ctx) => (
    <Button
      {...c.ds}
      {...toneProps(c, appearance)}
      size={ICON_SIZE[c.v("size") as keyof typeof ICON_SIZE] ?? "icon"}
      disabled={c.is("state", "disabled")}
      aria-label="Yêu thích"
    >
      {swapIcon(c.swap("Icon"))}
    </Button>
  )
}

export const buttons: Registry = {
  "CM-001": {
    render: (c) => {
      const variant = c.is("style", "Outline") ? "outline" : c.is("style", "Secondary") ? "secondary" : "default"
      const size = SIZE[c.v("size") as keyof typeof SIZE] ?? "default"
      return (
        <ButtonGroup {...c.ds} orientation={c.is("Flow", "Vertical") ? "vertical" : "horizontal"}>
          <Button variant={variant as "default"} size={size}>Hôm nay</Button>
          <Button variant={variant as "default"} size={size}>Tuần này</Button>
          <Button variant={variant as "default"} size={size}>Tháng này</Button>
        </ButtonGroup>
      )
    },
  },
  "CM-002": { render: iconButton("solid") },
  "CM-003": { render: iconButton("solid") },
  "CM-004": { render: iconButton("soft") },
  "CM-005": { render: iconButton("outline") },
  "CM-006": { render: iconButton("ghost") },
  "CM-007": { render: iconButton("link") },
  "CM-008": { render: textButton("solid") },
  "CM-009": { render: textButton("solid") },
  "CM-010": { render: textButton("soft") },
  "CM-011": { render: textButton("outline") },
  "CM-012": { render: textButton("ghost") },
  "CM-013": { render: textButton("link") },
}
