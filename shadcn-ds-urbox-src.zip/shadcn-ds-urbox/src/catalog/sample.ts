// Chu mau tieng Viet co dau cho catalog.
export const T = {
  title: "Quản lý ngân sách chiến dịch ưu đãi",
  short: "Tạo chiến dịch",
  desc: "Theo dõi số dư, hạn mức và lượt đổi quà của từng chương trình khách hàng thân thiết.",
  badge: "Mới",
  item: "Voucher ưu đãi tháng Mười Một",
  person: "Nguyễn Thị Hằng",
  initials: "NH",
  email: "hang.nguyen@urbox.vn",
  placeholder: "Nhập tên chiến dịch",
  value: "Ưu đãi Tết Nguyên Đán 2027",
  label: "Tên chiến dịch",
  hint: "Tối đa 80 ký tự, hiển thị cho người nhận quà.",
  right: "0/80",
  error: "Tên chiến dịch không được để trống.",
}

export const MENU = ["Xem chi tiết", "Nhân bản chiến dịch", "Xuất báo cáo đối soát", "Tạm dừng phát quà"]
export const MONTHS = ["Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11"]
export const BRANDS = ["Highlands Coffee", "Phúc Long", "Grab", "Shopee", "Lotte Mart", "CGV"]
