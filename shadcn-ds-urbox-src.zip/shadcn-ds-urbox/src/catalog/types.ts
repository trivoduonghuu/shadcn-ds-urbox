import type * as React from "react"

import type { Ctx } from "./engine"

export type Renderer = {
  /** Render mot phan tu. Phai trai c.ds len phan tu goc cua component. */
  render?: (c: Ctx) => React.ReactNode
  /** Render ca nhom phan tu trong mot overlay mo (vd. cac item trong mot menu). */
  group?: (cs: Ctx[], caption: (c: Ctx) => React.ReactNode) => React.ReactNode
  /** Overlay: moi phan tu (hoac ca nhom) mo trong mot iframe rieng. */
  frame?: { w: number; h: number; group?: boolean; when?: (c: Ctx) => boolean }
  /** Ghi chu hien duoi tieu de khoi. */
  note?: string
}

export type Registry = Record<string, Renderer>
