import codeMapJson from "./code-map.json"
import specJson from "./map.generated.json"

export type MapProp = { name: string; values: string[]; default: string }
export type MapRow = {
  id: string
  sheet: string
  figma: string
  kind: string
  ds: string
  props: MapProp[]
  bools: { name: string; default: boolean }[]
  swaps: { name: string; default: string }[]
}
export type CodeEntry = {
  code: string
  props: Record<string, Record<string, string>>
  bools: Record<string, string>
  swaps: Record<string, { code: string; option: string }>
  lech: string[][]
  np_suggest?: Record<string, string>
}

export const spec = specJson as MapRow[]
export const codeMap = codeMapJson as Record<string, CodeEntry>

export const FIGMA_ONLY = "FIGMA_ONLY"
const MAX_COMBOS = 24

/** Mot phan tu tren catalog: mot to hop gia tri theo ten Figma. */
export type Element = {
  key: string
  values: Record<string, string>
  bools: Record<string, boolean>
  swap?: { name: string; option: string }
  propsString: string
  noProp: string[]
}

const lower = (s: string) => s.toLowerCase()

/** Boolean co ten bat dau bang "- " phu thuoc boolean cha (Show Top / Show Bottom). */
function parentOf(row: MapRow, name: string): string | undefined {
  if (!name.startsWith("- ")) return undefined
  const wanted = /bottom/i.test(name) ? "show bottom" : "show top"
  return row.bools.find((b) => lower(b.name) === wanted)?.name
}

/** Boolean bat/tat icon ung voi mot instance swap; bat len o phan tu swap de thay duoc lua chon. */
export function swapBool(row: MapRow, swapName: string): string | undefined {
  const side = /\(left\)/i.test(swapName) ? "left" : /\(right\)/i.test(swapName) ? "right" : ""
  const re = side ? new RegExp(`${side}.?icon`, "i") : /^(show icon|indicator icon|icon)$/i
  return row.bools.find((b) => re.test(b.name))?.name
}

export function activeProps(row: MapRow): MapProp[] {
  const entry = codeMap[row.id]
  return row.props
    .map((p) => ({
      ...p,
      values: p.values.filter((v) => entry.props[p.name]?.[v] !== FIGMA_ONLY),
    }))
    .filter((p) => p.values.length > 0)
}

export function buildElements(row: MapRow): Element[] {
  const entry = codeMap[row.id]
  const props = activeProps(row)
  const defaults: Record<string, string> = {}
  for (const p of props) defaults[p.name] = p.values.includes(p.default) ? p.default : p.values[0]
  const boolDefaults: Record<string, boolean> = {}
  for (const b of row.bools) boolDefaults[b.name] = b.default

  const combos: Record<string, string>[] = []
  const total = props.reduce((n, p) => n * p.values.length, props.length ? 1 : 0)
  if (total > 0 && total <= MAX_COMBOS) {
    let acc: Record<string, string>[] = [{}]
    for (const p of props) acc = acc.flatMap((c) => p.values.map((v) => ({ ...c, [p.name]: v })))
    combos.push(...acc)
  } else if (total > MAX_COMBOS) {
    for (const p of props) for (const v of p.values) combos.push({ ...defaults, [p.name]: v })
  }

  const out: Omit<Element, "key" | "propsString" | "noProp">[] = combos.map((values) => ({ values, bools: { ...boolDefaults } }))
  for (const b of row.bools) {
    for (const on of [true, false]) {
      const bools = { ...boolDefaults, [b.name]: on }
      const parent = parentOf(row, b.name)
      if (parent) bools[parent] = true
      out.push({ values: { ...defaults }, bools })
    }
  }
  for (const s of row.swaps) {
    const bools = { ...boolDefaults }
    const related = swapBool(row, s.name)
    if (related) bools[related] = true
    out.push({ values: { ...defaults }, bools, swap: { name: s.name, option: entry.swaps[s.name].option } })
  }
  if (out.length === 0) out.push({ values: {}, bools: {} })

  return out.map((e, i) => {
    const parts = [
      ...props.map((p) => `${p.name}=${e.values[p.name]}`),
      ...row.bools.map((b) => `${b.name}=${e.bools[b.name]}`),
      ...(e.swap ? [`${e.swap.name}=${e.swap.option}`] : []),
    ]
    const noProp = props
      .filter((p) => entry.props[p.name]?.[e.values[p.name]]?.startsWith("NO_PROP"))
      .map((p) => `${p.name}=${e.values[p.name]}`)
    return { ...e, key: `${row.id}-${i}`, propsString: parts.join("; "), noProp }
  })
}

/** Truy cap gia tri theo ten Figma, khong phan biet hoa/thuong. */
export class Ctx {
  readonly row: MapRow
  readonly el: Element
  readonly ds: { "data-ds": string; "data-ds-props": string }
  constructor(row: MapRow, el: Element) {
    this.row = row
    this.el = el
    this.ds = { "data-ds": row.ds, "data-ds-props": el.propsString }
  }
  v(name: string): string {
    const k = Object.keys(this.el.values).find((x) => lower(x) === lower(name))
    return k ? this.el.values[k] : ""
  }
  is(name: string, value: string): boolean {
    return lower(this.v(name)) === lower(value)
  }
  b(name: string): boolean {
    const k = Object.keys(this.el.bools).find((x) => lower(x) === lower(name))
    return k ? this.el.bools[k] : false
  }
  swap(name: string): string | undefined {
    return this.el.swap && lower(this.el.swap.name) === lower(name) ? this.el.swap.option : undefined
  }
}
