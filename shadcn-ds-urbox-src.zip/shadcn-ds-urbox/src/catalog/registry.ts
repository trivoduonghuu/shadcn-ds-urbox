import { badges } from "./renderers/badges"
import { buttons } from "./renderers/buttons"
import { charts } from "./renderers/charts"
import { forms } from "./renderers/forms"
import { layout } from "./renderers/layout"
import { overlays } from "./renderers/overlays"
import type { Registry } from "./types"

export const R: Registry = { ...buttons, ...badges, ...layout, ...forms, ...overlays, ...charts }
