import * as React from "react"

import { cn } from "@/lib/utils"

// Timeline ghep tu token theme. Khong co trong shadcn/ui.
type TimelineItem = { title: React.ReactNode; time: React.ReactNode; description?: React.ReactNode; icon?: React.ReactNode }

type TimelineProps = React.ComponentProps<"ol"> & {
  items: TimelineItem[]
  variant?: "basic" | "icon" | "centered"
  inline?: boolean
}

function Timeline({ items, variant = "basic", inline = true, className, ...props }: TimelineProps) {
  return (
    <ol data-composed="timeline" data-variant={variant} className={cn("flex flex-col gap-4", className)} {...props}>
      {items.map((it, i) => (
        <li key={i} className={cn("flex gap-3", variant === "centered" && "grid grid-cols-[1fr_auto_1fr] items-start")}>
          {variant === "centered" && <span className="pt-1 text-right text-xs text-muted-foreground">{it.time}</span>}
          <span
            className={cn(
              "flex shrink-0 items-center justify-center rounded-full border border-primary bg-primary text-primary-foreground",
              variant === "icon" ? "size-8 [&_svg]:size-4" : "mt-1 size-3"
            )}
          >
            {variant === "icon" ? it.icon : null}
          </span>
          <div className={cn("flex gap-1", inline ? "flex-row flex-wrap items-baseline gap-x-2" : "flex-col")}>
            <span className="text-sm font-medium text-foreground">{it.title}</span>
            {variant !== "centered" && <span className="text-xs text-muted-foreground">{it.time}</span>}
            {it.description && <span className="w-full text-sm text-muted-foreground">{it.description}</span>}
          </div>
        </li>
      ))}
    </ol>
  )
}

export { Timeline }
