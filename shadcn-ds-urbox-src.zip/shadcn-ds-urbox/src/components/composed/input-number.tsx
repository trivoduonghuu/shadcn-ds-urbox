import * as React from "react"
import { ChevronDownIcon, ChevronUpIcon, MinusIcon, PlusIcon } from "lucide-react"

import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput } from "@/components/ui/input-group"
import { cn } from "@/lib/utils"

// Input Number ghep tu InputGroup (shadcn). Khong co trong shadcn/ui.
type Layout = "default" | "stretched" | "stacked-horizontal" | "stacked-vertical" | "mini"

type InputNumberProps = Omit<React.ComponentProps<typeof InputGroupInput>, "type"> & {
  layout?: Layout
}

function InputNumber({ layout = "default", disabled, className, ...props }: InputNumberProps) {
  const minus = (
    <InputGroupButton size="icon-xs" aria-label="Giảm" disabled={disabled}>
      <MinusIcon />
    </InputGroupButton>
  )
  const plus = (
    <InputGroupButton size="icon-xs" aria-label="Tăng" disabled={disabled}>
      <PlusIcon />
    </InputGroupButton>
  )
  return (
    <InputGroup data-composed="input-number" data-layout={layout} data-disabled={disabled} className={cn(layout === "mini" ? "w-28" : "w-56", className)}>
      {(layout === "stretched" || layout === "mini") && <InputGroupAddon>{minus}</InputGroupAddon>}
      <InputGroupInput type="number" inputMode="numeric" disabled={disabled} className={cn(layout !== "default" && "text-center")} {...props} />
      {(layout === "stretched" || layout === "mini") && <InputGroupAddon align="inline-end">{plus}</InputGroupAddon>}
      {layout === "stacked-horizontal" && (
        <InputGroupAddon align="inline-end">
          {minus}
          {plus}
        </InputGroupAddon>
      )}
      {(layout === "stacked-vertical" || layout === "default") && (
        <InputGroupAddon align="inline-end" className="flex-col gap-0 py-0">
          <InputGroupButton size="icon-xs" aria-label="Tăng" disabled={disabled}>
            <ChevronUpIcon />
          </InputGroupButton>
          <InputGroupButton size="icon-xs" aria-label="Giảm" disabled={disabled}>
            <ChevronDownIcon />
          </InputGroupButton>
        </InputGroupAddon>
      )}
    </InputGroup>
  )
}

export { InputNumber }
