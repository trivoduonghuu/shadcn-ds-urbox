import * as React from "react"
import { HeartIcon, StarIcon } from "lucide-react"

import { Toggle } from "@/components/ui/toggle"
import { cn } from "@/lib/utils"

// Rating ghep tu Toggle (shadcn). Mau chi dung token theme.
type RatingProps = Omit<React.ComponentProps<"div">, "color"> & {
  value?: number
  max?: number
  icon?: "star" | "heart"
  size?: "sm" | "default" | "lg"
  color?: "primary" | "warning" | "destructive"
}

function Rating({ value = 0, max = 5, icon = "star", size = "default", color = "primary", className, ...props }: RatingProps) {
  const Icon = icon === "heart" ? HeartIcon : StarIcon
  return (
    <div data-composed="rating" role="radiogroup" className={cn("flex items-center", className)} {...props}>
      {Array.from({ length: max }, (_, i) => (
        <Toggle key={i} size={size} pressed={i < value} aria-label={`${i + 1} / ${max}`} className="px-0">
          <Icon className={cn(color === "destructive" ? "text-destructive" : color === "warning" ? "text-warning" : "text-primary", i < value && "fill-current")} />
        </Toggle>
      ))}
    </div>
  )
}

export { Rating }
