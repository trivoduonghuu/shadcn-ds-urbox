import * as React from "react"
import { CheckIcon } from "lucide-react"

import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

// Stepper ghep tu Separator + token theme. Khong co trong shadcn/ui.
type Orientation = "horizontal" | "vertical"
type Shape = "rounded" | "round"

type StepItemProps = Omit<React.ComponentProps<"div">, "title"> & {
  index?: number
  title: React.ReactNode
  description?: React.ReactNode
  position?: "start" | "middle"
  active?: boolean
  orientation?: Orientation
  bullet?: "text" | "icon"
  shape?: Shape
  icon?: React.ReactNode
}

function StepItem({
  index = 1,
  title,
  description,
  position = "start",
  active = false,
  orientation = "horizontal",
  bullet = "text",
  shape = "rounded",
  icon,
  className,
  ...props
}: StepItemProps) {
  return (
    <div
      data-composed="step-item"
      data-active={active}
      data-orientation={orientation}
      className={cn("flex gap-2", orientation === "horizontal" ? "flex-row items-center" : "flex-col", className)}
      {...props}
    >
      {position === "middle" && (
        <Separator orientation={orientation === "horizontal" ? "horizontal" : "vertical"} className={orientation === "horizontal" ? "w-8" : "ml-4 h-6"} />
      )}
      <div className="flex items-center gap-2">
        <span
          className={cn(
            "flex size-8 shrink-0 items-center justify-center border text-sm font-medium",
            shape === "round" ? "rounded-full" : "rounded-md",
            active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"
          )}
        >
          {bullet === "icon" ? (icon ?? <CheckIcon className="size-4" />) : index}
        </span>
        <span className="flex flex-col">
          <span className={cn("text-sm font-medium", active ? "text-foreground" : "text-muted-foreground")}>{title}</span>
          {description && <span className="text-xs text-muted-foreground">{description}</span>}
        </span>
      </div>
    </div>
  )
}

type StepsProps = React.ComponentProps<"div"> & {
  steps: { title: React.ReactNode; description?: React.ReactNode }[]
  current?: number
  orientation?: Orientation
  shape?: Shape
  bullet?: "text" | "icon"
}

function Steps({ steps, current = 0, orientation = "horizontal", shape = "rounded", bullet = "text", className, ...props }: StepsProps) {
  return (
    <div
      data-composed="steps"
      data-orientation={orientation}
      className={cn("flex gap-2", orientation === "horizontal" ? "flex-row items-center" : "flex-col", className)}
      {...props}
    >
      {steps.map((s, i) => (
        <StepItem
          key={i}
          index={i + 1}
          title={s.title}
          description={s.description}
          position={i === 0 ? "start" : "middle"}
          active={i <= current}
          orientation={orientation}
          shape={shape}
          bullet={bullet}
        />
      ))}
    </div>
  )
}

export { Steps, StepItem }
