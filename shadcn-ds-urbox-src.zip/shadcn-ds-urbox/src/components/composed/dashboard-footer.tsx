import * as React from "react"
import { GlobeIcon, MailIcon, PhoneIcon } from "lucide-react"

import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

// Footer dashboard ghep tu Separator, Button, Breadcrumb. Khong co trong shadcn/ui.
type Variant = "default" | "social" | "actions" | "breadcrumb" | "centered" | "two-rows" | "two-rows-button"

const PAGES = ["Chính sách", "Điều khoản", "Hỗ trợ"]

function Links() {
  return (
    <nav className="flex gap-4">
      {PAGES.map((p) => (
        <Button key={p} variant="link" size="sm" className="px-0 text-muted-foreground">
          {p}
        </Button>
      ))}
    </nav>
  )
}

function Social() {
  return (
    <div className="flex gap-1">
      {[GlobeIcon, MailIcon, PhoneIcon].map((Icon, i) => (
        <Button key={i} variant="ghost" size="icon-sm" aria-label="Liên kết">
          <Icon />
        </Button>
      ))}
    </div>
  )
}

function DashboardFooter({ variant = "default", className, ...props }: React.ComponentProps<"footer"> & { variant?: Variant }) {
  const copy = <span className="text-sm text-muted-foreground">© 2026 UrBox. Nền tảng quà tặng doanh nghiệp.</span>
  return (
    <footer data-composed="dashboard-footer" data-variant={variant} className={cn("flex w-full flex-col gap-4 border-t bg-background px-6 py-4", className)} {...props}>
      {variant === "default" && <div className="flex items-center justify-between gap-4">{copy}<Links /></div>}
      {variant === "social" && <div className="flex items-center justify-between gap-4">{copy}<Social /></div>}
      {variant === "actions" && (
        <div className="flex items-center justify-between gap-4">
          {copy}
          <div className="flex gap-2">
            <Button variant="outline" size="sm">Huỷ</Button>
            <Button size="sm">Lưu chiến dịch</Button>
          </div>
        </div>
      )}
      {variant === "breadcrumb" && (
        <div className="flex items-center justify-between gap-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem><BreadcrumbLink href="#">Chiến dịch</BreadcrumbLink></BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem><BreadcrumbPage>Ngân sách ưu đãi</BreadcrumbPage></BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          {copy}
        </div>
      )}
      {variant === "centered" && (
        <div className="flex flex-col items-center gap-2">
          <span className="text-base font-semibold text-primary">UrBox</span>
          <Links />
          {copy}
        </div>
      )}
      {(variant === "two-rows" || variant === "two-rows-button") && (
        <>
          <div className="flex items-center justify-between gap-4">
            <span className="text-base font-semibold text-primary">UrBox</span>
            {variant === "two-rows-button" ? <Button size="sm">Liên hệ tư vấn</Button> : <Links />}
          </div>
          <Separator />
          <div className="flex items-center justify-between gap-4">{copy}<Social /></div>
        </>
      )}
    </footer>
  )
}

export { DashboardFooter }
