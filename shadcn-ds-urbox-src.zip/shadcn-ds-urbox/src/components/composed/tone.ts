// Tong mau ngu nghia cho cac kieu Figma ma shadcn/ui khong co variant (Soft, mau success/warning/info...).
// Dung bang className tren component shadcn, khong sua source shadcn. Chi dung token trong theme.
//   Soft  = nen mau 10% + chu cung mau (quyet dinh UX 05/11/2026, thay cho variant="secondary").
// Chuoi class viet day du de Tailwind quet duoc.

export type ToneColor = "primary" | "secondary" | "destructive" | "success" | "warning" | "info"
export type ToneAppearance = "solid" | "soft" | "outline" | "ghost" | "link"

const BUTTON: Record<ToneAppearance, Record<ToneColor, string>> = {
  solid: {
    primary: "",
    secondary: "",
    destructive: "",
    success: "bg-success text-success-foreground hover:bg-success/90",
    warning: "bg-warning text-warning-foreground hover:bg-warning/90",
    info: "bg-info text-info-foreground hover:bg-info/90",
  },
  soft: {
    primary: "bg-primary/10 text-primary shadow-none hover:bg-primary/20",
    secondary: "bg-secondary/60 text-secondary-foreground shadow-none hover:bg-secondary",
    destructive: "bg-destructive/10 text-destructive shadow-none hover:bg-destructive/20",
    success: "bg-success/10 text-success shadow-none hover:bg-success/20",
    warning: "bg-warning/10 text-warning shadow-none hover:bg-warning/20",
    info: "bg-info/10 text-info shadow-none hover:bg-info/20",
  },
  outline: {
    primary: "border-primary text-primary hover:bg-primary/10 hover:text-primary",
    secondary: "border-secondary text-secondary-foreground hover:bg-secondary/60",
    destructive: "border-destructive text-destructive hover:bg-destructive/10 hover:text-destructive",
    success: "border-success text-success hover:bg-success/10 hover:text-success",
    warning: "border-warning text-warning hover:bg-warning/10 hover:text-warning",
    info: "border-info text-info hover:bg-info/10 hover:text-info",
  },
  ghost: {
    primary: "text-primary hover:bg-primary/10 hover:text-primary",
    secondary: "text-secondary-foreground hover:bg-secondary/60",
    destructive: "text-destructive hover:bg-destructive/10 hover:text-destructive",
    success: "text-success hover:bg-success/10 hover:text-success",
    warning: "text-warning hover:bg-warning/10 hover:text-warning",
    info: "text-info hover:bg-info/10 hover:text-info",
  },
  link: {
    primary: "",
    secondary: "text-secondary-foreground",
    destructive: "text-destructive",
    success: "text-success",
    warning: "text-warning",
    info: "text-info",
  },
}

/** Variant shadcn lam nen cho moi kieu; className tone phu len tren. */
export const BASE_VARIANT = {
  solid: { primary: "default", secondary: "secondary", destructive: "destructive", success: "default", warning: "default", info: "default" },
  soft: { primary: "ghost", secondary: "ghost", destructive: "ghost", success: "ghost", warning: "ghost", info: "ghost" },
  outline: { primary: "outline", secondary: "outline", destructive: "outline", success: "outline", warning: "outline", info: "outline" },
  ghost: { primary: "ghost", secondary: "ghost", destructive: "ghost", success: "ghost", warning: "ghost", info: "ghost" },
  link: { primary: "link", secondary: "link", destructive: "link", success: "link", warning: "link", info: "link" },
} as const satisfies Record<ToneAppearance, Record<ToneColor, string>>

export function tone(appearance: ToneAppearance, color: ToneColor) {
  return BUTTON[appearance][color]
}

const BADGE: Record<"solid" | "soft" | "outline", Record<ToneColor, string>> = {
  solid: {
    primary: "",
    secondary: "",
    destructive: "",
    success: "border-transparent bg-success text-success-foreground",
    warning: "border-transparent bg-warning text-warning-foreground",
    info: "border-transparent bg-info text-info-foreground",
  },
  soft: {
    primary: "border-transparent bg-primary/10 text-primary",
    secondary: "border-transparent bg-secondary/60 text-secondary-foreground",
    destructive: "border-transparent bg-destructive/10 text-destructive",
    success: "border-transparent bg-success/10 text-success",
    warning: "border-transparent bg-warning/10 text-warning",
    info: "border-transparent bg-info/10 text-info",
  },
  outline: {
    primary: "border-primary text-primary",
    secondary: "border-secondary text-secondary-foreground",
    destructive: "border-destructive text-destructive",
    success: "border-success text-success",
    warning: "border-warning text-warning",
    info: "border-info text-info",
  },
}

export const BADGE_BASE = {
  solid: { primary: "default", secondary: "secondary", destructive: "destructive", success: "default", warning: "default", info: "default" },
  soft: { primary: "outline", secondary: "outline", destructive: "outline", success: "outline", warning: "outline", info: "outline" },
  outline: { primary: "outline", secondary: "outline", destructive: "outline", success: "outline", warning: "outline", info: "outline" },
} as const

export function badgeTone(appearance: "solid" | "soft" | "outline", color: ToneColor) {
  return BADGE[appearance][color]
}

export type AlertColor = "neutral" | "primary" | "destructive" | "success" | "warning" | "info"

const ALERT: Record<"outline" | "solid" | "soft", Record<AlertColor, string>> = {
  outline: {
    neutral: "",
    primary: "border-primary text-primary",
    destructive: "border-destructive",
    success: "border-success text-success [&>svg]:text-success",
    warning: "border-warning text-warning [&>svg]:text-warning",
    info: "border-info text-info [&>svg]:text-info",
  },
  solid: {
    neutral: "border-transparent bg-foreground text-background *:data-[slot=alert-description]:text-background/90",
    primary: "border-transparent bg-primary text-primary-foreground *:data-[slot=alert-description]:text-primary-foreground/90",
    destructive: "border-transparent bg-destructive text-background *:data-[slot=alert-description]:text-background/90",
    success: "border-transparent bg-success text-success-foreground *:data-[slot=alert-description]:text-success-foreground/90",
    warning: "border-transparent bg-warning text-warning-foreground *:data-[slot=alert-description]:text-warning-foreground/90",
    info: "border-transparent bg-info text-info-foreground *:data-[slot=alert-description]:text-info-foreground/90",
  },
  soft: {
    neutral: "border-transparent bg-muted",
    primary: "border-transparent bg-primary/10 text-primary",
    destructive: "border-transparent bg-destructive/10",
    success: "border-transparent bg-success/10 text-success *:data-[slot=alert-description]:text-success/90",
    warning: "border-transparent bg-warning/10 text-warning *:data-[slot=alert-description]:text-warning/90",
    info: "border-transparent bg-info/10 text-info *:data-[slot=alert-description]:text-info/90",
  },
}

export function alertTone(appearance: "outline" | "solid" | "soft", color: AlertColor) {
  return ALERT[appearance][color]
}

const CONTROL = {
  checkbox: {
    primary: "",
    secondary: "data-[state=checked]:border-secondary data-[state=checked]:bg-secondary data-[state=checked]:text-secondary-foreground",
    destructive: "data-[state=checked]:border-destructive data-[state=checked]:bg-destructive data-[state=checked]:text-background",
    success: "data-[state=checked]:border-success data-[state=checked]:bg-success data-[state=checked]:text-success-foreground",
    warning: "data-[state=checked]:border-warning data-[state=checked]:bg-warning data-[state=checked]:text-warning-foreground",
    info: "data-[state=checked]:border-info data-[state=checked]:bg-info data-[state=checked]:text-info-foreground",
  },
  radio: {
    primary: "",
    secondary: "text-secondary-foreground [&_svg]:fill-secondary-foreground",
    destructive: "text-destructive [&_svg]:fill-destructive",
    success: "text-success [&_svg]:fill-success",
    warning: "text-warning [&_svg]:fill-warning",
    info: "text-info [&_svg]:fill-info",
  },
  switch: {
    primary: "",
    secondary: "data-[state=checked]:bg-secondary",
    destructive: "data-[state=checked]:bg-destructive",
    success: "data-[state=checked]:bg-success",
    warning: "data-[state=checked]:bg-warning",
    info: "data-[state=checked]:bg-info",
  },
} satisfies Record<string, Record<ToneColor, string>>

export function controlTone(control: keyof typeof CONTROL, color: ToneColor) {
  return CONTROL[control][color]
}

/** Doc ten mau Figma (khong phan biet hoa/thuong). Amber dung chung warning. */
export function toColor(figma: string): ToneColor {
  const v = figma.toLowerCase()
  if (v === "amber") return "warning"
  return (["primary", "secondary", "destructive", "success", "warning", "info"] as const).find((c) => c === v) ?? "primary"
}
