import * as React from "react"

import { AvatarBadge } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

// Ghep tu AvatarBadge (shadcn). Chi dung token trong theme.
const TYPE_CLASS = {
  online: "bg-success",
  away: "bg-warning",
  busy: "bg-destructive",
  offline: "bg-muted-foreground",
  primary: "bg-primary",
} as const

type StatusIndicatorProps = React.ComponentProps<typeof AvatarBadge> & {
  type?: keyof typeof TYPE_CLASS
}

function StatusIndicator({ type = "online", className, ...props }: StatusIndicatorProps) {
  return (
    <AvatarBadge
      data-composed="status-indicator"
      data-type={type}
      className={cn(TYPE_CLASS[type], "text-primary-foreground", className)}
      {...props}
    />
  )
}

export { StatusIndicator }
