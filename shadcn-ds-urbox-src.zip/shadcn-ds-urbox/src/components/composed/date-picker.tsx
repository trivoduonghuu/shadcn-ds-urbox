import * as React from "react"
import { CalendarIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"

// Date Picker ghep tu Popover + Button + Calendar (pattern trong docs shadcn).
type DatePickerProps = Omit<React.ComponentProps<typeof Button>, "value"> & {
  open?: boolean
  value?: Date
  placeholder?: string
  showIcon?: boolean
}

const format = (d: Date) => d.toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" })

function DatePicker({ open, value, placeholder = "Chọn ngày", showIcon = false, className, ...props }: DatePickerProps) {
  return (
    <Popover open={open}>
      <PopoverTrigger asChild>
        <Button variant="outline" data-composed="date-picker" data-empty={!value} className={cn("w-60 justify-start font-normal data-[empty=true]:text-muted-foreground", className)} {...props}>
          {showIcon && <CalendarIcon />}
          {value ? format(value) : placeholder}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar mode="single" selected={value} defaultMonth={value} />
      </PopoverContent>
    </Popover>
  )
}

export { DatePicker }
