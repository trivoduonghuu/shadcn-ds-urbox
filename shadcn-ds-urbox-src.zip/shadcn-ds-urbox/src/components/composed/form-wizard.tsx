import * as React from "react"

import { Steps } from "@/components/composed/steps"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { cn } from "@/lib/utils"

// Form Wizard ghep tu Steps + Card + Button.
type FormWizardProps = React.ComponentProps<typeof Card> & {
  steps: { title: React.ReactNode; description?: React.ReactNode }[]
  current?: number
  orientation?: "horizontal" | "vertical"
  bullet?: "text" | "icon"
}

function FormWizard({ steps, current = 0, orientation = "horizontal", bullet = "text", children, className, ...props }: FormWizardProps) {
  return (
    <Card data-composed="form-wizard" data-orientation={orientation} className={cn("w-full", className)} {...props}>
      <CardContent className={cn("flex gap-6", orientation === "horizontal" ? "flex-col" : "flex-row")}>
        <Steps steps={steps} current={current} orientation={orientation} bullet={bullet} />
        <div className="flex flex-1 flex-col gap-4">{children}</div>
      </CardContent>
      <CardFooter className="justify-end gap-2">
        <Button variant="outline">Quay lại</Button>
        <Button>Tiếp tục</Button>
      </CardFooter>
    </Card>
  )
}

export { FormWizard }
